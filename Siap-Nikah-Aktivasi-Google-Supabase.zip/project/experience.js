/* Reception ledger, receipts and compact paginated lists. */
const pageSettings={};
function paginate(){
  const root=$('view');if(!root)return;
  const selectors={gifts:'.gift-card',admin:'.doc-row',users:'.user-card',dashboard:'.expense-row'};
  const items=[...root.querySelectorAll(selectors[route]||'#records tbody tr')];
  root.querySelector('.list-pagination')?.remove();
  if(!items.length)return;
  const settings=pageSettings[route]||(pageSettings[route]={size:10,page:1});
  const signature=items.map(x=>x.dataset.rowId||x.querySelector('[data-edit],[data-doc-edit],[data-edit-gift],[data-user]')?.outerHTML||x.textContent.slice(0,100)).join('|');
  if(settings.signature!==signature){settings.page=1;settings.signature=signature;}
  const size=settings.size===0?items.length:settings.size,pages=Math.max(1,Math.ceil(items.length/size));settings.page=Math.min(settings.page,pages);
  const start=(settings.page-1)*size,end=Math.min(start+size,items.length);
  items.forEach((item,i)=>item.hidden=i<start||i>=end);
  if(route==='gifts')root.querySelectorAll('.group-header').forEach(header=>header.hidden=![...header.nextElementSibling.querySelectorAll('.gift-card')].some(x=>!x.hidden));
  const bar=document.createElement('div');bar.className='list-pagination';
  bar.innerHTML='<label>Tampilkan <select aria-label="Jumlah baris">'+[[10,'10'],[25,'25'],[50,'50'],[100,'100'],[0,'Semua']].map(([value,label])=>'<option value="'+value+'" '+(value===settings.size?'selected':'')+'>'+label+'</option>').join('')+'</select> baris</label><span>'+numberFormat(start+1)+'–'+numberFormat(end)+' dari '+numberFormat(items.length)+'</span><div><button class="button secondary" data-page-prev '+(settings.page===1?'disabled':'')+' aria-label="Halaman sebelumnya">‹</button><span>'+settings.page+' / '+pages+'</span><button class="button secondary" data-page-next '+(settings.page===pages?'disabled':'')+' aria-label="Halaman berikutnya">›</button></div>';
  const host=route==='dashboard'?root.querySelector('#expense-list'):route==='gifts'?$('gift-groups'):route==='admin'?$('docs'):route==='users'?root.querySelector('.item-grid'):$('records');host.after(bar);
  bar.querySelector('select').onchange=e=>{settings.size=Number(e.target.value);settings.page=1;paginate();};
  bar.querySelector('[data-page-prev]').onclick=()=>{settings.page--;paginate();};bar.querySelector('[data-page-next]').onclick=()=>{settings.page++;paginate();};
}
function guestLedgerSummary(){
  if(route!=='guests'||!$('records'))return;
  const rows=visibleRows();
  $('records').querySelectorAll('tbody tr').forEach((tr,i)=>{
    const guest=rows[i],people=C.attendance(guest),cash=people.reduce((s,p)=>s+p.cash,0),goods=people.filter(p=>p.goods).length;
    if(!guest||tr.querySelector('[data-reception]'))return;
    tr.children[3].insertAdjacentHTML('beforeend','<small>'+numberFormat(people.length)+' hadir tercatat</small>'+(cash?'<small>'+money(cash)+'</small>':'')+(goods?'<small>'+numberFormat(goods)+' pemberi barang</small>':''));
    tr.lastElementChild.insertAdjacentHTML('beforeend','<button class="edit" data-reception="'+esc(guest.id)+'">Kehadiran & pemberian</button>');
  });
  $('records').querySelectorAll('[data-reception]').forEach(b=>b.onclick=()=>receptionModal(db.guests.find(x=>x.id===b.dataset.reception)));
  if(!$('guest-receipt-summary')){
    const t=C.totals(db),section=document.createElement('div');section.id='guest-receipt-summary';section.className='metrics reception-metrics';section.innerHTML=metric('Hadir tercatat',numberFormat(t.checkedIn),'Nama per orang tercatat','guests')+metric('Uang diterima',money(t.guestCash),'Seluruh pemberian uang','savings')+metric('Pemberi barang',numberFormat(t.guestGoods),'Rincian tersimpan per orang','gifts');$('records').before(section);
    const button=document.createElement('button');button.className='button secondary';button.textContent='Ekspor kehadiran & pemberian';button.onclick=()=>download('kehadiran-dan-pemberian.csv',C.csv(db.guests.flatMap(g=>C.attendance(g).map(p=>({undangan:g.name,acara:g.event,nama_tamu:p.name,jenis:p.kind,uang:p.cash,barang:p.goods})))),'text/csv;charset=utf-8');$('view').querySelector('.toolbar').appendChild(button);
  }
}
function receptionModal(guest){
  const writable=C.can(principal,'guests',true);let people=C.attendance(guest).map(p=>({...p}));
  if(!people.length&&writable)people.push({id:uuid(),name:'',kind:'',cash:0,goods:''});
  function collect(){
    people=[...$('reception-form').querySelectorAll('.attendee-row')].map(row=>({id:row.dataset.personId,name:row.querySelector('[data-person-name]').value.trim(),kind:row.querySelector('[data-person-kind]').value,cash:Number(row.querySelector('[data-person-cash]').value.replace(/\./g,'')||0),goods:row.querySelector('[data-person-goods]').value.trim()}));
  }
  function paint(){
    openModal('Kehadiran & pemberian · '+guest.name,'<p class="subtitle">Kuota '+numberFormat(guest.quota)+' orang. Catat nama setiap orang yang benar-benar hadir dan seluruh pemberiannya. Pilih “Tidak memberi” bila tidak ada pemberian.</p><form id="reception-form"><fieldset '+(!writable?'disabled':'')+' class="reception-fieldset"><div id="attendees">'+people.map((person,i)=>'<article class="attendee-row" data-person-id="'+esc(person.id)+'"><div class="attendee-heading"><strong>Tamu '+(i+1)+'</strong>'+(writable?'<button type="button" class="text-button" data-remove-person="'+i+'">Hapus</button>':'')+'</div><div class="form-grid"><div class="field"><label>Nama tamu *</label><input data-person-name value="'+esc(person.name)+'" maxlength="250" required></div><div class="field"><label>Pemberian *</label><select data-person-kind required>'+['','Uang','Barang','Uang & barang','Tidak memberi'].map(kind=>'<option value="'+kind+'" '+(kind===person.kind?'selected':'')+'>'+(kind||'Pilih pemberian')+'</option>').join('')+'</select></div><div class="field cash-field"><label>Nominal uang (Rp) *</label><input data-person-cash type="number" min="1" max="1000000000000" step="1" value="'+(person.cash||'')+'"></div><div class="field goods-field"><label>Semua barang & jumlahnya *</label><textarea data-person-goods maxlength="3000" placeholder="Contoh: 1 rice cooker; 2 set gelas">'+esc(person.goods)+'</textarea></div></div></article>').join('')+'</div>'+(writable?'<button type="button" class="button secondary" id="add-attendee">'+icon('plus')+'Tambah tamu hadir</button>':'')+'</fieldset><div id="reception-error" role="alert"></div>'+(writable?'<div class="form-actions"><button type="submit" class="button">Simpan kehadiran & pemberian</button></div>':'')+'</form>');
    $('reception-form').querySelectorAll('.attendee-row').forEach(row=>{
      const select=row.querySelector('[data-person-kind]');function toggle(){const cash=['Uang','Uang & barang'].includes(select.value),goods=['Barang','Uang & barang'].includes(select.value);row.querySelector('.cash-field').hidden=!cash;row.querySelector('.goods-field').hidden=!goods;const ci=row.querySelector('[data-person-cash]'),gi=row.querySelector('[data-person-goods]');ci.required=cash;gi.required=goods;if(!cash){ci.value='';ci.setCustomValidity('');}if(!goods)gi.value='';}select.onchange=toggle;toggle();
    });
    $('reception-form').querySelectorAll('[data-remove-person]').forEach(b=>b.onclick=()=>{collect();if(!confirm('Hapus catatan tamu dan pemberiannya?'))return;people.splice(Number(b.dataset.removePerson),1);paint();});
    if($('add-attendee'))$('add-attendee').onclick=()=>{collect();if(people.length>=guest.quota){toast('Kuota tercapai. Ubah kuota pada detail undangan terlebih dahulu.');return;}people.push({id:uuid(),name:'',kind:'',cash:0,goods:''});paint();};
    $('reception-form').onsubmit=async e=>{e.preventDefault();collect();const button=e.currentTarget.querySelector('[type=submit]');button.disabled=true;try{await save({collection:'guests',id:guest.id,version:guest.version,requestId:uuid(),action:'save',data:{...guest,attendanceLedger:JSON.stringify(people)}});$('modal').close();}catch(error){$('reception-error').innerHTML='<div class="error">'+esc(error.message)+'</div>';button.disabled=false;}};
    accountingInputs();
  }paint();
}
function dashboardReception(){
  if(route!=='dashboard'||!principal.owner||!ready)return;
  const t=C.totals(db),section=document.createElement('section');section.className='card reception-dashboard';
  section.innerHTML='<div class="card-head"><div><h2>Keuangan & penerimaan acara</h2><p class="subtitle">Pengeluaran dari pembayaran tercatat · penerimaan dari tamu hadir</p></div><button class="text-button" id="open-reception">Buku tamu</button></div><div class="card-body"><div class="metrics">'+metric('Pengeluaran aktual',money(t.paid),'Invoice melengkapi bukti transaksi','budget')+metric('Pemberian uang',money(t.guestCash),numberFormat(t.checkedIn)+' orang tercatat hadir','savings')+metric('Pemberi barang',numberFormat(t.guestGoods),'Nama & rincian di daftar undangan','gifts')+metric('Selisih kas acara',money(t.netEventCash),'Pemberian uang − pengeluaran','budget')+'</div><div class="line-stat"><span>Invoice / nota terlampir</span><strong>'+numberFormat(db.budget.reduce((s,x)=>s+(x.files||[]).length,0))+' berkas</strong></div></div><div id="expense-list">'+db.budget.map(x=>'<div class="expense-row" data-row-id="'+esc(x.id)+'"><div><strong>'+esc(x.name)+'</strong><small>'+esc(prettyDate(x.date))+' · '+(x.files||[]).length+' lampiran</small></div><div>'+money(C.netPaid(x))+'</div><button class="text-button" data-expense-detail="'+esc(x.id)+'">Detail</button></div>').join('')+(!db.budget.length?'<p class="subtitle empty">Belum ada pengeluaran.</p>':'')+'</div>';
  $('view').querySelector('.quick-actions').before(section);$('open-reception').onclick=()=>go('guests');section.querySelectorAll('[data-expense-detail]').forEach(b=>b.onclick=()=>edit('budget',db.budget.find(x=>x.id===b.dataset.expenseDetail)));
}
const editBeforeExperience=edit;
edit=function(key,record){
  editBeforeExperience(key,record);const form=$('edit-form');if(!form)return;
  if(key==='guests'&&record){const button=document.createElement('button');button.type='button';button.className='button secondary';button.textContent='Catat kehadiran & pemberian';button.onclick=()=>receptionModal(record);form.querySelector('.modal-foot').before(button);}
  if(key!=='budget'||record||!C.can(principal,key,true))return;
  const box=document.createElement('section');box.className='new-budget-proof';box.innerHTML='<label class="paid-now"><input type="checkbox" name="paidNow"> Sudah dibayar lunas — catat sebagai pengeluaran</label><div class="field"><label>Sumber pembayaran</label><select name="initialSource"><option>Dana lain</option><option>Tabungan</option></select></div><div class="field"><label for="new-budget-file">Invoice / nota (opsional)</label><input id="new-budget-file" type="file" accept=".pdf,.jpg,.jpeg,.png"><small>PDF, JPG atau PNG · maksimal 5 MB. Berkas diunggah setelah item biaya tersimpan.</small></div>';
  form.querySelector('.modal-foot').before(box);
  form.querySelector('[name=initialSource]').disabled=true;form.querySelector('[name=paidNow]').onchange=e=>form.querySelector('[name=initialSource]').disabled=!e.target.checked;
  const submit=form.onsubmit;
  form.onsubmit=async event=>{
    const file=$('new-budget-file').files[0];
    if(file&&(file.size>5*1024*1024||! /\.(pdf|jpe?g|png)$/i.test(file.name))){event.preventDefault();$('form-error').innerHTML='<div class="error">Pilih PDF, JPG atau PNG maksimal 5 MB.</div>';return;}
    await submit(event);
    if($('modal').open)return;
    const saved=db.budget.find(x=>x.id===form.dataset.recordId);if(!saved)return;
    edit('budget',saved);
    if(file){const input=$('attachment');const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;await input.onchange({target:input});}
  };
};
const renderBeforeExperience=render;render=function(){renderBeforeExperience();if(ready){guestLedgerSummary();dashboardReception();paginate();polishTables();accountingInputs();}};
const drawRowsBeforeExperience=drawRows;drawRows=function(){drawRowsBeforeExperience();guestLedgerSummary();paginate();polishTables();accountingInputs();};
const drawGiftsBeforeExperience=drawGifts;drawGifts=function(){drawGiftsBeforeExperience();paginate();};
const drawDocsBeforeExperience=drawDocs;drawDocs=function(){drawDocsBeforeExperience();paginate();};

/* Illustrative reception entries belong to the session-only demo. */
const demoBeforeExperience=demo;
demo=function(){const data=demoBeforeExperience();const family=data.guests[0];if(family)family.attendanceLedger=JSON.stringify([{id:'demo-person-one',name:'Siti (contoh)',kind:'Uang',cash:250000,goods:''},{id:'demo-person-two',name:'Budi (contoh)',kind:'Barang',cash:0,goods:'1 set gelas'},{id:'demo-person-three',name:'Rina (contoh)',kind:'Uang & barang',cash:150000,goods:'1 selimut'},{id:'demo-person-four',name:'Dimas (contoh)',kind:'Tidak memberi',cash:0,goods:''}]);return data;};
