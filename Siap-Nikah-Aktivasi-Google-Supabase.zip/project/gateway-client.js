/* Public configuration contains only a project URL and publishable key. */
const gatewayConfig=window.WEDDING_CONFIG||{mode:'preview'};
const usingSupabaseGateway=gatewayConfig.mode==='supabase-gateway'&&!live;
let gatewaySession=null,gatewayRefresh=null;
const gatewaySessionKey='siapnikah-session:'+gatewayConfig.supabaseUrl;
function validateGatewayConfig(){
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(gatewayConfig.supabaseUrl||''))throw new Error('URL project Supabase belum diisi dengan benar.');
  const key=gatewayConfig.supabasePublishableKey||'';
  if(!key||key.startsWith('sb_secret_'))throw new Error('Gunakan publishable / anon key untuk aplikasi.');
  if(!key.startsWith('sb_publishable_')){try{const claims=JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));if(claims.role!=='anon')throw new Error();}catch{throw new Error('Key aplikasi harus publishable atau anon, bukan service_role.');}}
  if(!/^[a-z][a-z0-9-]*$/.test(gatewayConfig.functionName||''))throw new Error('Nama penghubung belum diisi.');
}
function storeGatewaySession(session){gatewaySession=session;try{if(session)sessionStorage.setItem(gatewaySessionKey,JSON.stringify(session));else sessionStorage.removeItem(gatewaySessionKey);}catch{}}
async function gatewayAuth(path,body,token){
  const response=await fetch(gatewayConfig.supabaseUrl+'/auth/v1/'+path,{method:body?'POST':'GET',headers:{apikey:gatewayConfig.supabasePublishableKey,'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(20000)});
  let data;try{data=await response.json();}catch{throw new Error('Layanan login belum tersedia.');}
  if(!response.ok)throw new Error(data.msg||data.error_description||data.message||'Login gagal. Periksa akun dan password.');
  return data;
}
async function gatewayAccessToken(){
  if(!gatewaySession?.access_token)throw new Error('Silakan masuk terlebih dahulu.');
  if(gatewaySession.expires_at>Date.now()/1000+60)return gatewaySession.access_token;
  if(!gatewayRefresh)gatewayRefresh=gatewayAuth('token?grant_type=refresh_token',{refresh_token:gatewaySession.refresh_token}).then(data=>{storeGatewaySession({...data,expires_at:Math.floor(Date.now()/1000)+data.expires_in});return data.access_token;}).catch(error=>{storeGatewaySession(null);throw error;}).finally(()=>gatewayRefresh=null);
  return gatewayRefresh;
}
function gatewayLoginView(message){
  ready=false;db=C.blank();principal={owner:false,email:'',role:'Belum masuk',permissions:{}};email='';status('Belum masuk');
  $('nav').innerHTML='';$('bottom-nav')?.remove();$('mode-banner').innerHTML='';$('crumb').textContent='Masuk';$('avatar').textContent='SN';
  $('view').innerHTML='<div class="login-shell"><section class="card login-card"><div class="login-mark">'+icon('heart')+'</div><p class="login-eyebrow">RUANG PERNIKAHAN KALIAN</p><h1>Siapkan hari bahagia.</h1><p class="subtitle">Masuk untuk membuka rencana, keuangan, dan buku tamu yang tersimpan.</p>'+(message?'<div class="error">'+esc(message)+'</div>':'')+'<form id="gateway-login"><div class="field"><label for="login-email">Email</label><input id="login-email" name="email" type="email" autocomplete="username" required></div><div class="field"><label for="login-password">Password</label><input id="login-password" name="password" type="password" autocomplete="current-password" required></div><div id="login-error" role="alert"></div><button type="submit" class="button">Masuk ke ruang pernikahan</button></form><p class="login-footnote">Gunakan akun yang telah diaktifkan oleh pemilik aplikasi.</p></section></div>';
  $('gateway-login').onsubmit=async event=>{event.preventDefault();const form=event.currentTarget,button=form.querySelector('button');button.disabled=true;try{validateGatewayConfig();const data=await gatewayAuth('token?grant_type=password',Object.fromEntries(new FormData(form)));storeGatewaySession({...data,expires_at:Math.floor(Date.now()/1000)+data.expires_in});form.reset();await reload();}catch(error){if($('login-error'))$('login-error').innerHTML='<div class="error">'+esc(error.message)+'</div>';}finally{if(button.isConnected)button.disabled=false;}};
}
function gatewayAccountButton(){
  let button=$('gateway-signout');if(!button){button=document.createElement('button');button.id='gateway-signout';button.className='text-button';$('view').closest('main').querySelector('.topright').prepend(button);}
  button.textContent=gatewaySession?'Keluar':'Masuk';button.onclick=async()=>{if(busy){toast('Tunggu penyimpanan selesai.');return;}if(gatewaySession){const token=gatewaySession.access_token;storeGatewaySession(null);db=C.blank();localFiles.clear();gatewayLoginView();gatewayAccountButton();try{await gatewayAuth('logout',{},token);}catch{}}else gatewayLoginView();};
}
if(usingSupabaseGateway){
  live=true;principal={owner:false,email:'',role:'Belum masuk',permissions:{}};
  try{validateGatewayConfig();const fragment=new URLSearchParams(location.hash.slice(1));if(fragment.get('access_token')&&fragment.get('refresh_token')){storeGatewaySession({access_token:fragment.get('access_token'),refresh_token:fragment.get('refresh_token'),expires_at:Math.floor(Date.now()/1000)+Number(fragment.get('expires_in')||3600)});history.replaceState(null,'',location.pathname+location.search);}else{const stored=sessionStorage.getItem(gatewaySessionKey);if(stored)gatewaySession=JSON.parse(stored);}}catch{}
  rpc=async function(method,payload){
    validateGatewayConfig();const token=await gatewayAccessToken();
    const response=await fetch(gatewayConfig.supabaseUrl+'/functions/v1/'+gatewayConfig.functionName,{method:'POST',headers:{apikey:gatewayConfig.supabasePublishableKey,Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({method,payload}),signal:AbortSignal.timeout(65000)});
    let data;try{data=await response.json();}catch{throw new Error('Penghubung belum tersedia.');}
    if(!response.ok){if(response.status===401)storeGatewaySession(null);throw new Error(data.error||'Penyimpanan belum berhasil.');}return data;
  };
  const reloadBeforeGateway=reload;reload=async function(){try{validateGatewayConfig();if(!gatewaySession){gatewayLoginView();gatewayAccountButton();return;}await reloadBeforeGateway();gatewayAccountButton();}catch(error){gatewayLoginView(error.message);gatewayAccountButton();}};
  const renderBeforeGateway=render;render=function(){if(!gatewaySession){gatewayLoginView();gatewayAccountButton();return;}renderBeforeGateway();gatewayAccountButton();};
}
