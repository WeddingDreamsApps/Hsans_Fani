/* Presentation helpers preserve all existing handlers and data. */
function polishTables(){
  document.querySelectorAll('.table').forEach(table=>{
    const headers=[...table.querySelectorAll('thead th')].map(th=>th.textContent.trim());
    table.querySelectorAll('tbody tr').forEach(row=>[...row.children].forEach((cell,i)=>cell.setAttribute('data-label',headers[i]||'Tindakan')));
  });
}
const renderBeforePolish=render;
render=function(){renderBeforePolish();polishTables();};
const drawRowsBeforePolish=drawRows;
drawRows=function(){drawRowsBeforePolish();polishTables();};
// Navigation starts at the top of each page, including long KUA lists.
const goBeforePolish=go;
go=function(key){goBeforePolish(key);window.scrollTo({top:0,behavior:'instant'});};

/* Compact accounting presentation. Dates, times, phone numbers and links stay intact. */
function accountingInputs(){
  document.querySelectorAll('input[type="number"]').forEach(input=>{
    input.dataset.accountingInput='true';
    input.dataset.minimum=input.min;input.dataset.maximum=input.max;
    input.type='text';input.inputMode='numeric';
    const raw=()=>input.value.replace(/\./g,'').trim();
    const validate=()=>{const v=raw(),n=Number(v);input.setCustomValidity(v&&(!/^\d+$/.test(v)||!Number.isSafeInteger(n)||(input.dataset.minimum!==''&&n<Number(input.dataset.minimum))||(input.dataset.maximum!==''&&n>Number(input.dataset.maximum)))?'Masukkan angka bulat sesuai batas yang diizinkan.':'');};
    input.addEventListener('focus',()=>{input.value=raw();});
    input.addEventListener('input',validate);
    input.addEventListener('blur',()=>{validate();if(input.value&&input.validity.valid)input.value=numberFormat(Number(raw()));});
    if(input.value)input.value=numberFormat(Number(input.value));
    validate();
  });
  document.querySelectorAll('.table td').forEach(cell=>{if(cell.querySelector('.accounting'))cell.classList.add('numeric-cell');});
}
document.addEventListener('submit',event=>{
  const inputs=[...event.target.querySelectorAll('[data-accounting-input]')];
  inputs.forEach(input=>input.value=input.value.replace(/\./g,''));
  queueMicrotask(()=>inputs.forEach(input=>{if(input.isConnected&&input.value)input.value=numberFormat(Number(input.value));}));
},true);
new MutationObserver(()=>accountingInputs()).observe(document.body,{childList:true,subtree:true});
accountingInputs();
