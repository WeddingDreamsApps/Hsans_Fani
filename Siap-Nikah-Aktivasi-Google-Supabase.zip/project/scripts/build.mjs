import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const core=fs.readFileSync('core.js','utf8');
const enhancements=fs.readFileSync('enhancements.js','utf8');
const styles=fs.readFileSync('enhancements.css','utf8');
const polishCss=fs.readFileSync('polish.css','utf8');
const polishJs=fs.readFileSync('polish.js','utf8');
const experienceJs=fs.readFileSync('experience.js','utf8');
const experienceCss=fs.readFileSync('experience.css','utf8');
const gatewayClient=fs.readFileSync('gateway-client.js','utf8');
const publicConfig=JSON.parse(fs.readFileSync('config.public.json','utf8').replace(/^\uFEFF/,''));
if(publicConfig.supabasePublishableKey){
  const key=publicConfig.supabasePublishableKey;
  if(!key.startsWith('sb_publishable_')){
    let role;try{role=JSON.parse(Buffer.from(key.split('.')[1]||'','base64url').toString('utf8')).role;}catch{}
    if(role!=='anon')throw new Error('Only publishable/anon keys may be embedded in HTML.');
  }
}
const configScript='<script>window.WEDDING_CONFIG='+JSON.stringify(publicConfig).replace(/</g,'\\u003c')+';</script>';
const result=html.replace('<!-- CORE -->',configScript+'<script>\n'+core+'\n</script>').replace('<!-- ENHANCEMENTS -->','<style>\n'+styles+'\n'+polishCss+'\n'+experienceCss+'\n</style><script>\n'+enhancements+'\n'+polishJs+'\n'+experienceJs+'\n'+gatewayClient+'\nreload();\n</script>');
fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/index.html',result);
fs.writeFileSync('apps-script/Index.html',result);fs.writeFileSync('apps-script/Core.gs',core);
console.log('Built preview and Apps Script HTML from the same source.');
