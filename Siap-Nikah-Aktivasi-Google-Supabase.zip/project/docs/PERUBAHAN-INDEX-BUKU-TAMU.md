# Pembaruan index: pengeluaran dan buku tamu

- PDF/JPG/PNG invoice atau nota dapat dipilih ketika membuat item biaya dan dari detail item. Maksimal 5 MB; preview menyimpan lampiran hanya selama sesi.
- Pilihan sudah dibayar lunas mencatat pembayaran awal bersama item biaya. Biaya rencana tetap dapat dibuat tanpa pembayaran. Dashboard menghitung pembayaran bersih, bukan jumlah berkas.
- Buku tamu memisahkan RSVP dari kehadiran aktual. Setiap orang hadir wajib memiliki nama dan pilihan uang/barang/keduanya/tidak memberi. Nominal uang serta seluruh rincian barang dicatat per orang.
- Dashboard menunjukkan pengeluaran aktual, uang tamu, pemberi barang dan selisih kas acara. Penerimaan tamu tidak otomatis menambah ledger tabungan agar tidak dihitung dua kali.
- Daftar data memiliki pilihan 10/25/50/100/semua baris serta navigasi halaman. Ekspor tetap memuat seluruh hasil pencarian. Tersedia ekspor terpisah kehadiran/pemberian.
- Persyaratan yang diminta dihapus dari template KUA. Kartu, tabel, form, dan navigasi tetap padat serta responsif.
- Penyimpanan Google nyata belum diaktifkan. Data dan lampiran dalam index lokal ini hanya untuk pratinjau sesi, dan hilang setelah refresh.
