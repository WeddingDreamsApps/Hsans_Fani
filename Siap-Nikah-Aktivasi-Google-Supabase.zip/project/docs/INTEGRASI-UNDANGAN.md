# Kontrak integrasi web undangan

Versi 0.2 menyediakan URL website pada Data Mempelai/Daftar Undangan, tautan per tamu, draf pesan WhatsApp, status pengiriman terpisah dari RSVP, dan ekspor JSON. Website undangan belum dibuat sehingga belum ada sinkronisasi otomatis.

Tautan yang dihasilkan: URL milik pengguna dengan query `guest=<id>`, `to=<nama>`, `event=<acara>`. Website harus meng-escape nama sebelum menampilkan. ID tamu dan nama **bukan kredensial**; kuota yang dipercaya harus diambil dari backend, bukan query browser.

Ekspor: `schemaVersion`, `generatedAt`, serta array `guests` dengan `guestId`, `name`, `event`, `quota`, `rsvp.status`, `rsvp.attending`, `link`. Kontak dan catatan pribadi tidak dimasukkan. Ekspor ini untuk penghubung aplikasi, bukan diterbitkan sebagai daftar tamu publik.

Tahap sambungan yang harus dibuat bersama web undangan:

1. Endpoint privat server membuat token acak per undangan, menyimpan hash token dan mengizinkan pencabutan. Tautan ID saat ini perlu diganti dengan token tersebut.
2. Endpoint publik token hanya mengembalikan informasi acara dan undangan terkait, tanpa membocorkan tamu lain atau database.
3. RSVP menerima token, status, jumlah hadir, dan idempotency key; memvalidasi kuota dari data server. Simpan melalui penguncian dan audit yang sama.
4. Dashboard mengambil perubahan dari Google setelah respons berhasil. Query nama atau ID tidak memberikan izin untuk mengubah RSVP.
5. Terapkan rate limit, expiry, dan validasi asal. Jangan membuka API administratif Apps Script secara anonim.

Pratinjau saat ini mendemonstrasikan alur tautan/draf dan RSVP manual. Ia tidak menyatakan token publik atau webhook telah diaktifkan.
