# Perubahan index v0.2

9 Oktober 2026.

- Seserahan/mahar: pengelompokan dan subjudul bebas, tab jenis, estimasi per kelompok, status pembayaran serta persiapan terpisah, link belanja HTTPS, dan lampiran.
- KUA: template 18 dokumen/tahapan dari Kemenag, kategori Umum/Bersyarat/Tahapan, checklist ketersediaan terpisah dari status pemeriksaan, tambah template tanpa duplikasi, edit, upload, view, download, ubah nama dan ganti berkas.
- Nota: akses upload invoice/nota langsung dari tabel budget. Berkas pengganti mempertahankan file lama di Drive; aplikasi menaut ke versi baru.
- Undangan: URL web, tautan per tamu, pesan WhatsApp yang dikirim pengguna, status kirim terpisah, dan ekspor kontrak integrasi JSON. Sinkronisasi publik belum aktif karena web undangan belum dibuat.
- Pengguna: peran Pasangan/Koordinator/Panitia/Pembaca, status aktif/nonaktif, akses tidak ada/lihat/ubah per modul, serta pencabutan. Akun utama ditetapkan oleh server, tidak dapat diubah melalui UI anggota. Pratinjau memungkinkan simulasi akun.
- Ponsel: menu bawah Ringkasan, Tugas, Budget, Undangan, Menu; menu terakhir memuat fitur lainnya. Menu desktop tetap sidebar.

## Status koneksi dan pengamanan akses

File `outputs/index.html` adalah pratinjau dengan data contoh dan lampiran di memori sesi, termasuk simulasi role. Refresh menghapus perubahan contoh. Backend Apps Script ikut diperbarui dan memeriksa izin sebelum baca/ubah/unduh; hasil baca difilter di server. Tidak ada perubahan izin Google, spreadsheet, atau file Drive pada pekerjaan ini.

Tetapkan `OWNER_EMAIL` di Script Properties ke akun utama. Fallback untuk instalasi lama adalah email pertama `ALLOWED_EMAILS`. Jalankan `initializeDatabase` lagi untuk menambahkan `SN_Pengguna` tanpa menimpa tabel yang ada.

**Penting untuk deployment panitia:** mode lama Apps Script `USER_ACCESSING` memerlukan izin Google langsung terhadap spreadsheet/folder. Itu tidak memberikan isolasi data jika panitia diberi akses langsung ke sumber. Jangan memberikan akses sumber ke panitia yang seharusnya terbatas. Untuk produksi dengan peran terbatas diperlukan backend yang berjalan dengan izin pemilik serta identitas pengguna yang terverifikasi; Apps Script execute-as-owner hanya boleh dipakai bila identitas aktif tersedia dan tervalidasi untuk lingkungan tersebut (misalnya Workspace dengan kebijakan yang sesuai). Pada identitas kosong kode menolak akses. Login untuk pengguna eksternal Gmail memerlukan integrasi identitas tambahan sebelum diaktifkan. Antarmuka role serta aturan server sudah disiapkan; deployment akses terbatas belum diverifikasi nyata.

Preview PDF/gambar tersedia melalui blob. Word diunduh untuk dibuka/diedit, kemudian diunggah melalui Ganti file. Mengedit nama berkas mengubah label aplikasi, bukan isi dokumen Word/PDF. Pemeriksaan jenis berkas tidak diklaim sebagai antivirus.

## Sumber checklist KUA

- https://kebumen.kemenag.go.id/mau-menikah-ini-syarat-dan-tahapan-pendaftaran-nikah-di-kua-sesuai-pma-30-tahun-2024/
- https://purbalingga.kemenag.go.id/mau-nikah-pahami-dulu-persyaratan-pendaftaran-nikahnya/

Pemisahan dokumen umum dan bersyarat mengikuti rujukan tersebut. Pas foto merupakan petunjuk pelayanan lokal yang perlu dikonfirmasi di KUA tujuan. Daftar tersedia untuk disunting dan bukan keputusan persetujuan KUA.
