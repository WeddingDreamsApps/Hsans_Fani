# Aktivasi Sheets + Drive melalui Supabase

**Status saat ini: kode siap; belum aktif online.** Project `bcqszjdvfswmvesknnks` telah diverifikasi: layanan Auth merespons 200 dan login email aktif. Endpoint `wedding-gateway` masih merespons 404. Email pemilik: `hasanudin.legal@gmail.com`. Deployment Apps Script belum tersedia; SQL belum dijalankan pada server. Pengujian lokal menggunakan layanan tiruan, bukan bukti penulisan ke Google.

Alur: GitHub Pages → Supabase Auth / Edge Function → Apps Script → Google Sheets dan Drive.

Data pernikahan tidak disalin ke PostgreSQL. Script SQL Supabase menyediakan tabel pembatasan permintaan per akun, dengan RLS dan akses hanya dari server. Identitas Supabase diverifikasi server sebelum diteruskan melalui HMAC. Google tetap memeriksa apakah email tersebut pemilik atau anggota aktif beserta izin per modul. Supabase tidak otomatis mempercepat pembacaan Sheets; latensi dan kuota Google tetap berlaku.

## 1. Sambungkan Google sebagai pemilik

Buka spreadsheet tujuan → Ekstensi → Apps Script menggunakan akun pemilik/editor yang juga punya hak membuat berkas pada folder Drive.

Pasang berkas dari folder `apps-script`: `Code.gs`, `Core.gs`, `Gateway.gs`, `Setup.gs`, dan HTML `Index.html` dengan nama editor `Index`. Isi manifest editor dengan `appsscript.gateway.json`, **bukan** manifest lama. Aktifkan layanan Google Sheets API v4.

Cara tercepat: jalankan `setupWeddingOwner` menggunakan `hasanudin.legal@gmail.com`, lalu selesaikan izin Google. Fungsi ini mengisi pemilik, membuat secret acak jika belum ada, menyiapkan tabel, dan mengaktifkan gateway. Secret dapat disalin dari Project Settings → Script properties langsung ke Supabase Secrets; tidak ditampilkan di log. Nilai pemilik berbeda yang sudah ada tidak ditimpa.

Jika menyiapkan manual, di Project Settings → Script properties, isi:

| Properti | Nilai |
|---|---|
| OWNER_EMAIL | Email akun utama aplikasi yang akan login lewat Supabase |
| ALLOWED_EMAILS | Email akun Google yang menjalankan penyiapan awal |
| GATEWAY_SECRET | Nilai acak minimal 32 karakter; hanya di server |

Untuk penyiapan awal, `OWNER_EMAIL` harus cocok dengan email Google pemilik yang menjalankan fungsi. Email login Supabase akun utama harus sama. Anggota lain dapat memakai email berbeda, tetapi harus ditambahkan ke Manajemen Pengguna oleh pemilik.

Buat secret dengan password manager. Gunakan nilai yang sama di Supabase. Jangan memasukkan secret ke index, repository, chat, atau konfigurasi publik.

Jalankan `initializeDatabase` dan selesaikan otorisasi Google. Tab lain dipertahankan; jika struktur tab SN_ tidak kompatibel, script berhenti. Jalankan `enableSupabaseGateway` setelah secret diisi.

Folder Drive harus General access **Restricted**. Panitia memperoleh dokumen melalui aplikasi berdasarkan izin, bukan tautan publik atau akses langsung ke seluruh folder/spreadsheet.

Deploy sebagai Web app: **Execute as Me / pemilik**, akses **Anyone** agar server Supabase dapat memanggilnya. Endpoint menerima hanya request bertanda tangan server; login publik tidak membuka data. Pastikan `GATEWAY_ONLY=true` sebelum deploy. Jika Workspace melarang akses ini, gateway tidak dapat diaktifkan tanpa perubahan kebijakan administrator atau backend Google OAuth lain.

Simpan URL deployment berakhiran `/exec`. Jangan gunakan URL `/dev`. Saat mengganti kode, perbarui versi deployment.

## 2. Pasang Supabase

Gunakan project milik Anda. Di SQL Editor, jalankan `supabase/migrations/202610090001_gateway.sql`.

Buat Edge Function bernama `wedding-gateway`, menggunakan `index.ts` dan `handler.mjs` dalam `supabase/functions/wedding-gateway`. CLI dari folder paket yang berisi direktori supabase:

```sh
supabase login
supabase link --project-ref PROJECT_REF_ANDA
supabase functions deploy wedding-gateway --no-verify-jwt
```

`verify_jwt=false` di konfigurasi fungsi digunakan karena kode sendiri memanggil Supabase Auth `/auth/v1/user` untuk memvalidasi token setiap request. Ini **bukan** akses anonim ke data: bearer token yang tidak valid, email belum terkonfirmasi, dan email yang tidak terdaftar ditolak. Origin aplikasi diperiksa; fungsi SQL pembatasan permintaan hanya bisa dipanggil server.

Di Edge Functions → Secrets, isi:

| Secret | Nilai |
|---|---|
| GOOGLE_APPS_SCRIPT_URL | URL deployment Google `/exec` |
| GATEWAY_SECRET | Nilai yang sama dengan Script properties Google |
| ALLOWED_ORIGINS | `https://weddingdreamsapps.github.io` |

Supabase menyediakan `SUPABASE_URL`, `SUPABASE_ANON_KEY`, dan `SUPABASE_SERVICE_ROLE_KEY` pada runtime fungsi. Service-role key tidak pernah dikirim ke browser. Bila project memakai konfigurasi API baru, isi `SUPABASE_PUBLISHABLE_KEY` pada secrets agar gateway memakainya untuk verifikasi Auth.

Di Authentication, aktifkan email/password. Buat akun utama dengan email yang cocok dengan OWNER_EMAIL; konfirmasi email dan tetapkan password langsung di dashboard/akun. Nonaktifkan pendaftaran umum bila aplikasi hanya untuk keluarga/panitia.

Site URL dan redirect yang diizinkan: `https://weddingdreamsapps.github.io/Hsans_Fani/`. Sebelum panitia login, buat akun Auth mereka dan tambahkan email yang sama ke Manajemen Pengguna dalam aplikasi. Menambahkan anggota di aplikasi tidak otomatis membuat akun Supabase Auth.

## 3. Aktifkan index GitHub

Isi `config.public.json`:

```json
{
  "mode": "supabase-gateway",
  "supabaseUrl": "https://bcqszjdvfswmvesknnks.supabase.co",
  "supabasePublishableKey": "PUBLISHABLE_ATAU_ANON_KEY_ANDA",
  "functionName": "wedding-gateway"
}
```

Hanya URL project dan publishable/anon key yang boleh berada di file ini. Build menolak secret/service_role key.

Dari direktori source project, jalankan `npm run build`. Upload isi `dist/index.html` sebagai `index.html` pada root repository `WeddingDreamsApps/Hsans_Fani`. Index terbaru sudah memakai konfigurasi login project Supabase. Login saja belum mengaktifkan penyimpanan: SQL, Edge Function, dan deployment Google tetap harus dipasang.

GitHub Pages tidak memerlukan file secret, Apps Script, atau SQL untuk disajikan ke browser. Semua kode sumber boleh disimpan di repository, tetapi secret server hanya di dashboard. Akun GitHub Codex saat ini hanya memiliki akses baca; pembaruan langsung memerlukan akses tulis.

## 4. Verifikasi aktivasi nyata

1. Login sebagai akun utama; data awal berasal dari Sheets dan tidak berisi contoh Nadia/Ardi.
2. Isi Data Mempelai, refresh, lalu pastikan data tetap ada dan sesuai spreadsheet.
3. Tambah biaya berstatus dibayar, unggah PDF/JPG/PNG, refresh, buka dan unduh berkas. Pastikan file ada di folder Drive dan dashboard menunjukkan pembayaran tepat sekali.
4. Catat tamu hadir serta uang/barang; refresh dan periksa total dashboard.
5. Login sebagai panitia terbatas; uji bahwa keuangan, KUA, dan manajemen pengguna yang tidak diizinkan ditolak.
6. Request tanpa login atau tanda tangan Google yang benar harus ditolak.

Kegagalan/timeout bukan konfirmasi keberhasilan. Muat ulang untuk memastikan hasil sebelum mengulangi transaksi. Aktivasi dianggap selesai setelah pengujian nyata ini lulus; pengujian lokal saja tidak cukup.

## Rujukan implementasi

- [Supabase: securing Edge Functions](https://supabase.com/docs/guides/functions/auth)
- [Supabase: verifikasi pengguna](https://supabase.com/docs/reference/javascript/auth-getuser)
- [Supabase: Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Google: Content Service dan redirect](https://developers.google.com/apps-script/guides/content)
- [Google: identitas deployment dan akses web app](https://developers.google.com/apps-script/manifest/web-app-api-executable)
