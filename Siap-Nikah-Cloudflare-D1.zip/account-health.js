// Read-only owner check. No password, key or user list is returned to the browser.
(function(){
  const before=usersPage;
  usersPage=function(){
    before();if(!principal.owner)return;
    const bar=document.querySelector('.user-workspace-head');if(!bar)return;
    const button=document.createElement('button');button.className='doc-edit-icon';button.type='button';button.title='Periksa layanan akun';button.setAttribute('aria-label',button.title);button.innerHTML=icon('check');
    button.onclick=async()=>{button.disabled=true;try{const result=await rpc('checkAccountService');toast(result.message);}catch(error){toast(error.message);}finally{button.disabled=false;}};
    bar.append(button);
    const backup=document.createElement('button');backup.type='button';backup.className='doc-edit-icon';backup.title='Cadangkan seluruh data';backup.setAttribute('aria-label',backup.title);backup.innerHTML=icon('download');
    backup.onclick=async()=>{backup.disabled=true;try{const snapshot=await rpc('exportBackup'),url=URL.createObjectURL(new Blob([JSON.stringify(snapshot,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='siap-nikah-cadangan-'+localToday()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('Cadangan data diunduh. Lampiran tetap tersimpan di Drive.');}catch(error){toast(error.message);}finally{backup.disabled=false;}};
    bar.append(backup);
  };
})();
