import C from './core.mjs';
const methods=new Set(['loadData','changeData','uploadAttachment','getAttachment','getUserHistory','changeUserHistory','recordLogin','saveOwnerProfile']);
function actorFor(data,email,owner){
  if(email===owner)return {email,owner:true,role:'Akun utama'};
  const member=data.users.find(x=>x.email===email&&x.status==='Aktif');
  if(!member)throw new Error('Akses akun belum diberikan atau sudah dicabut.');
  return {email,owner:false,role:member.role,permissions:JSON.parse(member.permissions||'{}')};
}
async function digest(text){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(b=>b.toString(16).padStart(2,'0')).join('');}
async function drive(env,email,method,args){
  const endpoint=String(env.GOOGLE_APPS_SCRIPT_URL||'').trim(),secret=String(env.GATEWAY_SECRET||'').trim();
  if(!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(endpoint))throw new Error('Alamat GOOGLE_APPS_SCRIPT_URL di Cloudflare belum valid.');
  if(secret.length<32)throw new Error('GATEWAY_SECRET di Cloudflare kosong atau terlalu pendek. Salin nilai rahasia dari Properti skrip Apps Script, minimal 32 karakter.');
  const payload=JSON.stringify({v:1,timestamp:Date.now(),nonce:crypto.randomUUID(),email,method,args});
  const encoder=new TextEncoder(),key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature=[...new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(payload)))].map(b=>b.toString(16).padStart(2,'0')).join('');
  const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({payload,signature}),redirect:'follow',signal:AbortSignal.timeout(55000)});
  if(!response.ok)throw new Error('Drive belum dapat dihubungi.');
  const result=await response.json();if(result.ok!==true)throw new Error(result.error||'Drive menolak permintaan.');return result.result;
}
export async function handle(request,env){
  const origin=request.headers.get('origin')||'',allowed=(env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim());
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
  if(origin&&allowed.includes(origin))Object.assign(headers,{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS'});
  const reply=(status,value)=>new Response(JSON.stringify(value),{status,headers});
  if(origin&&!allowed.includes(origin))return reply(403,{error:'Alamat aplikasi belum diizinkan.'});
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(request.method!=='POST')return reply(405,{error:'Metode tidak diizinkan.'});
  try{
    if(!env.DB||!env.OWNER_EMAIL||!env.SUPABASE_URL||!env.SUPABASE_PUBLISHABLE_KEY)return reply(503,{error:'Database Cloudflare belum dipasang.'});
    const authorization=request.headers.get('authorization')||'';if(!/^Bearer \S+$/.test(authorization))return reply(401,{error:'Silakan masuk terlebih dahulu.'});
    const auth=await fetch(env.SUPABASE_URL+'/auth/v1/user',{headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,Authorization:authorization},signal:AbortSignal.timeout(10000)});
    if(!auth.ok)return reply(401,{error:'Sesi berakhir. Silakan masuk kembali.'});
    const user=await auth.json();if(!user.id||!user.email_confirmed_at||!user.email)return reply(401,{error:'Email akun belum dikonfirmasi.'});
    const email=user.email.toLowerCase(),minute=Math.floor(Date.now()/60000);
    const limit=await env.DB.prepare('INSERT INTO wedding_limits VALUES(?,?,1) ON CONFLICT(user_id) DO UPDATE SET minute=excluded.minute,requests=CASE WHEN wedding_limits.minute=excluded.minute THEN wedding_limits.requests+1 ELSE 1 END WHERE wedding_limits.minute<>excluded.minute OR wedding_limits.requests<=60 RETURNING requests').bind(user.id,minute).first();
    if(!limit||limit.requests>60)return reply(429,{error:'Terlalu banyak permintaan. Tunggu satu menit.'});
    const raw=await request.text();if(raw.length>7200000)return reply(413,{error:'Berkas maksimal 5 MB.'});
    let input;try{input=JSON.parse(raw);}catch{return reply(400,{error:'Permintaan tidak valid.'});}
    if(!methods.has(input.method))return reply(400,{error:'Metode tidak diizinkan.'});
    const state=await env.DB.prepare('SELECT * FROM wedding_state WHERE id=1').first();if(!state)throw new Error('Schema database belum dipasang.');
    const data=JSON.parse(state.data),actor=actorFor(data,email,env.OWNER_EMAIL.toLowerCase());
    if(input.method==='getUserHistory'){if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat melihat riwayat pengguna.'});return reply(200,{history:(data._userHistory||[]).filter(x=>!x.deleted),ownerProfile:data._ownerProfile||{name:'Akun utama'}});}
    if(['changeUserHistory','recordLogin','saveOwnerProfile'].includes(input.method)){
      if(input.method!=='recordLogin'&&!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mengelola pengguna dan riwayat.'});
      const r=input.payload||{};if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),previous=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();if(previous){if(previous.actor!==email||previous.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{ok:true,duplicate:true});}
      const at=new Date().toISOString();data._userHistory=data._userHistory||[];
      if(input.method==='recordLogin')data._userHistory.push({id:crypto.randomUUID(),email,type:'Login',action:'Masuk ke aplikasi',timestamp:at,notes:'',version:1});
      if(input.method==='saveOwnerProfile'){const name=String(r.name||'').trim();if(!name||name.length>100)throw new Error('Nama wajib diisi, maksimal 100 karakter.');data._ownerProfile={name};data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Mengubah nama akun utama',timestamp:at,notes:'',version:1});}
      if(input.method==='changeUserHistory'){const item=data._userHistory.find(x=>x.id===r.id&&!x.deleted);if(!item||item.version!==r.version)throw new Error('Riwayat berubah. Muat ulang.');if(!['edit','delete'].includes(r.action))throw new Error('Tindakan tidak valid.');if(r.action==='delete')item.deleted=true;else{const notes=String(r.notes||'').trim();if(notes.length>1000)throw new Error('Catatan maksimal 1.000 karakter.');item.notes=notes;}item.version++;item.edited_at=at;data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:r.action==='delete'?'Menghapus riwayat dari tampilan':'Mengedit catatan riwayat',timestamp:at,notes:'',version:1});}
      data._userHistory=data._userHistory.slice(-500);const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,at,state.version).first();if(!saved)return reply(409,{error:'Data berubah. Muat ulang sebelum mencoba lagi.'});return reply(200,{ok:true});
    }
    if(input.method==='loadData')return reply(200,{data:C.visible(data,actor),actor,email,mode:'cloudflare',serverTime:new Date().toISOString()});
    const req=input.payload;if(!req||!Object.hasOwn(C.modules,req.collection)||!C.can(actor,req.collection,input.method!=='getAttachment'))return reply(403,{error:'Anda tidak memiliki izin untuk modul ini.'});
    const record=data[req.collection].find(x=>x.id===req.id);
    if(input.method==='getAttachment'){
      const file=record?.files?.find(x=>x.id===req.fileId);if(!file)throw new Error('Lampiran tidak tersedia.');
      return reply(200,await drive(env,email,'cloudGetFile',{fileId:file.id,name:file.name}));
    }
    if(!/^[\w-]{16,80}$/.test(req.requestId||''))throw new Error('Identitas permintaan tidak valid.');
    const fingerprint=await digest(raw),prior=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(req.requestId).first();
    if(prior){if(prior.actor!==email||prior.fingerprint!==fingerprint)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
    if(req.collection==='users'&&String(req.data?.email||'').toLowerCase()===env.OWNER_EMAIL.toLowerCase())throw new Error('Akun utama tidak dapat diganti.');
    const stamp=new Date().toISOString();
    if(input.method==='changeData')C.mutate(data,req,stamp);
    else{
      if(!record||record.version!==req.version)throw new Error('Catatan berubah. Muat ulang sebelum unggah.');
      if(req.replaceFileId&&!record.files?.some(x=>x.id===req.replaceFileId))throw new Error('Lampiran pengganti tidak tersedia.');
      if((record.files||[]).length>=10&&!req.replaceFileId)throw new Error('Maksimal 10 lampiran.');
      if(req.collection==='budget'&&!['application/pdf','image/jpeg','image/png'].includes(req.mime))throw new Error('Invoice harus PDF, JPG atau PNG.');
      const file=await drive(env,email,'cloudUploadFile',req);
      record.files=[...(record.files||[]).filter(x=>x.id!==req.replaceFileId),file];if(req.collection==='admin')record.available=true;record.version++;record.updated_at=stamp;
    }
    data._userHistory=data._userHistory||[];data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:(input.method==='uploadAttachment'?'Mengunggah lampiran':req.action==='delete'?'Menghapus catatan':'Mengubah catatan')+' · '+C.modules[req.collection].title,timestamp:stamp,notes:'',version:1});data._userHistory=data._userHistory.slice(-500);
    const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai. Ekspor dan arsipkan data lama.');
    const result=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,req.requestId,email,fingerprint,stamp,state.version).first();
    if(!result)return reply(409,{error:'Data berubah saat disimpan. Muat ulang; periksa hasil sebelum mengulangi.'});
    return reply(200,{data:C.visible(data,actor)});
  }catch(error){return reply(400,{error:error.message||'Penyimpanan belum terkonfirmasi.'});}
}
export default {fetch:handle};
