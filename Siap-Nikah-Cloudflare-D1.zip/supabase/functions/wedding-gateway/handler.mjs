export function createGateway({env,fetchImpl=fetch,cryptoImpl=crypto,now=Date.now,uuid=()=>cryptoImpl.randomUUID()}){
  const methods=new Set(['loadData','changeData','uploadAttachment','getAttachment']);
  return async function handler(request){
    const origin=request.headers.get('origin')||'';
    const allowed=(env('ALLOWED_ORIGINS')||'').split(',').map(x=>x.trim()).filter(Boolean);
    const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
    if(origin&&allowed.includes(origin)){headers['Access-Control-Allow-Origin']=origin;headers['Access-Control-Allow-Headers']='authorization, apikey, content-type';headers['Access-Control-Allow-Methods']='POST, OPTIONS';}
    const reply=(status,value)=>new Response(JSON.stringify(value),{status,headers});
    if(origin&&!allowed.includes(origin))return reply(403,{error:'Alamat aplikasi belum diizinkan.'});
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
    if(request.method!=='POST')return reply(405,{error:'Metode tidak diizinkan.'});
    try{
      const base=env('SUPABASE_URL'),publicKey=env('SUPABASE_PUBLISHABLE_KEY')||env('SUPABASE_ANON_KEY'),serverKey=env('SUPABASE_SERVICE_ROLE_KEY'),script=env('GOOGLE_APPS_SCRIPT_URL'),secret=env('GATEWAY_SECRET');
      if(!base||!publicKey||!serverKey||!secret||secret.length<32||!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(script||''))return reply(503,{error:'Penghubung belum dikonfigurasi.'});
      const auth=request.headers.get('authorization')||'';if(!/^Bearer [^\s]+$/.test(auth))return reply(401,{error:'Silakan masuk terlebih dahulu.'});
      const identity=await fetchImpl(base+'/auth/v1/user',{headers:{apikey:publicKey,Authorization:auth},signal:AbortSignal.timeout(10000)});
      if(!identity.ok)return reply(401,{error:'Sesi berakhir. Silakan masuk kembali.'});
      const user=await identity.json();if(!user.id||!user.email||!user.email_confirmed_at)return reply(401,{error:'Email akun belum dikonfirmasi.'});
      const raw=await request.text();if(raw.length>7200000)return reply(413,{error:'Berkas maksimal 5 MB.'});
      let input;try{input=JSON.parse(raw);}catch{return reply(400,{error:'Permintaan tidak valid.'});}
      if(!input||!methods.has(input.method))return reply(400,{error:'Metode tidak diizinkan.'});
      const limit=await fetchImpl(base+'/rest/v1/rpc/claim_wedding_gateway_request',{method:'POST',headers:{apikey:serverKey,Authorization:'Bearer '+serverKey,'Content-Type':'application/json'},body:JSON.stringify({p_user:user.id}),signal:AbortSignal.timeout(10000)});
      if(!limit.ok)return reply(503,{error:'Script Supabase belum dipasang atau tidak tersedia.'});
      if(await limit.json()!==true)return reply(429,{error:'Terlalu banyak permintaan. Tunggu satu menit.'});
      const payload=JSON.stringify({v:1,timestamp:now(),nonce:uuid(),email:user.email.toLowerCase(),method:input.method,args:input.payload});
      const encoder=new TextEncoder(),key=await cryptoImpl.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
      const bytes=new Uint8Array(await cryptoImpl.subtle.sign('HMAC',key,encoder.encode(payload))),signature=[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
      const upstream=await fetchImpl(script,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({payload,signature}),redirect:'follow',signal:AbortSignal.timeout(55000)});
      if(!upstream.ok)return reply(502,{error:'Google belum dapat dihubungi.'});
      let response;try{response=await upstream.json();}catch{return reply(502,{error:'Deployment Apps Script belum menghasilkan respons JSON. Periksa akses dan versi deployment.'});}
      if(response.ok!==true)return reply(400,{error:response.error||'Google menolak permintaan.'});
      return reply(200,response.result);
    }catch{return reply(503,{error:'Koneksi belum berhasil. Periksa hasil penyimpanan sebelum mengulangi transaksi.'});}
  };
}
