import { createGateway } from './handler.mjs';
Deno.serve(createGateway({ env: (name) => Deno.env.get(name) }));
