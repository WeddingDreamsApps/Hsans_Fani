-- Supabase is the authentication/gateway layer. Wedding data stays in Google Sheets.
begin;
create table if not exists public.wedding_gateway_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  window_start timestamptz not null,
  requests integer not null check (requests > 0)
);
alter table public.wedding_gateway_limits enable row level security;
revoke all on public.wedding_gateway_limits from public, anon, authenticated;
grant select, insert, update, delete on public.wedding_gateway_limits to service_role;
create or replace function public.claim_wedding_gateway_request(p_user uuid)
returns boolean language plpgsql security definer set search_path = '' as $$
declare used integer;
begin
  if p_user is null then return false; end if;
  insert into public.wedding_gateway_limits as limits(user_id, window_start, requests)
  values(p_user, pg_catalog.now(), 1)
  on conflict(user_id) do update set
    requests = case when limits.window_start <= pg_catalog.now() - interval '1 minute' then 1 else limits.requests + 1 end,
    window_start = case when limits.window_start <= pg_catalog.now() - interval '1 minute' then pg_catalog.now() else limits.window_start end
  returning requests into used;
  return used <= 60;
end;
$$;
revoke all on function public.claim_wedding_gateway_request(uuid) from public, anon, authenticated;
grant execute on function public.claim_wedding_gateway_request(uuid) to service_role;
commit;
