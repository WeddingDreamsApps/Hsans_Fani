/* Feature expansion v0.2. Preview remains session-only; live access is checked server-side. */
const KUA_SOURCE='https://kebumen.kemenag.go.id/mau-menikah-ini-syarat-dan-tahapan-pendaftaran-nikah-di-kua-sesuai-pma-30-tahun-2024/';
const KUA_PHOTO_SOURCE='https://purbalingga.kemenag.go.id/mau-nikah-pahami-dulu-persyaratan-pendaftaran-nikahnya/';
const KUA_REQUIREMENTS=[
  ['Surat pengantar nikah desa / kelurahan','Umum','Dari tempat tinggal calon pengantin.'],
  ['Fotokopi akta kelahiran','Umum','Siapkan untuk kedua calon pengantin.'],
  ['Fotokopi KTP','Umum','Identitas kedua calon pengantin.'],
  ['Fotokopi Kartu Keluarga','Umum','Pastikan identitas sesuai dokumen lain.'],
  ['Surat keterangan sehat','Umum','Dari Puskesmas atau fasilitas kesehatan.'],
  ['Persetujuan kedua calon pengantin','Umum','Siapkan formulir sesuai petunjuk KUA.'],
  ['Pas foto calon pengantin','Umum','Rujukan Purbalingga: latar biru, 4×6 dan 2×3 masing-masing 2 lembar. Konfirmasi ukuran/jumlah ke KUA tujuan.'],
  ['Rekomendasi nikah KUA asal','Bersyarat','Jika menikah di luar kecamatan domisili.'],
  ['Izin tertulis orang tua / wali','Bersyarat','Untuk calon pengantin di bawah 21 tahun.'],
  ['Dispensasi kawin pengadilan','Bersyarat','Untuk calon pengantin di bawah 19 tahun saat akad.'],
  ['Izin atasan / kesatuan','Bersyarat','Untuk anggota TNI atau Polri.'],
  ['Akta cerai','Bersyarat','Untuk duda / janda karena perceraian.'],
  ['Akta kematian pasangan','Bersyarat','Untuk duda / janda karena pasangan meninggal.'],
  ['Dokumen keterlambatan pendaftaran','Bersyarat','Jika kurang dari 10 hari kerja: dispensasi camat atau pernyataan bermeterai beserta alasan. Konfirmasi ke KUA.'],
  ['Pendaftaran kehendak nikah','Tahapan','Rencanakan paling lambat 10 hari kerja sebelum akad.'],
  ['Bimbingan perkawinan','Tahapan','Ikuti jadwal dan simpan bukti / sertifikat.'],
  ['Pemeriksaan nikah di KUA','Tahapan','Hadir bersama calon pasangan dan wali sesuai jadwal.']
];
const PAYMENT_STATES=['Belum dibayar','Proses pembayaran','DP / sebagian','Lunas','Hadiah / tanpa biaya'];
const GROUPS=['Perlengkapan ibadah','Busana & sepatu','Perawatan & kosmetik','Perhiasan','Tas & aksesori','Makanan & buah','Mahar','Lainnya'];
const ROLE_DEFAULTS={
  Pasangan:{profile:'read',budget:'write',savings:'write',gifts:'write',vendors:'write',admin:'write',guests:'write',tasks:'write',rundown:'write'},
  Koordinator:{vendors:'read',guests:'write',tasks:'write',rundown:'write'},
  Panitia:{tasks:'write',rundown:'read'},
  Pembaca:{tasks:'read',rundown:'read'}
};
const localFiles=new Map();let giftsType='Semua',adminType='Semua';
ICONS.users=ICONS.profile;
Object.assign(labels,{itemGroup:'Kelompok / subjudul',paymentStatus:'Status pembayaran',shopUrl:'Link belanja e-commerce',requirementType:'Jenis persyaratan',available:'Dokumen sudah tersedia',deliveryStatus:'Status pengiriman',address:'Alamat',email:'Email akun Google',role:'Peran',permissions:'Akses modul',invitationUrl:'URL web undangan (HTTPS)'});
const baseDemo=demo;
demo=function(){
  const data=baseDemo();
  data.gifts=[
    {id:'demo-gift',version:1,name:'Perlengkapan salat',type:'Seserahan',itemGroup:'Perlengkapan ibadah',quantity:1,amount:850000,paymentStatus:'Lunas',status:'Disiapkan',shopUrl:'https://www.tokopedia.com/search?q=perlengkapan%20salat',owner:'Ardi'},
    {id:'demo-gift2',version:1,name:'Sepatu pilihan',type:'Seserahan',itemGroup:'Busana & sepatu',quantity:1,amount:700000,paymentStatus:'Proses pembayaran',status:'Direncanakan',shopUrl:'https://shopee.co.id/search?keyword=sepatu',owner:'Nadia'},
    {id:'demo-gift3',version:1,name:'Mahar emas 5 gram',type:'Mahar',itemGroup:'Mahar',quantity:1,amount:0,paymentStatus:'Belum dibayar',status:'Direncanakan',owner:'Ardi',notes:'Isi nominal sesuai harga pembelian; ini bukan informasi harga emas.'}
  ];
  data.admin=KUA_REQUIREMENTS.map((item,i)=>({id:'kua-template-'+i,version:1,name:item[0],requirementType:item[1],available:i<2,owner:'Kedua mempelai',status:i<2?'Disiapkan':'Belum disiapkan',source:i===6?KUA_PHOTO_SOURCE:KUA_SOURCE,notes:item[2],date:''}));
  data.users=[{id:'demo-user-one',version:1,name:'Koordinator acara',email:'koordinator@contoh.test',role:'Koordinator',status:'Aktif',permissions:JSON.stringify(ROLE_DEFAULTS.Koordinator)},{id:'demo-user-two',version:1,name:'Panitia penerima tamu',email:'panitia@contoh.test',role:'Panitia',status:'Aktif',permissions:JSON.stringify(ROLE_DEFAULTS.Panitia)}];
  data.guests.forEach(x=>{x.deliveryStatus='Belum dikirim';x.address='';});
  return data;
};
const baseSave=save;
save=async function(req){if(!C.can(principal,req.collection,true))throw new Error('Hanya pengguna yang memiliki izin ubah boleh menyimpan.');return baseSave(req);};
const baseRender=render;
render=function(){
  if(route!=='dashboard'&&route!=='more'&&!C.can(principal,route,false))route='dashboard';
  if(route==='more'){route='dashboard';baseRender();route='more';}else baseRender();
  $('nav').querySelectorAll('[data-route]').forEach(b=>{if(b.dataset.route!=='dashboard'&&!C.can(principal,b.dataset.route,false))b.remove();});
  if(!live){
    const banner=$('mode-banner').querySelector('.banner');if(banner){
      const wrap=document.createElement('label');wrap.className='preview-switch';wrap.innerHTML='Simulasi akun <select id="preview-role" aria-label="Simulasi akses akun"><option value="owner">Akun utama</option>'+db.users.filter(u=>u.status==='Aktif').map(u=>'<option value="'+esc(u.id)+'" '+(principal.email===u.email?'selected':'')+'>'+esc(u.name)+'</option>').join('')+'</select>';banner.appendChild(wrap);
      $('preview-role').onchange=e=>{const u=db.users.find(x=>x.id===e.target.value);principal=u?{owner:false,email:u.email,role:u.role,permissions:JSON.parse(u.permissions)}:{owner:true,email:'utama@contoh.test',role:'Akun utama'};go('dashboard');};
    }
  }
  if(!principal.owner&&ready&&route==='dashboard')operationalDashboard();
  if(ready&&route==='more')moreMenu();
  if(ready&&!C.can(principal,route,true)&&!['dashboard','more'].includes(route)){
    $('view').querySelectorAll('#add-record,#add-task,#empty-add,button[type="submit"]').forEach(b=>b.remove());
    if(route==='profile')$('profile-form')?.querySelectorAll('input,textarea').forEach(e=>e.disabled=true);
  }
  if(!C.can(principal,'profile',false))$('avatar').textContent=principal.role==='Panitia'?'PN':'KO';
  mobileNav();
};
function mobileNav(){
  let nav=$('bottom-nav');if(!nav){nav=document.createElement('nav');nav.id='bottom-nav';nav.className='bottom-nav';nav.setAttribute('aria-label','Navigasi ponsel');document.body.appendChild(nav);}
  const keys=[['dashboard','Ringkasan'],['tasks','Tugas'],['budget','Budget'],['guests','Undangan'],['more','Menu']];
  nav.innerHTML=keys.map(([k,label])=>'<button data-bottom="'+k+'" class="'+(route===k?'active':'')+'" '+(route===k?'aria-current="page"':'')+'>'+icon(k==='more'?'menu':k)+'<span>'+label+'</span></button>').join('');
  nav.querySelectorAll('button').forEach(b=>{const k=b.dataset.bottom;if(k!=='more'&&k!=='dashboard'&&!C.can(principal,k,false)){b.disabled=true;b.style.opacity='.35';}b.onclick=()=>go(k);});
}
function moreMenu(){
  $('crumb').textContent='Semua menu';$('view').innerHTML='<div class="page-head"><div><h1>Semua menu</h1><p class="subtitle">'+esc(principal.role)+' · '+esc(principal.email||email)+'</p></div></div><div class="menu-grid">'+Object.entries(C.modules).filter(([k])=>C.can(principal,k,false)).map(([k,v])=>'<button data-menu="'+k+'">'+icon(k)+'<span>'+esc(v.title)+'</span></button>').join('')+'</div>';
  $('view').querySelectorAll('[data-menu]').forEach(b=>b.onclick=()=>go(b.dataset.menu));
}
function operationalDashboard(){
  const keys=Object.keys(C.modules).filter(k=>k!=='users'&&C.can(principal,k,false));
  $('view').innerHTML='<div class="page-head"><div><h1>Ruang panitia</h1><p class="subtitle">'+esc(principal.role)+' · '+esc(principal.email)+'</p></div></div><div class="role-alert">Menu yang tersedia mengikuti izin dari akun utama.</div><div class="menu-grid">'+keys.map(k=>'<button data-menu="'+k+'">'+icon(k)+esc(C.modules[k].title)+'</button>').join('')+'</div>';
  $('view').querySelectorAll('[data-menu]').forEach(b=>b.onclick=()=>go(b.dataset.menu));
}
const baseListing=listing;
listing=function(){if(route==='gifts')giftsPage();else if(route==='admin')adminPage();else if(route==='users')usersPage();else{baseListing();if(route==='guests')enhanceGuests();if(route==='budget')enhanceBudget();}};
fields=function(key,record={}){
  return C.modules[key].fields.filter(f=>!['permissions','attendanceLedger'].includes(f)).map(f=>{
    let vals=f==='status'?C.statuses[key]:choices[f];if(f==='type')vals=key==='savings'?['Setoran','Penarikan']:['Seserahan','Mahar'];if(f==='paymentStatus')vals=PAYMENT_STATES;if(f==='requirementType')vals=['Umum','Bersyarat','Tahapan'];if(f==='deliveryStatus')vals=['Belum dikirim','Dikirim','Dibuka'];if(f==='role')vals=Object.keys(ROLE_DEFAULTS);
    const v=record[f]??(['quota','quantity'].includes(f)?1:undefined),required=f==='name'||(key==='users'&&f==='email')||(key==='rundown'&&['start','end'].includes(f));
    const type=['amount','budget','target','quota','attending','capacity','quantity'].includes(f)?'number':f==='date'?'date':['start','end'].includes(f)?'datetime-local':f==='email'?'email':f.endsWith('Url')||f==='source'?'url':'text';
    if(f==='available')return '<div class="field full"><label class="checkbox-label"><input type="checkbox" name="available" '+(record.available?'checked':'')+'>Dokumen / langkah ini sudah tersedia atau selesai disiapkan</label></div>';
    return '<div class="field '+(f==='notes'?'full':'')+'"><label for="field-'+f+'">'+esc(labels[f])+(required?' *':'')+'</label>'+(vals?'<select id="field-'+f+'" name="'+f+'">'+vals.map(o=>'<option '+(v===o?'selected':'')+'>'+esc(o)+'</option>').join('')+'</select>':(f==='notes'?'<textarea id="field-notes" name="notes" maxlength="3000">'+esc(v)+'</textarea>':'<input id="field-'+f+'" name="'+f+'" type="'+type+'" value="'+esc(v)+'" '+(required?'required':'')+(type==='number'?' min="0" max="1000000000000" step="1"':' maxlength="'+(type==='url'?1000:250)+'"')+(f==='itemGroup'?' list="group-suggestions"':'')+'>'))+(f==='itemGroup'?'<datalist id="group-suggestions">'+GROUPS.map(g=>'<option>'+g+'</option>').join('')+'</datalist>':'')+'</div>';
  }).join('');
};
function pageHead(title,subtitle,actions){document.querySelector('.topbar>.page-head')?.remove();return '<div class="page-head"><div><h1>'+title+'</h1><p class="subtitle">'+subtitle+'</p></div>'+actions+'</div>';}
function basicToolbar(){return '<div class="toolbar"><div class="search">'+icon('search')+'<input id="search" placeholder="Cari catatan…" aria-label="Cari catatan" value="'+esc(search)+'"></div><button class="button secondary" id="export">'+icon('download')+'Ekspor CSV</button></div>';}
function wireToolbar(draw){$('search').oninput=e=>{search=e.target.value;draw();};$('export').onclick=()=>download(route+'.csv',C.csv(db[route]),'text/csv;charset=utf-8');}
function giftsPage(){
  const rows=db.gifts,t=rows.reduce((s,r)=>s+r.amount,0),done=rows.filter(x=>['Lunas','Hadiah / tanpa biaya'].includes(x.paymentStatus)).length;
  $('view').innerHTML=pageHead('Seserahan & Mahar','Pisahkan kelompok barang, progres persiapan, dan status pembayarannya.','<button class="button" id="add-record">'+icon('plus')+'Tambah barang</button>')+'<div class="metrics">'+metric('Barang',numberFormat(rows.length),'Dalam '+new Set(rows.map(r=>r.itemGroup||'Lainnya')).size+' kelompok','gifts')+metric('Estimasi barang',money(t),'Tidak dihitung otomatis sebagai pengeluaran','budget')+metric('Pembayaran selesai',numberFormat(done)+' / '+numberFormat(rows.length),'Lunas atau hadiah tanpa biaya','check')+'</div><div class="segmented" id="gift-tabs">'+['Semua','Seserahan','Mahar'].map(x=>'<button data-type="'+x+'" class="'+(giftsType===x?'selected':'')+'">'+x+'</button>').join('')+'</div>'+basicToolbar()+'<div id="gift-groups"></div>';
  $('add-record').onclick=()=>edit('gifts');$('gift-tabs').querySelectorAll('button').forEach(b=>b.onclick=()=>{giftsType=b.dataset.type;giftsPage();});wireToolbar(drawGifts);drawGifts();
}
function drawGifts(){
  const rows=db.gifts.filter(x=>(giftsType==='Semua'||x.type===giftsType)&&(!search||[x.name,x.itemGroup,x.owner].join(' ').toLowerCase().includes(search.toLowerCase())));
  const groups=[...new Set(rows.map(x=>x.itemGroup||'Lainnya'))];
  $('gift-groups').innerHTML=groups.map(g=>{const items=rows.filter(x=>(x.itemGroup||'Lainnya')===g);return '<div class="group-header"><h2>'+esc(g)+'</h2><p>'+numberFormat(items.length)+' barang · '+money(items.reduce((s,x)=>s+x.amount,0))+'</p></div><div class="item-grid">'+items.map(x=>'<article class="card gift-card"><div class="gift-title"><div><h3>'+esc(x.name)+'</h3>'+badge(x.type)+'</div><span class="attachment-counter">'+(x.files||[]).length+' lampiran</span></div><div class="gift-price">'+money(x.amount)+'</div><p class="gift-meta">'+numberFormat(x.quantity)+' item · '+esc(x.owner||'Belum ada PIC')+'</p><div class="gift-controls"><div><label for="pay-'+x.id+'">Pembayaran</label><select id="pay-'+x.id+'" data-gift="'+esc(x.id)+'" data-field="paymentStatus" '+(!C.can(principal,'gifts',true)?'disabled':'')+'>'+PAYMENT_STATES.map(s=>'<option '+((x.paymentStatus||'Belum dibayar')===s?'selected':'')+'>'+s+'</option>').join('')+'</select></div><div><label for="prep-'+x.id+'">Persiapan</label><select id="prep-'+x.id+'" data-gift="'+esc(x.id)+'" data-field="status" '+(!C.can(principal,'gifts',true)?'disabled':'')+'>'+C.statuses.gifts.map(s=>'<option '+(x.status===s?'selected':'')+'>'+s+'</option>').join('')+'</select></div></div><div class="card-buttons"><button class="button secondary" data-edit-gift="'+esc(x.id)+'">Detail & lampiran</button>'+(x.shopUrl?'<a class="button subtle" href="'+esc(x.shopUrl)+'" target="_blank" rel="noopener noreferrer">Buka link belanja</a>':'')+'</div></article>').join('')+'</div>';}).join('')||'<div class="card empty"><h3>Belum ada barang</h3><p>Tambahkan kelompok dan barang untuk seserahan atau mahar.</p></div>';
  document.querySelectorAll('[data-edit-gift]').forEach(b=>b.onclick=()=>edit('gifts',db.gifts.find(r=>r.id===b.dataset.editGift)));
  document.querySelectorAll('[data-gift]').forEach(s=>s.onchange=async()=>{const x=db.gifts.find(r=>r.id===s.dataset.gift);s.disabled=true;try{await save({collection:'gifts',id:x.id,version:x.version,requestId:uuid(),action:'save',data:{...x,[s.dataset.field]:s.value}});}catch(e){toast(e.message);drawGifts();}});
}
function adminPage(){
  const applicable=db.admin.filter(x=>x.status!=='Tidak berlaku'),done=applicable.filter(x=>x.available).length;
  $('view').innerHTML=pageHead('Peta Persiapan','Checklist dokumen dan tahapan pendaftaran nikah.','<button class="button" id="add-record">'+icon('plus')+'Tambah</button>')+'<div class="metrics">'+metric('Kesiapan dokumen',numberFormat(done)+' / '+numberFormat(applicable.length),'Tidak berlaku dikecualikan dari hitungan','admin',applicable.length?done/applicable.length*100:0)+metric('Lampiran',db.admin.reduce((s,x)=>s+(x.files||[]).length,0),'Berkas privat di Google Drive saat aktif','download')+'</div><div class="notice">Persyaratan bersyarat dipakai hanya jika sesuai kondisi kalian. Checklist “tersedia” tidak berarti dokumen telah disetujui KUA. Konfirmasi persyaratan dan format berkas ke KUA tujuan.</div><div class="segmented" id="admin-tabs">'+['Semua','Umum','Bersyarat','Tahapan'].map(x=>'<button data-admin-type="'+x+'" class="'+(adminType===x?'selected':'')+'">'+x+'</button>').join('')+'<button id="load-kua-template">Tambah dari daftar persyaratan</button></div>'+basicToolbar()+'<div class="doc-list" id="docs"></div><div class="sources">Rujukan: <a href="'+KUA_SOURCE+'" target="_blank" rel="noopener">Kemenag Kebumen — PMA 30/2024</a> · <a href="'+KUA_PHOTO_SOURCE+'" target="_blank" rel="noopener">Kemenag Purbalingga — dokumen & pas foto</a><br>Diperiksa 9 Oktober 2026. Ukuran pas foto perlu dikonfirmasi ke KUA tujuan.</div>';
  $('add-record').onclick=()=>edit('admin');$('admin-tabs').querySelectorAll('[data-admin-type]').forEach(b=>b.onclick=()=>{adminType=b.dataset.adminType;adminPage();});$('load-kua-template').onclick=templateModal;if(!C.can(principal,'admin',true))$('load-kua-template').remove();wireToolbar(drawDocs);drawDocs();
}
function drawDocs(){const rows=db.admin.filter(x=>(typeof prepVisibleDoc!=='function'||prepVisibleDoc(x))&&(adminType==='Semua'||(x.requirementType||'Umum')===adminType)&&(!search||[x.name,x.notes,x.owner].join(' ').toLowerCase().includes(search.toLowerCase())));
  $('docs').innerHTML=rows.map(x=>'<article class="card doc-row"><button class="check '+(x.available?'done':'')+'" data-doc-check="'+esc(x.id)+'" aria-label="Tandai '+esc(x.name)+' tersedia" aria-pressed="'+!!x.available+'" '+(!C.can(principal,'admin',true)?'disabled':'')+'>'+(x.available?icon('check'):'')+'</button><div class="doc-description"><h3>'+esc(x.name)+'</h3><p>'+esc(x.notes)+'</p><div class="doc-tags">'+badge(x.requirementType||'Umum')+badge(x.status)+'<span class="attachment-counter">'+(x.available?'✓ Sudah tersedia':'Belum tersedia')+' · '+(x.files||[]).length+' berkas</span></div><p>'+esc(x.owner||'Belum ada PIC')+(x.date?' · '+esc(prettyDate(x.date)):'')+'</p><div class="doc-attachments">'+(x.files||[]).map(f=>'<button class="doc-attachment" data-doc-file="'+esc(f.id)+'" data-doc-record="'+esc(x.id)+'" title="Lihat lampiran: '+esc(f.name)+'">'+icon('attach')+'<span>'+esc(f.name)+'</span></button>').join('')+'</div></div><div class="doc-actions"><button class="doc-edit-icon" data-doc-edit="'+esc(x.id)+'" aria-label="'+(C.can(principal,'admin',true)?'Edit ':'Lihat ')+esc(x.name)+'" title="'+(C.can(principal,'admin',true)?'Edit dokumen':'Lihat dokumen')+'">'+icon(C.can(principal,'admin',true)?'edit':'admin')+'</button></div></article>').join('')||'<div class="card empty"><h3>Belum ada persyaratan</h3><p>Tambahkan daftar persyaratan resmi melalui tombol di atas.</p></div>';
  document.querySelectorAll('[data-doc-edit]').forEach(b=>b.onclick=()=>edit('admin',db.admin.find(x=>x.id===b.dataset.docEdit)));
  document.querySelectorAll('[data-doc-file]').forEach(b=>b.onclick=()=>{const x=db.admin.find(r=>r.id===b.dataset.docRecord);if(x)openFile('admin',x,b.dataset.docFile,false);});
  document.querySelectorAll('[data-doc-check]').forEach(b=>b.onclick=async()=>{const x=db.admin.find(r=>r.id===b.dataset.docCheck);try{await save({collection:'admin',id:x.id,version:x.version,requestId:uuid(),action:'save',data:{...x,available:!x.available,status:!x.available&&x.status==='Belum disiapkan'?'Disiapkan':x.status}});}catch(e){toast(e.message);}});
}
function templateModal(){if(!C.can(principal,'admin',true))return;
  const missing=KUA_REQUIREMENTS.map((x,i)=>({x,i})).filter(({x})=>!db.admin.some(r=>r.name===x[0]));
  openModal('Pilih persyaratan yang berlaku','<p class="muted" style="font-size:14px">Dokumen yang sudah ada tidak ditambahkan lagi. Pilih persyaratan bersyarat sesuai kebutuhan.</p><div class="template-list">'+missing.map(({x,i})=>'<label><input type="checkbox" data-template="'+i+'" '+(x[1]!=='Bersyarat'?'checked':'')+'><span>'+esc(x[0])+'<small>'+esc(x[1])+' · '+esc(x[2])+'</small></span></label>').join('')+'</div><div id="template-error" role="alert"></div><button class="button" id="add-template" '+(!missing.length?'disabled':'')+'>Tambahkan yang dipilih</button>');
  $('add-template').onclick=async()=>{const selected=[...document.querySelectorAll('[data-template]:checked')].map(x=>Number(x.dataset.template));const b=$('add-template');b.disabled=true;try{for(const i of selected){const x=KUA_REQUIREMENTS[i];await save({collection:'admin',id:'kua-template-'+i,version:0,action:'save',requestId:uuid(),data:{name:x[0],requirementType:x[1],available:false,status:'Belum disiapkan',owner:'Kedua mempelai',source:i===6?KUA_PHOTO_SOURCE:KUA_SOURCE,notes:x[2]}});}$('modal').close();}catch(e){$('template-error').innerHTML='<div class="error">'+esc(e.message)+'</div>';b.disabled=false;}};
}
function userPermissions(record){let permissions;try{permissions=JSON.parse(record.permissions||'{}');}catch(e){permissions={};}return permissions;}
function usersPage(){
  $('view').innerHTML=pageHead('Manajemen Pengguna','Hanya akun utama yang dapat mengatur anggota dan akses modul.','<button class="button" id="add-record">'+icon('plus')+'Tambah pengguna</button>')+'<div class="notice">Izin dibagi menjadi Tanpa akses, Lihat, dan Ubah. Modul keuangan serta dokumen KUA tertutup secara default untuk panitia.</div><div class="item-grid"><article class="card user-card"><span class="role-chip">Akun utama</span><h3>Pemilik ruang pernikahan</h3><p>'+esc(principal.email||email)+'</p><div class="user-access"><span>Seluruh modul</span><span>Kelola pengguna</span></div><p>Akun utama ditetapkan pada konfigurasi server dan tidak dapat diganti oleh panitia.</p></article>'+db.users.map(x=>{const perms=userPermissions(x);return '<article class="card user-card"><div class="gift-title"><span class="role-chip">'+esc(x.role)+'</span>'+badge(x.status)+'</div><h3>'+esc(x.name)+'</h3><p>'+esc(x.email)+'</p><div class="user-access">'+Object.entries(perms).filter(([,v])=>v!=='none').map(([k,v])=>'<span>'+esc(C.modules[k]?.title||k)+' · '+(v==='write'?'ubah':'lihat')+'</span>').join('')+'</div><button class="button secondary" data-user="'+esc(x.id)+'">Atur akses</button></article>';}).join('')+'</div>';
  $('add-record').onclick=()=>edit('users');document.querySelectorAll('[data-user]').forEach(b=>b.onclick=()=>edit('users',db.users.find(x=>x.id===b.dataset.user)));
}
function permissionFields(record){const p=userPermissions(record);return '<div class="field full"><h3>Akses per modul</h3><div class="permission-table">'+Object.entries(C.modules).filter(([k])=>k!=='users').map(([k,v])=>'<label class="permission-row"><span>'+esc(v.title)+'</span><select name="perm-'+k+'" data-permission="'+k+'">'+[['none','Tanpa akses'],['read','Lihat'],['write','Ubah']].map(([value,label])=>'<option value="'+value+'" '+((p[k]||'none')===value?'selected':'')+'>'+label+'</option>').join('')+'</select></label>').join('')+'</div></div>';}
function enhanceGuests(){document.querySelector('#view>.metrics')?.classList.add('guest-three-metrics');}

const baseDrawRows=drawRows;
drawRows=function(){baseDrawRows();if(route==='guests'&&$('invitation-base')){const existing=$('view').querySelector('.invitation-config');existing?.remove();enhanceGuests();}};
function invitationLink(x){const base=db.profile[0]?.invitationUrl;if(!base)return '';try{const url=new URL(base);if(url.protocol!=='https:')return '';url.searchParams.set('guest',x.id);url.searchParams.set('to',x.name);url.searchParams.set('event',x.event);return url.href;}catch(e){return '';}}
function invitationModal(x){const link=invitationLink(x),message='Yth. '+x.name+'\n\nKami mengundang Bapak/Ibu/Saudara/i untuk menghadiri pernikahan '+(db.profile[0]?.name||'kami')+' & '+(db.profile[0]?.partner||'pasangan')+'.\nAcara: '+x.event+'\n'+(link?'Informasi dan konfirmasi kehadiran:\n'+link:'Tautan undangan akan menyusul.')+'\n\nTerima kasih.';
  let phone=String(x.contact||'').replace(/\D/g,'');if(phone.startsWith('0'))phone='62'+phone.slice(1);
  openModal('Undangan · '+x.name,'<div class="invitation-preview"><p>'+esc(message)+'</p></div><div class="field"><label>Tautan khusus tamu</label><input readonly class="link-input" value="'+esc(link)+'" placeholder="Atur URL web undangan terlebih dahulu"></div><div class="card-buttons" style="margin:16px 0"><button class="button secondary" id="copy-invite">Salin pesan</button>'+((phone.length>=8&&link)?'<a class="button" href="https://wa.me/'+phone+'?text='+encodeURIComponent(message)+'" target="_blank" rel="noopener noreferrer">Buka WhatsApp</a>':'')+'</div><p class="muted" style="font-size:13px">WhatsApp membuka draf; pesan dikirim oleh Anda. ID tamu bukan token autentikasi. Endpoint RSVP publik belum aktif.</p>'+(C.can(principal,'guests',true)?'<div class="form-actions"><button class="button subtle" id="mark-delivered">Tandai sudah dikirim</button><button class="button secondary" id="edit-guest">Edit & RSVP</button></div>':''));
  $('copy-invite').onclick=()=>copyText(message);if($('edit-guest'))$('edit-guest').onclick=()=>edit('guests',x);if($('mark-delivered'))$('mark-delivered').onclick=async()=>{try{await save({requestId:uuid(),collection:'guests',id:x.id,version:x.version,action:'save',data:{...x,deliveryStatus:'Dikirim'}});$('modal').close();}catch(e){toast(e.message);}};
}
async function copyText(text){try{await navigator.clipboard.writeText(text);toast('Pesan disalin.');}catch(e){openModal('Salin pesan','<textarea style="min-height:240px" readonly>'+esc(text)+'</textarea><p class="subtitle">Pilih teks dan salin; browser tidak mengizinkan penyalinan otomatis.</p>');}}
function enhanceBudget(){const table=$('records').querySelector('table');if(!table)return;const th=document.createElement('th');th.textContent='Invoice / nota';const head=table.querySelector('thead tr');head.insertBefore(th,head.lastElementChild);table.querySelectorAll('tbody tr').forEach((tr,i)=>{const x=visibleRows()[i];const td=document.createElement('td');td.innerHTML='<button class="edit" data-nota="'+esc(x.id)+'">'+(x.files||[]).length+' lampiran · '+(C.can(principal,'budget',true)?'Upload':'Lihat')+'</button>';tr.insertBefore(td,tr.lastElementChild);});table.querySelectorAll('[data-nota]').forEach(b=>b.onclick=()=>edit('budget',db.budget.find(x=>x.id===b.dataset.nota)));}
const drawRowsWithGuests=drawRows;
drawRows=function(){drawRowsWithGuests();if(route==='budget')enhanceBudget();};
// Use a single expansion per redraw; base listing has already drawn its rows.
listing=function(){if(route==='gifts')giftsPage();else if(route==='admin')adminPage();else if(route==='users')usersPage();else{baseListing();if(route==='guests'&&!$('invitation-base'))enhanceGuests();}};
edit=function(key,record){
  if(!C.can(principal,key,false)){toast('Anda tidak memiliki akses.');return;}
  const x=record||{},id=x.id||uuid(),writable=C.can(principal,key,true),ledgerReadonly=key==='savings'&&!!record;const requestId=uuid();
  if(!record&&!writable){toast('Akses Anda hanya untuk melihat.');return;}
  const defaults=key==='users'&&!record?{role:'Panitia',status:'Aktif',permissions:JSON.stringify(ROLE_DEFAULTS.Panitia)}:{};
  openModal((record?'Detail':'Tambah')+' · '+C.modules[key].title,'<form id="edit-form"><fieldset style="padding:0;border:0;margin:0" '+(!writable||ledgerReadonly?'disabled':'')+'><div class="form-grid">'+fields(key,{...defaults,...x})+(key==='users'?permissionFields({...defaults,...x}):'')+'</div></fieldset>'+(ledgerReadonly?'<div class="notice">Gunakan transaksi koreksi untuk memperbaiki tabungan; catatan sebelumnya dipertahankan.</div>':'')+'<div id="form-error" role="alert"></div><div class="modal-foot"><div>'+(record&&writable&&!['budget','savings','profile'].includes(key)?'<button type="button" class="button danger" id="delete-record">'+(key==='users'?'Hapus akses':'Hapus')+'</button>':'')+'</div><div class="card-buttons">'+(key==='budget'&&record&&writable?'<button type="button" id="payment" class="button secondary">Catat pembayaran</button>':'')+(writable&&!ledgerReadonly?'<button class="button" type="submit">Simpan</button>':'')+'</div></div></form>'+(key==='budget'&&record?'<div class="history"><h3>Riwayat pembayaran</h3>'+((x.payments||[]).map(p=>'<div class="line-stat"><span>'+esc(prettyDate(p.date))+' · '+esc(p.source)+'<br>'+esc(p.type==='refund'?'Refund':'Pembayaran')+'</span><strong>'+money(p.amount)+'</strong></div>').join('')||'<p class="subtitle">Belum ada pembayaran.</p>')+'</div>':'')+(record&&key!=='users'?'<section class="attachments" id="attachments"></section>':'')+(!record&&key!=='users'?'<p class="subtitle">Simpan catatan dahulu, lalu tambahkan dokumen atau nota pada Detail.</p>':''));
  const form=$('edit-form');form.dataset.recordId=id;form.onsubmit=async e=>{e.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;const data=Object.fromEntries(new FormData(form));if(key==='users'){const p={};form.querySelectorAll('[data-permission]').forEach(s=>p[s.dataset.permission]=s.value);data.permissions=JSON.stringify(p);for(const k of Object.keys(data))if(k.startsWith('perm-'))delete data[k];}if(key==='admin')data.available=!!form.querySelector('[name=available]').checked;
    try{await save({collection:key,id,version:x.version||0,requestId,action:'save',data:{...x,...data},...(key==='budget'&&!record&&form.querySelector('[name=paidNow]')?.checked?{initialPayment:{amount:data.amount,source:form.querySelector('[name=initialSource]').value,date:data.date||localToday()}}:{})});$('modal').close();}catch(err){$('form-error').innerHTML='<div class="error">'+esc(err.message)+'</div>';}finally{button.disabled=false;}};
  if(key==='users')$('field-role').onchange=e=>{const p=ROLE_DEFAULTS[e.target.value];form.querySelectorAll('[data-permission]').forEach(s=>s.value=p[s.dataset.permission]||'none');};
  if($('delete-record'))$('delete-record').onclick=async()=>{if(!confirm(key==='users'?'Cabut akses pengguna ini?':'Hapus catatan? Berkas di Drive tetap disimpan.'))return;try{await save({collection:key,id,version:x.version,requestId:uuid(),action:'delete'});$('modal').close();}catch(e){$('form-error').innerHTML='<div class="error">'+esc(e.message)+'</div>';}};
  if($('payment'))$('payment').onclick=()=>payment(x);
  if($('attachments'))attachmentPanel(key,x,writable);
};
function attachmentPanel(key,x,writable){
  const title=key==='budget'?'Invoice, nota & bukti pembayaran':key==='admin'?'Dokumen persyaratan':'Lampiran';
  $('attachments').innerHTML='<h3>'+title+'</h3>'+(x.files||[]).map(f=>'<div class="file-row"><div><strong>'+esc(f.name)+'</strong><small>'+(f.previewOnly?'Berkas contoh di sesi ini':'Google Drive')+'</small></div><div class="file-actions"><button class="button secondary" data-file-view="'+esc(f.id)+'">View</button>'+(writable?'<button class="button secondary" data-file-edit="'+esc(f.id)+'">Edit nama</button><button class="button secondary" data-file-replace="'+esc(f.id)+'">Ganti file</button>':'')+'</div></div>').join('')+(!(x.files||[]).length?'<p class="subtitle">Belum ada berkas. '+(key==='admin'?'Checkbox tersedia juga dapat digunakan untuk dokumen fisik.':'')+'</p>':'')+(writable?'<div class="upload-area"><label for="attachment">'+(key==='budget'?'Upload invoice / nota':'Upload dokumen')+'</label><p class="subtitle">'+(key==='budget'?'PDF, JPG, PNG':'PDF, Word, JPG, PNG')+' · maksimal 5 MB.'+(!live?' Pratinjau: berkas hanya tersedia selama sesi ini.':'')+'</p><input id="attachment" type="file" accept="'+(key==='budget'?'.pdf,.jpg,.jpeg,.png':'.pdf,.doc,.docx,.jpg,.jpeg,.png')+'"><div id="upload-error" role="alert"></div></div>':'');
  let replacement=null,uploadRequestId=uuid();
  document.querySelectorAll('[data-file-view]').forEach(b=>b.onclick=()=>openFile(key,x,b.dataset.fileView,false));
  document.querySelectorAll('[data-file-edit]').forEach(b=>b.onclick=async()=>{const f=x.files.find(f=>f.id===b.dataset.fileEdit),name=prompt('Nama dokumen yang ditampilkan',f.name);if(!name)return;try{await save({collection:key,id:x.id,version:x.version,action:'fileEdit',fileId:f.id,fileName:name,requestId:uuid()});edit(key,db[key].find(r=>r.id===x.id));}catch(e){toast(e.message);}});
  document.querySelectorAll('[data-file-replace]').forEach(b=>b.onclick=()=>{replacement=b.dataset.fileReplace;uploadRequestId=uuid();$('attachment').click();});
  if($('attachment'))$('attachment').onchange=async e=>{
    const file=e.target.files[0];if(!file)return;if(key==='budget'&&!/\.(pdf|jpe?g|png)$/i.test(file.name)){toast('Pilih PDF, JPG atau PNG untuk invoice / nota.');return;}if(file.size>5*1024*1024){$('upload-error').innerHTML='<div class="error">Berkas maksimal 5 MB.</div>';return;}
    const types={'pdf':'application/pdf','doc':'application/msword','docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','jpg':'image/jpeg','jpeg':'image/jpeg','png':'image/png'};const mime=types[file.name.split('.').pop().toLowerCase()];if(!mime){toast('Format tidak didukung.');return;}
    const input=e.target;input.disabled=true;const form=$('edit-form');form.querySelectorAll('button').forEach(b=>b.disabled=true);busy=true;status('Mengunggah…');$('upload-error').textContent='Sedang mengunggah berkas ke Drive…';
    try{
      if(live){const base64=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(new Error('Berkas tidak terbaca.'));r.readAsDataURL(file);});const result=await rpc('uploadAttachment',{collection:key,id:x.id,version:x.version,requestId:uploadRequestId,name:file.name,mime,base64,replaceFileId:replacement});db=result.data;}
      else{if((x.files||[]).length>=10&&!replacement)throw new Error('Maksimal 10 lampiran.');const id=uuid();localFiles.set(id,file);const row=db[key].find(r=>r.id===x.id);row.files=[...(row.files||[]).filter(f=>f.id!==replacement),{id,name:file.name,mime,previewOnly:true,uploaded_at:new Date().toISOString()}];row.version++;if(key==='admin')row.available=true;}
      status(live?'Tersimpan di Drive':'Lampiran contoh');render();edit(key,db[key].find(r=>r.id===x.id));toast(live?'Berkas tersimpan di Drive.':'Berkas ditambahkan untuk pratinjau sesi ini.');
    }catch(err){$('upload-error').innerHTML='<div class="error">'+esc(err.message)+'\nMuat ulang untuk memeriksa hasil sebelum mengganti berkas lain.</div>';input.disabled=false;form.querySelectorAll('button').forEach(b=>b.disabled=false);status('Upload belum terkonfirmasi');}finally{busy=false;input.value='';}
  };
}
let attachmentViewSequence=0,attachmentPdfLoader=null;
function loadAttachmentPdf(){
 if(window.pdfjsLib)return Promise.resolve(window.pdfjsLib);
 if(!attachmentPdfLoader)attachmentPdfLoader=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';script.onload=()=>{window.pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';resolve(window.pdfjsLib);};script.onerror=()=>{attachmentPdfLoader=null;reject(new Error('Pembaca PDF belum dapat dimuat.'));};document.head.append(script);});
 return attachmentPdfLoader;
}
async function openFile(key,x,fileId){
 const f=(x.files||[]).find(f=>f.id===fileId);
 if(!f){toast('Lampiran tidak tersedia.');return;}
 const returnToEdit=!!$('edit-form'),sequence=++attachmentViewSequence;let objectUrl=null;
 const modal=$('modal');
 const cleanup=()=>{if(objectUrl){const old=objectUrl;objectUrl=null;setTimeout(()=>URL.revokeObjectURL(old),60000);}};
 const back=()=>{attachmentViewSequence++;cleanup();if(returnToEdit&&db[key]?.find(r=>r.id===x.id))edit(key,db[key].find(r=>r.id===x.id));else modal.close();};
 openModal('Lampiran · '+f.name,'<div class="attachment-preview"><div id="attachment-content" class="attachment-content" role="status">Memuat lampiran…</div><div class="attachment-footer"><a class="button secondary" id="download-doc" role="button" aria-disabled="true">Download</a><button class="button" id="back-doc">Kembali</button></div></div>');
 $('back-doc').onclick=back;modal.addEventListener('close',cleanup,{once:true});
 try{
  let blob,downloadUrl;
  if(live&&!f.previewOnly){const r=await rpc('getAttachment',{collection:key,id:x.id,fileId});const binary=atob(r.base64),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);blob=new Blob([bytes],{type:r.mime||f.mime||'application/octet-stream'});downloadUrl='data:'+blob.type+';base64,'+r.base64;}
  else{blob=localFiles.get(fileId);if(!blob)throw new Error('Berkas belum tersedia di sesi ini.');}
  if(sequence!==attachmentViewSequence||!modal.open||!$('attachment-content'))return;
  objectUrl=URL.createObjectURL(blob);
  if(!downloadUrl)downloadUrl=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});
  const isImage=/^image\/(png|jpeg|gif|webp)$/i.test(blob.type),isPdf=blob.type==='application/pdf';
  $('attachment-content').removeAttribute('role');
  $('attachment-content').innerHTML=isImage?'<img class="viewer attachment-image" alt="'+esc(f.name)+'" src="'+objectUrl+'">':isPdf?'<div id="attachment-pdf-pages" class="attachment-pdf-pages" role="status">Menampilkan PDF…</div>':'<div class="notice">Pratinjau format ini belum tersedia. Gunakan Download untuk menyimpan berkas.</div>';
  $('download-doc').setAttribute('aria-disabled','false');
  $('download-doc').href=downloadUrl;$('download-doc').download=f.name;
  if(isPdf){
   const pdfjs=await loadAttachmentPdf(),pdf=await pdfjs.getDocument({data:new Uint8Array(await blob.arrayBuffer()),isEvalSupported:false}).promise;
   if(sequence!==attachmentViewSequence||!modal.open){pdf.destroy();return;}
   const pages=$('attachment-pdf-pages');pages.textContent='';pages.removeAttribute('role');
   try{for(let n=1;n<=pdf.numPages;n++){
    if(sequence!==attachmentViewSequence||!modal.open)break;
    const page=await pdf.getPage(n),base=page.getViewport({scale:1}),width=Math.max(240,pages.clientWidth-16),scale=width/base.width,ratio=Math.min(window.devicePixelRatio||1,2),viewport=page.getViewport({scale:scale*ratio});
    const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);canvas.style.width='100%';canvas.setAttribute('aria-label','Halaman '+n+' dari '+pdf.numPages);pages.append(canvas);
    await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;page.cleanup();
   }}finally{pdf.destroy();}
  }
 }catch(e){if(sequence!==attachmentViewSequence||!modal.open||!$('attachment-content'))return;$('attachment-content').textContent='Lampiran belum dapat dimuat. '+e.message;}
}
