/* Reception ledger, receipts and compact paginated lists. */
const pageSettings={};
function paginate(){
  const root=$('view');if(!root)return;
  const selectors={gifts:'.gift-card',admin:'.doc-row',users:'.user-card',dashboard:'.expense-row'};
  const items=[...root.querySelectorAll(selectors[route]||'#records tbody tr')];
  root.querySelector('.list-pagination')?.remove();
  if(!items.length)return;
  const settings=pageSettings[route]||(pageSettings[route]={size:10,page:1});
  const signature=items.map(x=>x.dataset.rowId||x.querySelector('[data-edit],[data-doc-edit],[data-edit-gift],[data-user]')?.outerHTML||x.textContent.slice(0,100)).join('|');
  if(settings.signature!==signature){settings.page=1;settings.signature=signature;}
  const size=settings.size===0?items.length:settings.size,pages=Math.max(1,Math.ceil(items.length/size));settings.page=Math.min(settings.page,pages);
  const start=(settings.page-1)*size,end=Math.min(start+size,items.length);
  items.forEach((item,i)=>item.hidden=i<start||i>=end);
  if(route==='gifts')root.querySelectorAll('.group-header').forEach(header=>header.hidden=![...header.nextElementSibling.querySelectorAll('.gift-card')].some(x=>!x.hidden));
  const bar=document.createElement('div');bar.className='list-pagination';
  bar.innerHTML='<label>Tampilkan <select aria-label="Jumlah baris">'+[[10,'10'],[25,'25'],[50,'50'],[100,'100'],[0,'Semua']].map(([value,label])=>'<option value="'+value+'" '+(value===settings.size?'selected':'')+'>'+label+'</option>').join('')+'</select> baris</label><span>'+numberFormat(start+1)+'–'+numberFormat(end)+' dari '+numberFormat(items.length)+'</span><div><button class="button secondary" data-page-prev '+(settings.page===1?'disabled':'')+' aria-label="Halaman sebelumnya">‹</button><span>'+settings.page+' / '+pages+'</span><button class="button secondary" data-page-next '+(settings.page===pages?'disabled':'')+' aria-label="Halaman berikutnya">›</button></div>';
  const host=route==='dashboard'?root.querySelector('#expense-list'):route==='gifts'?$('gift-groups'):route==='admin'?$('docs'):route==='users'?root.querySelector('.item-grid'):$('records');host.after(bar);
  bar.querySelector('select').onchange=e=>{settings.size=Number(e.target.value);settings.page=1;paginate();};
  bar.querySelector('[data-page-prev]').onclick=()=>{settings.page--;paginate();};bar.querySelector('[data-page-next]').onclick=()=>{settings.page++;paginate();};
}
function guestLedgerSummary(){
  if(route!=='guests'||!$('records'))return;
  const rows=visibleRows();
  $('records').querySelectorAll('tbody tr').forEach((tr,i)=>{
    const guest=rows[i],people=C.attendance(guest),cash=people.reduce((s,p)=>s+p.cash,0),goods=people.filter(p=>p.goods).length;
    if(!guest||tr.querySelector('[data-reception]'))return;
    tr.children[3].insertAdjacentHTML('beforeend','<small>'+numberFormat(people.length)+' hadir tercatat</small>'+(cash?'<small>'+money(cash)+'</small>':'')+(goods?'<small>'+numberFormat(goods)+' pemberi barang</small>':''));
    tr.lastElementChild.insertAdjacentHTML('beforeend','<button class="edit" data-reception="'+esc(guest.id)+'">Kehadiran & pemberian</button>');
  });
  $('records').querySelectorAll('[data-reception]').forEach(b=>b.onclick=()=>receptionModal(db.guests.find(x=>x.id===b.dataset.reception)));
  if(!$('guest-receipt-summary')){
    const t=C.totals(db),section=document.createElement('div');section.id='guest-receipt-summary';section.className='metrics reception-metrics';section.innerHTML=metric('Hadir tercatat',numberFormat(t.checkedIn),'Nama per orang tercatat','guests')+metric('Uang diterima',money(t.guestCash),'Seluruh pemberian uang','savings')+metric('Pemberi barang',numberFormat(t.guestGoods),'Rincian tersimpan per orang','gifts');$('records').before(section);
  }
}
function receptionModal(guest){
  const writable=C.can(principal,'guests',true);let people=C.attendance(guest).map(p=>({...p}));
  if(!people.length&&writable)people.push({id:uuid(),name:guest.name,kind:'',cash:0,goods:''});
  function collect(){
    people=[...$('reception-form').querySelectorAll('.attendee-row')].map(row=>({id:row.dataset.personId,name:row.querySelector('[data-person-name]').value.trim(),kind:row.querySelector('[data-person-kind]').value,cash:Number(row.querySelector('[data-person-cash]').value.replace(/\./g,'')||0),goods:row.querySelector('[data-person-goods]').value.trim()}));
  }
  function paint(){
    openModal('Kehadiran & pemberian · '+guest.name,'<p class="subtitle">Kuota '+numberFormat(guest.quota)+' orang. Catat nama setiap orang yang benar-benar hadir dan seluruh pemberiannya. Pilih “Tidak memberi” bila tidak ada pemberian.</p><form id="reception-form"><fieldset '+(!writable?'disabled':'')+' class="reception-fieldset"><div id="attendees">'+people.map((person,i)=>'<article class="attendee-row" data-person-id="'+esc(person.id)+'"><div class="attendee-heading"><strong>Tamu '+(i+1)+'</strong>'+(writable?'<button type="button" class="text-button" data-remove-person="'+i+'">Hapus</button>':'')+'</div><div class="form-grid"><div class="field"><label>Nama tamu *</label><input aria-label="Nama tamu '+(i+1)+'" data-person-name value="'+esc(person.name)+'" maxlength="250" required></div><div class="field"><label>Pemberian *</label><select aria-label="Pemberian tamu '+(i+1)+'" data-person-kind required>'+['','Uang','Barang','Uang & barang','Tidak memberi'].map(kind=>'<option value="'+kind+'" '+(kind===person.kind?'selected':'')+'>'+(kind||'Pilih pemberian')+'</option>').join('')+'</select></div><div class="field cash-field"><label>Nominal uang (Rp) *</label><input aria-label="Nominal uang tamu '+(i+1)+'" data-person-cash type="number" min="1" max="1000000000000" step="1" value="'+(person.cash||'')+'"></div><div class="field goods-field"><label>Semua barang & jumlahnya *</label><textarea aria-label="Barang dan jumlah tamu '+(i+1)+'" data-person-goods maxlength="3000" placeholder="Contoh: 1 rice cooker; 2 set gelas">'+esc(person.goods)+'</textarea></div></div></article>').join('')+'</div>'+(writable?'<button type="button" class="button secondary" id="add-attendee">'+icon('plus')+'Tambah tamu hadir</button>':'')+'</fieldset><div id="reception-error" role="alert"></div>'+(writable?'<div class="form-actions"><button type="submit" class="button">Simpan kehadiran & pemberian</button></div>':'')+'</form>');
    $('reception-form').querySelectorAll('.attendee-row').forEach(row=>{
      const select=row.querySelector('[data-person-kind]');function toggle(){const cash=['Uang','Uang & barang'].includes(select.value),goods=['Barang','Uang & barang'].includes(select.value);row.querySelector('.cash-field').hidden=!cash;row.querySelector('.goods-field').hidden=!goods;const ci=row.querySelector('[data-person-cash]'),gi=row.querySelector('[data-person-goods]');ci.required=cash;gi.required=goods;if(!cash){ci.value='';ci.setCustomValidity('');}if(!goods)gi.value='';}select.onchange=toggle;toggle();
    });
    $('reception-form').querySelectorAll('[data-remove-person]').forEach(b=>b.onclick=()=>{collect();if(!confirm('Hapus catatan tamu dan pemberiannya?'))return;people.splice(Number(b.dataset.removePerson),1);paint();});
    if($('add-attendee'))$('add-attendee').onclick=()=>{collect();if(people.length>=guest.quota){toast('Kuota tercapai. Ubah kuota pada detail undangan terlebih dahulu.');return;}people.push({id:uuid(),name:'',kind:'',cash:0,goods:''});paint();};
    $('reception-form').onsubmit=async e=>{e.preventDefault();collect();const button=e.currentTarget.querySelector('[type=submit]');button.disabled=true;try{await save({collection:'guests',id:guest.id,version:guest.version,requestId:uuid(),action:'save',data:{...guest,attendanceLedger:JSON.stringify(people)}});$('modal').close();}catch(error){$('reception-error').innerHTML='<div class="error">'+esc(error.message)+'</div>';button.disabled=false;}};
    accountingInputs();
  }paint();
}
function dashboardReception(){
  if(route!=='dashboard'||!principal.owner||!ready)return;
  const t=C.totals(db),section=document.createElement('section');section.className='card reception-dashboard';
  section.innerHTML='<div class="card-head"><div><h2>Keuangan & penerimaan acara</h2><p class="subtitle">Pengeluaran dari pembayaran tercatat · penerimaan dari tamu hadir</p></div><button class="text-button" id="open-reception">Buku tamu</button></div><div class="card-body"><div class="metrics">'+metric('Pengeluaran aktual',money(t.paid),'Invoice melengkapi bukti transaksi','budget')+metric('Pemberian uang',money(t.guestCash),numberFormat(t.checkedIn)+' orang tercatat hadir','savings')+metric('Pemberi barang',numberFormat(t.guestGoods),'Nama & rincian di daftar undangan','gifts')+metric('Selisih kas acara',money(t.netEventCash),'Pemberian uang − pengeluaran','budget')+'</div><div class="line-stat"><span>Invoice / nota terlampir</span><strong>'+numberFormat(db.budget.reduce((s,x)=>s+(x.files||[]).length,0))+' berkas</strong></div></div><div id="expense-list">'+db.budget.map(x=>'<div class="expense-row" data-row-id="'+esc(x.id)+'"><div><strong>'+esc(x.name)+'</strong><small>'+esc(prettyDate(x.date))+' · '+(x.files||[]).length+' lampiran</small></div><div>'+money(C.netPaid(x))+'</div><button class="text-button" data-expense-detail="'+esc(x.id)+'">Detail</button></div>').join('')+(!db.budget.length?'<p class="subtitle empty">Belum ada pengeluaran.</p>':'')+'</div>';
  $('view').querySelector('.quick-actions').before(section);$('open-reception').onclick=()=>go('guests');section.querySelectorAll('[data-expense-detail]').forEach(b=>b.onclick=()=>edit('budget',db.budget.find(x=>x.id===b.dataset.expenseDetail)));
}
const editBeforeExperience=edit;
edit=function(key,record){
  editBeforeExperience(key,record);const form=$('edit-form');if(!form)return;
  if(key==='guests'&&record){const button=document.createElement('button');button.type='button';button.className='button secondary';button.textContent='Catat kehadiran & pemberian';button.onclick=()=>receptionModal(record);form.querySelector('.modal-foot').before(button);}
  if(key==='admin'&&!record&&C.can(principal,key,true)){
    const box=document.createElement('section');box.className='new-budget-proof';box.innerHTML='<div class="field"><label for="new-admin-file">Upload dokumen KUA (opsional)</label><input id="new-admin-file" type="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"><small>PDF, Word, JPG atau PNG · maksimal 5 MB. Berkas diunggah setelah persyaratan tersimpan.</small></div>';form.querySelector('.modal-foot').before(box);
    const submit=form.onsubmit;form.onsubmit=async event=>{const file=$('new-admin-file').files[0];if(file&&(file.size>5*1024*1024||! /\.(pdf|docx?|jpe?g|png)$/i.test(file.name))){event.preventDefault();$('form-error').innerHTML='<div class="error">Pilih PDF, Word, JPG atau PNG maksimal 5 MB.</div>';return;}await submit(event);if($('modal').open)return;const saved=db.admin.find(x=>x.id===form.dataset.recordId);if(!saved)return;edit('admin',saved);if(file){const input=$('attachment'),transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;await input.onchange({target:input});}};
  }
  if(key!=='budget'||record||!C.can(principal,key,true))return;
  const box=document.createElement('section');box.className='new-budget-proof';box.innerHTML='<label class="paid-now"><input type="checkbox" name="paidNow" checked> Sudah dibayar lunas — catat sebagai pengeluaran</label><div class="field"><label>Sumber pembayaran</label><select name="initialSource"><option>Dana lain</option><option>Tabungan</option></select></div><div class="field"><label for="new-budget-file">Invoice / nota (opsional)</label><input id="new-budget-file" type="file" accept=".pdf,.jpg,.jpeg,.png"><small>PDF, JPG atau PNG · maksimal 5 MB. Berkas diunggah setelah item biaya tersimpan.</small></div>';
  form.querySelector('.modal-foot').before(box);
  form.querySelector('[name=initialSource]').disabled=!form.querySelector('[name=paidNow]').checked;form.querySelector('[name=paidNow]').onchange=e=>form.querySelector('[name=initialSource]').disabled=!e.target.checked;
  const submit=form.onsubmit;
  form.onsubmit=async event=>{
    const file=$('new-budget-file').files[0];
    if(file&&(file.size>5*1024*1024||! /\.(pdf|jpe?g|png)$/i.test(file.name))){event.preventDefault();$('form-error').innerHTML='<div class="error">Pilih PDF, JPG atau PNG maksimal 5 MB.</div>';return;}
    await submit(event);
    if($('modal').open)return;
    const saved=db.budget.find(x=>x.id===form.dataset.recordId);if(!saved)return;
    edit('budget',saved);
    if(file){const input=$('attachment');const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;await input.onchange({target:input});}
  };
};
function visibleUploadActions(){
  if(route!=='budget'||!C.can(principal,route,true))return;
  const root=$('view');root.querySelectorAll(route==='budget'?'[data-edit]':'[data-doc-edit]').forEach(detail=>{
    const id=route==='budget'?detail.dataset.edit:detail.dataset.docEdit,record=db[route].find(x=>x.id===id);if(!record||detail.parentElement.querySelector('[data-upload-record]'))return;
    const button=document.createElement('button');button.type='button';button.className='button secondary';button.dataset.uploadRecord=id;button.textContent=route==='budget'?'Upload invoice / nota':'Upload dokumen';button.onclick=()=>{edit(route,record);$('attachments')?.scrollIntoView({block:'nearest',behavior:'smooth'});$('attachment')?.focus();};detail.after(button);
  });
}
const renderBeforeExperience=render;render=function(){renderBeforeExperience();if(ready){guestLedgerSummary();dashboardReception();visibleUploadActions();paginate();polishTables();accountingInputs();}};
const drawRowsBeforeExperience=drawRows;drawRows=function(){drawRowsBeforeExperience();guestLedgerSummary();visibleUploadActions();paginate();polishTables();accountingInputs();};
const drawGiftsBeforeExperience=drawGifts;drawGifts=function(){drawGiftsBeforeExperience();paginate();};
const drawDocsBeforeExperience=drawDocs;drawDocs=function(){drawDocsBeforeExperience();visibleUploadActions();paginate();};

/* Illustrative reception entries belong to the session-only demo. */
const demoBeforeExperience=demo;
demo=function(){const data=demoBeforeExperience();const family=data.guests[0];if(family)family.attendanceLedger=JSON.stringify([{id:'demo-person-one',name:'Siti (contoh)',kind:'Uang',cash:250000,goods:''},{id:'demo-person-two',name:'Budi (contoh)',kind:'Barang',cash:0,goods:'1 set gelas'},{id:'demo-person-three',name:'Rina (contoh)',kind:'Uang & barang',cash:150000,goods:'1 selimut'},{id:'demo-person-four',name:'Dimas (contoh)',kind:'Tidak memberi',cash:0,goods:''}]);return data;};

/* Three desktop sidebar modes and compact record actions. */
let sidebarMode=0;
function compactNavigation(){
  let toggle=document.getElementById('sidebar-mode');
  if(!toggle){toggle=document.createElement('button');toggle.id='sidebar-mode';toggle.className='sidebar-mode';toggle.innerHTML=icon('menu');document.querySelector('.brand').append(toggle);toggle.onclick=()=>{sidebarMode=(sidebarMode+1)%3;compactNavigation();};}
  document.body.dataset.sidebarMode=String(sidebarMode);toggle.title=['Sidebar: ikon dan nama. Klik untuk ikon saja.','Sidebar: ikon saja. Klik untuk sembunyikan.','Sidebar tersembunyi. Klik untuk tampilkan.'][sidebarMode];toggle.setAttribute('aria-label',toggle.title);
  document.querySelectorAll('#nav button').forEach(b=>{const label=b.querySelector('span')?.textContent||b.textContent;b.title=label;b.setAttribute('aria-label',label);});
  document.querySelectorAll('#view [data-edit],#view [data-edit-gift],#view [data-edit-user]').forEach(b=>{const label=b.getAttribute('aria-label')||b.title||b.textContent.trim()||'Edit catatan';b.title=label;b.setAttribute('aria-label',label);b.innerHTML=icon('edit');b.classList.add('compact-edit');});
}
const renderBeforeCompact=render;render=function(){renderBeforeCompact();compactNavigation();};
const rowsBeforeCompact=drawRows;drawRows=function(){rowsBeforeCompact();compactNavigation();};
const giftsBeforeCompact=drawGifts;drawGifts=function(){giftsBeforeCompact();compactNavigation();};
compactNavigation();

function singleHeader(){const top=document.querySelector('.topbar'),head=document.querySelector('#view .page-head');if(!top||!head)return;top.querySelector('.page-head')?.remove();top.prepend(head);}
const renderBeforeSingleHeader=render;render=function(){document.querySelector('.topbar>.page-head')?.remove();renderBeforeSingleHeader();singleHeader();};
// Tabs and filters may redraw a feature directly rather than through render().
new MutationObserver(()=>singleHeader()).observe($('view'),{childList:true,subtree:true});

const editBeforeSimpleGuest=edit;edit=function(key,record){editBeforeSimpleGuest(key,record);if(key!=='guests'||record||!C.can(principal,key,true))return;const form=$('edit-form');if(!form)return;form.querySelector('.form-grid').innerHTML='<div class="field"><label for="field-name">Nama *</label><input id="field-name" name="name" required maxlength="200" autocomplete="name"></div><div class="field"><label for="field-group">Kelompok *</label><input id="field-group" name="group" required maxlength="200" placeholder="Keluarga, teman, rekan kerja…"></div><div class="field full"><label for="field-address">Alamat *</label><textarea id="field-address" name="address" required maxlength="2000" rows="2" autocomplete="street-address"></textarea></div><div class="field full"><label for="field-notes">Catatan <span class="muted">(opsional)</span></label><textarea id="field-notes" name="notes" maxlength="2000" rows="2"></textarea></div><input type="hidden" name="event" value="Resepsi"><input type="hidden" name="quota" value="1"><input type="hidden" name="attending" value="0"><input type="hidden" name="status" value="Belum dikirim"><input type="hidden" name="deliveryStatus" value="Belum dikirim">';document.querySelector('#modal-body>p.subtitle')?.remove();const submit=form.onsubmit;form.onsubmit=async e=>{for(const name of ['name','group','address']){const input=form.elements.namedItem(name);input.value=input.value.trim();}if(!form.reportValidity()){e.preventDefault();return;}await submit(e);};};

const usersPageBeforeHistory=usersPage;usersPage=function(){usersPageBeforeHistory();if(!principal.owner)return;const ownerCard=document.querySelector('#view .user-card'),ownerButton=document.createElement('button');ownerButton.className='button secondary compact-edit';ownerButton.innerHTML=icon('edit');ownerButton.title='Edit nama akun utama';ownerButton.setAttribute('aria-label',ownerButton.title);ownerButton.onclick=async()=>{try{const result=await rpc('getUserHistory');openModal('Edit akun utama','<form id="owner-name-form"><div class="field"><label for="owner-name">Nama akun utama</label><input id="owner-name" name="name" required maxlength="100" value="'+esc(result.ownerProfile.name)+'"></div><p class="subtitle">Email login: '+esc(principal.email)+'</p><div class="form-error" id="owner-error"></div><div class="form-actions"><button class="button">Simpan</button></div></form>');$('owner-name-form').onsubmit=async e=>{e.preventDefault();const button=e.currentTarget.querySelector('button');button.disabled=true;try{await rpc('saveOwnerProfile',{name:$('owner-name').value,requestId:uuid()});$('modal').close();render();}catch(error){$('owner-error').textContent=error.message;}finally{button.disabled=false;}};}catch(error){toast(error.message);}};ownerCard.append(ownerButton);rpc('getUserHistory').then(r=>{if(ownerCard.isConnected)ownerCard.querySelector('h3').textContent=r.ownerProfile.name;}).catch(()=>{});const historyButton=document.createElement('button');historyButton.className='button secondary';historyButton.textContent='Riwayat login & aktivitas';historyButton.onclick=()=>userHistoryModal();document.querySelector('#view .notice').after(historyButton);document.querySelectorAll('[data-user]').forEach(b=>{b.title='Edit pengguna & akses';b.setAttribute('aria-label',b.title);b.innerHTML=icon('edit');b.classList.add('compact-edit');});};
async function userHistoryModal(filter='Semua',page=0){try{const result=await rpc('getUserHistory'),all=result.history.filter(x=>filter==='Semua'||x.type===filter).reverse(),rows=all.slice(page*10,page*10+10);openModal('Riwayat pengguna','<p class="subtitle">Riwayat mulai dicatat setelah fitur ini aktif. Catatan riwayat bisa diedit; penghapusan menyembunyikan entri dari daftar. Jejak audit penyimpanan tetap tersimpan.</p><div class="segmented">'+['Semua','Login','Aktivitas'].map(x=>'<button type="button" data-history-filter="'+x+'" class="'+(filter===x?'selected':'')+'">'+x+'</button>').join('')+'</div><div class="history-records">'+rows.map(x=>'<article class="history-user-row"><div><strong>'+esc(x.action)+'</strong><small>'+esc(x.email)+' · '+esc(new Date(x.timestamp).toLocaleString('id-ID'))+'</small>'+(x.notes?'<p>'+esc(x.notes)+'</p>':'')+'</div><button class="doc-edit-icon" data-history-edit="'+esc(x.id)+'" aria-label="Edit catatan riwayat">'+icon('edit')+'</button><button class="doc-edit-icon" data-history-delete="'+esc(x.id)+'" aria-label="Hapus riwayat dari daftar">×</button></article>').join('')+(rows.length?'':'<p class="subtitle">Belum ada riwayat.</p>')+'</div><div class="form-actions"><button class="button secondary" id="history-prev" '+(page===0?'disabled':'')+'>Sebelumnya</button><span>'+numberFormat(all.length)+' entri</span><button class="button secondary" id="history-next" '+((page+1)*10>=all.length?'disabled':'')+'>Berikutnya</button></div>');document.querySelectorAll('[data-history-filter]').forEach(b=>b.onclick=()=>userHistoryModal(b.dataset.historyFilter));$('history-prev').onclick=()=>userHistoryModal(filter,page-1);$('history-next').onclick=()=>userHistoryModal(filter,page+1);document.querySelectorAll('[data-history-edit]').forEach(b=>b.onclick=()=>{const item=rows.find(x=>x.id===b.dataset.historyEdit);openModal('Edit catatan riwayat','<form id="history-edit-form"><p>'+esc(item.action)+'</p><div class="field"><label for="history-notes">Catatan</label><textarea id="history-notes" maxlength="1000">'+esc(item.notes)+'</textarea></div><div id="history-error"></div><div class="form-actions"><button class="button">Simpan</button></div></form>');$('history-edit-form').onsubmit=async e=>{e.preventDefault();const button=e.currentTarget.querySelector('button');button.disabled=true;try{await rpc('changeUserHistory',{id:item.id,version:item.version,action:'edit',notes:$('history-notes').value,requestId:uuid()});await userHistoryModal(filter,page);}catch(error){$('history-error').textContent=error.message;button.disabled=false;}};});document.querySelectorAll('[data-history-delete]').forEach(b=>b.onclick=async()=>{const item=rows.find(x=>x.id===b.dataset.historyDelete);b.disabled=true;try{await rpc('changeUserHistory',{id:item.id,version:item.version,action:'delete',requestId:uuid()});await userHistoryModal(filter,0);}catch(error){toast(error.message);b.disabled=false;}});}catch(error){toast(error.message);}}
