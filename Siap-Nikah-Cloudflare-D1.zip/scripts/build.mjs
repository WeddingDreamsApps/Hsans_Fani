import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const core=fs.readFileSync('core.js','utf8');
const enhancements=fs.readFileSync('enhancements.js','utf8');
const styles=fs.readFileSync('enhancements.css','utf8');
const polishCss=fs.readFileSync('polish.css','utf8');
const polishJs=fs.readFileSync('polish.js','utf8');
const experienceJs=fs.readFileSync('experience.js','utf8');
const experienceCss=fs.readFileSync('experience.css','utf8')+'\n'+fs.readFileSync('concept.css','utf8')+'\n'+fs.readFileSync('workflow.css','utf8')+'\n'+fs.readFileSync('login-sunset.css','utf8')+'\n'+fs.readFileSync('dark-mobile.css','utf8')+'\n'+fs.readFileSync('reference-theme.css','utf8');
const gatewayClient=fs.readFileSync('gateway-client.js','utf8')+'\n'+fs.readFileSync('concept.js','utf8')+'\n'+fs.readFileSync('workflow-core.js','utf8')+'\n'+fs.readFileSync('workflow.js','utf8')+'\n'+fs.readFileSync('gift-sheet-core.js','utf8')+'\n'+fs.readFileSync('gift-sheet.js','utf8')+'\n'+fs.readFileSync('preparation-logos.js','utf8')+'\n'+fs.readFileSync('preparation-map.js','utf8')+'\n'+fs.readFileSync('finance-integration.js','utf8')+'\n'+fs.readFileSync('invitation-core.js','utf8')+'\n'+fs.readFileSync('invitations.js','utf8')+'\n'+fs.readFileSync('guest-share.js','utf8')+'\n'+fs.readFileSync('guest-tabs.js','utf8')+'\n'+fs.readFileSync('timeline-core.js','utf8')+'\n'+fs.readFileSync('timeline.js','utf8');
const publicConfig=JSON.parse(fs.readFileSync('config.public.json','utf8').replace(/^\uFEFF/,''));
if(publicConfig.supabasePublishableKey){
  const key=publicConfig.supabasePublishableKey;
  if(!key.startsWith('sb_publishable_')){
    let role;try{role=JSON.parse(Buffer.from(key.split('.')[1]||'','base64url').toString('utf8')).role;}catch{}
    if(role!=='anon')throw new Error('Only publishable/anon keys may be embedded in HTML.');
  }
}
const configScript='<script>window.WEDDING_CONFIG='+JSON.stringify(publicConfig).replace(/</g,'\\u003c')+';</script>';
const result=html.replace('<!-- CORE -->',()=>configScript+'<script>\n'+core+'\n</script>').replace('<!-- ENHANCEMENTS -->',()=>'<style>\n'+styles+'\n'+polishCss+'\n'+experienceCss+'\n'+fs.readFileSync('gift-sheet.css','utf8')+'\n'+fs.readFileSync('preparation-map.css','utf8')+'\n'+fs.readFileSync('finance-integration.css','utf8')+'\n'+fs.readFileSync('invitations.css','utf8')+'\n'+fs.readFileSync('guest-tabs.css','utf8')+'\n'+fs.readFileSync('timeline.css','utf8')+'\n</style><script>\n'+enhancements+'\n'+polishJs+'\n'+experienceJs+'\n'+gatewayClient+'\n'+fs.readFileSync('qrcode-vendor.js','utf8')+'\n'+fs.readFileSync('guest-qr.js','utf8')+'\n;\n'+fs.readFileSync('account-health.js','utf8')+'\nreload();\n</script>');
const mobileResult=result.replace('</style><script>\n'+enhancements,()=>'\n'+fs.readFileSync('mobile-refinement.css','utf8')+'\n'+fs.readFileSync('row-presentation.css','utf8')+'\n</style><script>\n'+enhancements).replace('reload();\n</script>',()=>fs.readFileSync('row-presentation.js','utf8')+'\nreload();\n</script>');
fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/index.html',mobileResult);
fs.copyFileSync('mountain-sunset.png','dist/mountain-sunset.png');
fs.writeFileSync('apps-script/Index.html',mobileResult);fs.writeFileSync('apps-script/Core.gs',core);
// Keep financial rules identical in browser and Worker on every build.
fs.writeFileSync('cloudflare/core.mjs',core+'\nexport default WeddingCore;\n');
const worker=fs.readFileSync('cloudflare/worker.mjs','utf8').replace("import C from './core.mjs';",'const C=WeddingCore;').replace("import {guestInput,guestKey,activeGuestQr,guestForm} from './guest-checkin.mjs';",'');
fs.writeFileSync('cloudflare/worker-dashboard.mjs',core+'\n'+fs.readFileSync('cloudflare/guest-checkin.mjs','utf8').replaceAll('export ','')+'\n'+worker);
console.log('Built preview and Apps Script HTML from the same source.');
