ICONS.link='M14 3h7v7 M21 3l-9 9 M10 5H3v16h16v-7';
/* Unified financial view projects source records without duplicating their storage. */
['Transportasi','Akomodasi','Konsumsi'].forEach(category=>{if(!choices.category.includes(category))choices.category.push(category);});
function financeSource(row){return row.sourceKey==='gifts'?row.category:row.sourceKey==='admin'?'Peta Persiapan':row.sourceKey==='tasks'?'Timeline':row.sourceKey==='vendors'?'Vendor & Venue':'Manual';}
function financeOrigin(row){return db[row.sourceKey]?.find(record=>record.id===row.sourceId);}
function financeFiles(row){const origin=financeOrigin(row),ledger=db.budget.find(record=>record.id===row.ledgerId);return [...(origin?.files||[]).map(file=>({file,key:row.sourceKey,record:origin})),...(row.sourceKey!=='budget'?(ledger?.files||[]).map(file=>({file,key:'budget',record:ledger})):[])];}
function financeOpenSource(row){const origin=financeOrigin(row);if(origin){go(row.sourceKey);edit(row.sourceKey,origin);}}
function financeViewFiles(row){const files=financeFiles(row);if(!files.length){financeOpenSource(row);return;}if(files.length===1){const item=files[0];openFile(item.key,item.record,item.file.id,false);return;}openModal('Lampiran · '+row.name,'<div class="finance-file-list">'+files.map((item,index)=>'<button type="button" class="button secondary" data-finance-file="'+index+'">'+icon('attach')+esc(item.file.name)+'</button>').join('')+'</div>');document.querySelectorAll('[data-finance-file]').forEach(button=>button.onclick=()=>{const item=files[Number(button.dataset.financeFile)];openFile(item.key,item.record,item.file.id,false);});}
async function financePayment(row){
 if(!C.can(principal,'budget',true))return;
 if(row.sourceKey==='admin'){financeOpenSource(row);return;}
 if(row.sourceKey==='budget'){payment(financeOrigin(row));return;}
 let ledger=db.budget.find(record=>record.id===row.id);
 if(!ledger||ledger.amount!==row.amount||ledger.name!==row.name||ledger.category!==row.category){
  await save({collection:'budget',id:row.id,version:ledger?.version||0,action:'save',requestId:uuid(),data:{name:row.name,category:row.category,amount:row.amount,date:ledger?.date||'',owner:row.owner||'',notes:ledger?.notes||'Terhubung dengan '+financeSource(row)+'.'}});
  ledger=db.budget.find(record=>record.id===row.id);
 }
 if(ledger)payment(ledger);
}
function drawFinanceRows(){
 const rows=C.paidFinanceRows(db).filter(row=>!search||[row.name,row.category,financeSource(row)].join(' ').toLowerCase().includes(search.toLowerCase()));
 $('records').innerHTML='<div class="table-wrap"><table class="table standard-data-table finance-table"><thead><tr>'+['Item biaya','Sumber','Rencana','Dibayar','Sisa','Lampiran',''].map(label=>'<th>'+label+'</th>').join('')+'</tr></thead><tbody>'+rows.map((row,index)=>{const paid=C.financePaid(row),files=financeFiles(row),status=paid===0&&row.amount>0?'Belum dibayar':paid<row.amount?'DP / sebagian':'Lunas';return '<tr data-finance-row="'+index+'"><td title="'+esc(row.name)+'"><strong>'+esc(row.name)+'</strong><small>'+esc(row.category)+(row.date?' · '+esc(prettyDate(row.date)):'')+'</small></td><td><span class="finance-source">'+esc(financeSource(row))+'</span></td><td>'+(row.amount?numberFormat(row.amount):'—')+'</td><td>'+(paid?numberFormat(paid):'—')+'<small>'+status+'</small></td><td>'+(row.amount>paid?numberFormat(row.amount-paid):'—')+'</td><td><button class="doc-edit-icon" data-finance-files="'+index+'" aria-label="'+(files.length?'Lihat lampiran ':'Tambah lampiran ')+esc(row.name)+'" title="'+files.length+' lampiran">'+icon('attach')+'</button>'+(files.length?'<small>'+numberFormat(files.length)+'</small>':'')+'</td><td><div class="finance-actions">'+(row.sourceKey!=='admin'&&C.can(principal,'budget',true)?'<button class="doc-edit-icon" data-finance-pay="'+index+'" aria-label="Catat pembayaran '+esc(row.name)+'" title="Catat pembayaran">'+icon('budget')+'</button>':'')+'<button class="doc-edit-icon" data-finance-edit="'+index+'" aria-label="Edit '+esc(row.name)+'" title="'+(row.sourceKey==='budget'?'Edit biaya':'Buka data asal')+'">'+icon(row.sourceKey==='budget'?'edit':'link')+'</button></div></td></tr>';}).join('')+'</tbody></table></div>'+(!rows.length?'<div class="empty"><p>Belum ada pengeluaran yang sudah dibayar.</p></div>':'');
 document.querySelectorAll('[data-finance-row]').forEach(tr=>{const row=rows[Number(tr.dataset.financeRow)],detail=document.createElement('small');detail.className='finance-mobile-detail';detail.textContent=financeSource(row)+' · Sisa '+numberFormat(Math.max(0,row.amount-C.financePaid(row)));tr.firstElementChild.append(detail);const file=tr.querySelector('[data-finance-files]')?.cloneNode(true);if(file){file.classList.add('finance-mobile-file');tr.querySelector('.finance-actions')?.prepend(file);}});
 document.querySelectorAll('[data-finance-edit]').forEach(button=>button.onclick=()=>financeOpenSource(rows[Number(button.dataset.financeEdit)]));
 document.querySelectorAll('[data-finance-files]').forEach(button=>button.onclick=()=>financeViewFiles(rows[Number(button.dataset.financeFiles)]));
 document.querySelectorAll('[data-finance-pay]').forEach(button=>button.onclick=async()=>{button.disabled=true;try{await financePayment(rows[Number(button.dataset.financePay)]);}catch(error){toast(error.message);}finally{button.disabled=false;}});
 $('export').onclick=()=>download('keuangan-terintegrasi.csv',C.csv(rows.map(row=>({Nama:row.name,Kategori:row.category,Sumber:financeSource(row),'Rencana biaya':row.amount,Dibayar:C.financePaid(row),Sisa:Math.max(0,row.amount-C.financePaid(row)),Tanggal:row.date}))), 'text/csv;charset=utf-8');
 paginate();polishTables();
}
const drawRowsBeforeFinance=drawRows;drawRows=function(){if(route==='budget'){drawFinanceRows();return;}drawRowsBeforeFinance();};
const dashboardBeforeFinance=dashboardReception;dashboardReception=function(){
 dashboardBeforeFinance();if(route!=='dashboard'||!principal.owner||!ready)return;const section=$('view').querySelector('.reception-dashboard'),list=section?.querySelector('#expense-list');if(!list)return;
 const rows=C.financeRows(db),expenses=C.paidFinanceRows(db);
 list.innerHTML=expenses.map((row,index)=>'<div class="expense-row" data-row-id="'+esc(row.id)+'"><div><strong>'+esc(row.name)+'</strong><small>'+esc(financeSource(row))+'</small></div><div>'+money(C.financePaid(row))+'</div><button class="text-button" data-finance-expense="'+index+'">Detail</button></div>').join('')||'<p class="subtitle empty">Belum ada pengeluaran tercatat.</p>';
 list.querySelectorAll('[data-finance-expense]').forEach(button=>button.onclick=()=>financeOpenSource(expenses[Number(button.dataset.financeExpense)]));
 section.querySelector('.card-head .subtitle').textContent='Pembayaran dan biaya persiapan terintegrasi · penerimaan tamu hadir';
 const totalFiles=rows.reduce((sum,row)=>sum+financeFiles(row).length,0);section.querySelector('.line-stat strong').textContent=numberFormat(totalFiles)+' berkas';paginate();
};
const editBeforeFinance=edit;edit=function(key,record){
 editBeforeFinance(key,record);const form=$('edit-form');if(!form)return;
 if(key==='budget'){form.dataset.giftEditor='true';$('modal-body').querySelector(':scope>.subtitle')?.remove();}
 if(key==='gifts'&&record&&C.can(principal,'budget',false)){
  const row=C.financeRows(db).find(row=>row.sourceKey==='gifts'&&row.sourceId===record.id);if(!row)return;
  const panel=document.createElement('div');panel.className='finance-gift-payments';panel.innerHTML='<span>Pembayaran '+money(C.financePaid(row))+' · Sisa '+money(Math.max(0,row.amount-C.financePaid(row)))+'</span>'+(C.can(principal,'budget',true)?'<button type="button" class="button secondary">'+icon('budget')+'Catat pembayaran</button>':'');
  form.querySelector('.modal-foot').before(panel);const button=panel.querySelector('button');if(button)button.onclick=async()=>{button.disabled=true;try{await financePayment(row);}catch(error){toast(error.message);button.disabled=false;}};
 }
};

