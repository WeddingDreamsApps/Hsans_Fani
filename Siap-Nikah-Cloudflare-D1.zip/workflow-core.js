var WeddingWorkflow=(function(){
  const plan=[
    ['Sepakati tanggal, lokasi, dan anggaran',180,'Hasanudin'],
    ['Susun daftar tamu bersama keluarga',150,'Efani'],
    ['Bandingkan dan pilih venue',120,'Hasanudin'],
    ['Pilih katering, dekorasi, dan dokumentasi',100,'Efani'],
    ['Siapkan dokumen dan konsultasi KUA tujuan',90,'Hasanudin'],
    ['Susun seserahan dan mahar',60,'Efani'],
    ['Finalkan undangan dan konfirmasi tamu',30,'Efani'],
    ['Susun rundown dan pembagian tugas panitia',21,'Hasanudin'],
    ['Konfirmasi seluruh vendor dan pembayaran',7,'Hasanudin'],
    ['Periksa dokumen, barang, dan kesiapan panitia',1,'Efani']
  ];
  function before(date,days){if(!/^\d{4}-\d{2}-\d{2}$/.test(date||''))return '';const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-days);return Number.isNaN(d.getTime())?'':d.toISOString().slice(0,10);}
  function planRows(date){return plan.map(([name,days,owner],i)=>({id:'wedding-plan-'+i,name,date:before(date,days),owner,priority:i===4||i===9?'Tinggi':'Normal',status:'Belum mulai',notes:'Panduan persiapan H-'+days+'. Sesuaikan tanggal melalui ikon pensil.'}));}
  function costId(key,id){if(!['gifts','vendors'].includes(key))throw new Error('Sumber biaya tidak dikenal.');return 'linked-'+key+'-'+id;}
  function costData(key,record){return {name:record.name,category:key==='gifts'?(record.type==='Mahar'?'Mahar':'Seserahan'):record.category||'Lainnya',amount:record.amount||0,date:'',owner:key==='gifts'?record.owner||'':'Hasanudin',notes:'Terhubung dengan '+(key==='gifts'?'Seserahan & Mahar':'Vendor & Venue')+'. Catat pembayaran aktual melalui rincian biaya.'};}
  function taskMatch(rows,item){return rows.some(r=>r.id===item.id||r.name.trim().toLowerCase()===item.name.trim().toLowerCase());}
  function ics(records){const escape=s=>String(s||'').replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');return ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Siap Nikah//Persiapan//ID',...records.filter(r=>r.date).flatMap(r=>['BEGIN:VEVENT','UID:'+escape(r.id)+'@siapnikah','DTSTART;VALUE=DATE:'+r.date.replace(/-/g,''),'SUMMARY:'+escape(r.name),'DESCRIPTION:'+escape((r.owner||'')+'\n'+(r.notes||'')),'END:VEVENT']),'END:VCALENDAR'].join('\r\n')+'\r\n';}
  return {before,planRows,costId,costData,taskMatch,ics};
})();
if(typeof module!=='undefined')module.exports=WeddingWorkflow;
