# Status pengujian versi 0.1

9 Oktober 2026.

## Lulus lokal

21 pengujian Node: perhitungan DP, refund menurut sumber dana, saldo kurang, konflik versi, kredit terpisah antar-vendor, larangan hapus transaksi, koreksi tabungan, validasi nominal, kuota RSVP, rundown lintas malam, CSV formula injection, cakupan menu, perlindungan field, satu profil, allowlist Google, inisialisasi berulang, retry idempotent, perubahan payload pada request sama, kegagalan batch, dan preservasi tabel lama.

Pengujian backend memakai layanan Google tiruan. Pemeriksaan sintaks JavaScript server dan script dalam HTML juga lulus. Build menghasilkan UI Apps Script dan pratinjau dari sumber yang sama.

## Belum terbukti / terhalang

- Read metadata Google: berhasil. Write spreadsheet: dua kali ditolak Google `403 PERMISSION_DENIED`.
- Upload Drive dan penggunaan aplikasi Google nyata: belum diuji karena Apps Script belum terpasang/diotorisasi.
- Tampilan dan interaksi browser: belum terverifikasi visual; browser tidak dapat menjangkau server lokal, mengalami timeout. Tidak ada klaim pengujian desktop/mobile visual.
- Penerbitan Sites: project privat didaftarkan, tetapi pengiriman sumber terhalang peninjauan persetujuan otomatis. Belum ada deployment berhasil atau URL live.
- GitHub: belum dikirim; URL repository tujuan belum diberikan.

Tidak ada data contoh yang ditulis ke spreadsheet pengguna. Tidak ada API key pengguna yang digunakan, disimpan ke paket, atau dimasukkan ke repository.
