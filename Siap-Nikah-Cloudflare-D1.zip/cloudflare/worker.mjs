import C from './core.mjs';
import {guestInput,guestKey,activeGuestQr,guestForm,guestTransfer} from './guest-checkin.mjs';
const methods=new Set(['loadData','changeData','uploadAttachment','getAttachment','getUserHistory','changeUserHistory','recordLogin','saveOwnerProfile','createUserAccount','updateUserAccount','checkAccountService','exportBackup','getGuestCheckin','setGuestCheckin']);
function actorFor(data,email,owner){
  if(email===owner)return {email,owner:true,role:'Akun utama'};
  const member=data.users.find(x=>x.email===email&&x.status==='Aktif');
  if(!member)throw new Error('Akses akun belum diberikan atau sudah dicabut.');
  return {email,owner:false,role:member.role,permissions:JSON.parse(member.permissions||'{}')};
}
async function digest(text){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(b=>b.toString(16).padStart(2,'0')).join('');}
async function drive(env,email,method,args){
  const endpoint=String(env.GOOGLE_APPS_SCRIPT_URL||'').trim(),secret=String(env.GATEWAY_SECRET||'').trim();
  if(!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(endpoint))throw new Error('Alamat GOOGLE_APPS_SCRIPT_URL di Cloudflare belum valid.');
  if(secret.length<32)throw new Error('GATEWAY_SECRET di Cloudflare kosong atau terlalu pendek. Salin nilai rahasia dari Properti skrip Apps Script, minimal 32 karakter.');
  const payload=JSON.stringify({v:1,timestamp:Date.now(),nonce:crypto.randomUUID(),email,method,args});
  const encoder=new TextEncoder(),key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature=[...new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(payload)))].map(b=>b.toString(16).padStart(2,'0')).join('');
  // Google ContentService redirects to a one-time content URL. Keep signed POST
  // through script-host canonical redirects, but never forward its body elsewhere.
  const signal=AbortSignal.timeout(55000);let url=endpoint,options={method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({payload,signature}),redirect:'manual',signal},response;
  for(let hop=0;hop<6;hop++){
    response=await fetch(url,options);if(![301,302,303,307,308].includes(response.status))break;
    const location=response.headers.get('location');if(!location)throw new Error('Pengalihan Drive tidak valid.');
    const next=new URL(location,url);if(next.protocol!=='https:'||next.username||next.password)throw new Error('Pengalihan Drive tidak diizinkan.');
    if(next.hostname==='script.googleusercontent.com')options={method:'GET',redirect:'manual',signal};
    else if(next.hostname!=='script.google.com'||options.method!=='POST'||response.status===303)throw new Error('Penghubung Drive meminta login atau deployment belum dapat diakses.');
    url=next.href;
  }
  if(!response.ok)throw new Error('Drive belum dapat dihubungi (status '+response.status+').');
  let result;try{result=await response.json();}catch{throw new Error('Penghubung Drive belum mengembalikan data. Periksa deployment Apps Script yang terpasang di Cloudflare.');}if(result.ok!==true)throw new Error(result.error||'Drive menolak permintaan.');return result.result;
}
export async function handle(request,env){
  if(new URL(request.url).pathname==='/guest-check-in')return handleGuestCheckin(request,env);
  const origin=request.headers.get('origin')||'',allowed=(env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim());
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
  if(origin&&allowed.includes(origin))Object.assign(headers,{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS'});
  const reply=(status,value)=>new Response(JSON.stringify(value),{status,headers});
  if(origin&&!allowed.includes(origin))return reply(403,{error:'Alamat aplikasi belum diizinkan.'});
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(request.method!=='POST')return reply(405,{error:'Metode tidak diizinkan.'});
  try{
    if(!env.DB||!env.OWNER_EMAIL||!env.SUPABASE_URL||!env.SUPABASE_PUBLISHABLE_KEY)return reply(503,{error:'Database Cloudflare belum dipasang.'});
    if(!request.headers.get('authorization')){
      const input=await request.json();if(input.method!=='loginAccount')return reply(401,{error:'Silakan masuk terlebih dahulu.'});
      const ip=await digest(request.headers.get('cf-connecting-ip')||'unknown'),minute=Math.floor(Date.now()/60000);
      const count=await env.DB.prepare('INSERT INTO wedding_limits VALUES(?,?,1) ON CONFLICT(user_id) DO UPDATE SET minute=excluded.minute,requests=CASE WHEN wedding_limits.minute=excluded.minute THEN wedding_limits.requests+1 ELSE 1 END WHERE wedding_limits.minute<>excluded.minute OR wedding_limits.requests<=10 RETURNING requests').bind('login:'+ip,minute).first();
      if(!count||count.requests>10)return reply(429,{error:'Terlalu banyak percobaan login. Tunggu satu menit.'});
      const r=input.payload||{},identifier=String(r.email||'').trim().toLowerCase();if(identifier.length>250||typeof r.password!=='string'||r.password.length>128)return reply(400,{error:'Data login tidak valid.'});
      const state=await env.DB.prepare('SELECT * FROM wedding_state WHERE id=1').first(),data=JSON.parse(state.data);
      const loginEmail=identifier.includes('@')?identifier:identifier===data._ownerProfile?.username?env.OWNER_EMAIL:data.users.find(x=>x.username===identifier)?.email||identifier+'@users.siapnikah.app';
      const response=await fetch(env.SUPABASE_URL+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:loginEmail,password:r.password}),signal:AbortSignal.timeout(20000)});
      if(!response.ok)return reply(401,{error:'Username atau password tidak sesuai.'});const session=await response.json();try{actorFor(data,session.user.email.toLowerCase(),env.OWNER_EMAIL.toLowerCase());}catch{return reply(403,{error:'Akses akun tidak aktif.'});}return reply(200,session);
    }
    const authorization=request.headers.get('authorization')||'';if(!/^Bearer \S+$/.test(authorization))return reply(401,{error:'Silakan masuk terlebih dahulu.'});
    const auth=await fetch(env.SUPABASE_URL+'/auth/v1/user',{headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,Authorization:authorization},signal:AbortSignal.timeout(10000)});
    if(!auth.ok)return reply(401,{error:'Sesi berakhir. Silakan masuk kembali.'});
    const user=await auth.json();if(!user.id||!user.email_confirmed_at||!user.email)return reply(401,{error:'Email akun belum dikonfirmasi.'});
    const email=user.email.toLowerCase(),minute=Math.floor(Date.now()/60000);
    const limit=await env.DB.prepare('INSERT INTO wedding_limits VALUES(?,?,1) ON CONFLICT(user_id) DO UPDATE SET minute=excluded.minute,requests=CASE WHEN wedding_limits.minute=excluded.minute THEN wedding_limits.requests+1 ELSE 1 END WHERE wedding_limits.minute<>excluded.minute OR wedding_limits.requests<=60 RETURNING requests').bind(user.id,minute).first();
    if(!limit||limit.requests>60)return reply(429,{error:'Terlalu banyak permintaan. Tunggu satu menit.'});
    const raw=await request.text();if(raw.length>7200000)return reply(413,{error:'Berkas maksimal 5 MB.'});
    let input;try{input=JSON.parse(raw);}catch{return reply(400,{error:'Permintaan tidak valid.'});}
    if(!methods.has(input.method))return reply(400,{error:'Metode tidak diizinkan.'});
    const state=await env.DB.prepare('SELECT * FROM wedding_state WHERE id=1').first();if(!state)throw new Error('Schema database belum dipasang.');
    const data=JSON.parse(state.data),actor=actorFor(data,email,env.OWNER_EMAIL.toLowerCase());
    if(['getGuestCheckin','setGuestCheckin'].includes(input.method)){
      if(!C.can(actor,'guests',false))return reply(403,{error:'Tidak memiliki akses Buku Tamu.'});
      if(input.method==='setGuestCheckin'){
        if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mengaktifkan QR.'});
        const r=input.payload||{};if(typeof r.enabled!=='boolean'||!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Pengaturan QR tidak valid.');
        data._guestCheckin={enabled:r.enabled,token:data._guestCheckin?.token||crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-','')};
        const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(JSON.stringify(data),r.requestId,email,await digest(raw),new Date().toISOString(),state.version).first();if(!saved)return reply(409,{error:'Data berubah. Coba kembali.'});
      }
      const config=data._guestCheckin,enabled=!!(config?.enabled);
      return reply(200,{enabled,url:enabled?new URL('/guest-check-in?token='+config.token,request.url).href:null});
    }
    if(input.method==='exportBackup'){

      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mencadangkan seluruh data.'});
      return reply(200,{schema:'siap-nikah-backup-v1',exportedAt:new Date().toISOString(),version:state.version,data});
    }
    if(input.method==='checkAccountService'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat menguji layanan akun.'});
      if(!env.SUPABASE_SECRET_KEY)return reply(503,{error:'Secret Supabase belum dipasang.'});
      const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users?page=1&per_page=1',{headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY},signal:AbortSignal.timeout(10000)});
      if(!response.ok)return reply(502,{error:'Secret Supabase belum dapat mengakses layanan akun. Status '+response.status+'.'});
      const result=await response.json();if(!Array.isArray(result.users))return reply(502,{error:'Respons layanan akun belum valid.'});
      return reply(200,{ok:true,message:'Layanan akun terhubung. Secret Supabase valid.'});
    }
    if(input.method==='createUserAccount'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat membuat akun.'});
      if(!env.SUPABASE_SECRET_KEY)return reply(503,{error:'Pembuatan akun belum aktif. Pasang SUPABASE_SECRET_KEY di Cloudflare.'});
      const r=input.payload||{},name=String(r.name||'').trim(),username=String(r.username||'').trim().toLowerCase();
      if(!name||name.length>100||!/^[a-z0-9._-]{3,30}$/.test(username))throw new Error('Isi nama dan username 3–30 karakter (huruf, angka, titik, _ atau -).');
      if(typeof r.password!=='string'||r.password.length<8||r.password.length>128)throw new Error('Password harus 8–128 karakter.');
      if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),previous=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();
      if(previous){if(previous.actor!==email||previous.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
      const memberEmail=username+'@users.siapnikah.app';if(data.users.some(x=>x.username===username||x.email===memberEmail))throw new Error('Username sudah digunakan.');
      const id=crypto.randomUUID(),stamp=new Date().toISOString();
      C.mutate(data,{collection:'users',id,version:0,action:'save',data:{name,username,email:memberEmail,role:r.role||'Panitia',status:'Aktif',permissions:r.permissions||'{}',notes:''}},stamp);
      data._userHistory=(data._userHistory||[]).concat({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Membuat akun · '+username,timestamp:stamp,notes:'',version:1}).slice(-500);
      const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users',{method:'POST',headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:memberEmail,password:r.password,email_confirm:true,user_metadata:{name,username}}),signal:AbortSignal.timeout(20000)});
      if(!response.ok)throw new Error(response.status===422?'Username sudah terdaftar di layanan login.':'Layanan login belum dapat membuat akun. Periksa secret Supabase.');
      const created=await response.json();if(!created.id)throw new Error('Pembuatan akun login belum terkonfirmasi.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,stamp,state.version).first();
      if(!saved)return reply(409,{error:'Akun login sudah dibuat, tetapi akses belum tersimpan karena data berubah. Tambahkan akses untuk '+memberEmail+' melalui pengaturan pengguna.'});
      return reply(200,{data:C.visible(data,actor)});
    }
    if(input.method==='updateUserAccount'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mengedit akun.'});
      const r=input.payload||{},name=String(r.name||'').trim(),username=String(r.username||'').trim().toLowerCase(),owner=r.id==='owner';
      if(!name||name.length>100||!/^[a-z0-9._-]{3,30}$/.test(username))throw new Error('Nama wajib diisi. Username 3–30 karakter.');
      if(r.password&&(typeof r.password!=='string'||r.password.length<8||r.password.length>128))throw new Error('Password baru harus 8–128 karakter.');
      if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),prior=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();if(prior){if(prior.actor!==email||prior.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
      const member=owner?null:data.users.find(x=>x.id===r.id);if(!owner&&(!member||member.version!==r.version))throw new Error('Akun berubah. Muat ulang.');
      if(data.users.some(x=>x.id!==r.id&&x.username===username)||(!owner&&data._ownerProfile?.username===username))throw new Error('Username sudah digunakan.');
      const stamp=new Date().toISOString();if(owner)data._ownerProfile={...data._ownerProfile,name,username};else C.mutate(data,{collection:'users',id:r.id,version:r.version,action:'save',data:{...member,name,username,role:r.role,status:r.status,permissions:r.permissions}},stamp);
      if(r.password){
        if(!env.SUPABASE_SECRET_KEY)return reply(503,{error:'Secret Supabase belum dipasang.'});let authId=owner?user.id:null;
        for(let page=1;page<=20&&!authId;page++){const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users?page='+page+'&per_page=100',{headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY},signal:AbortSignal.timeout(10000)});if(!response.ok)throw new Error('Layanan login belum dapat dihubungi.');const list=await response.json();authId=list.users?.find(x=>x.email===member.email)?.id;if((list.users||[]).length<100)break;}
        if(!authId)throw new Error('Akun login tidak ditemukan.');const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users/'+authId,{method:'PUT',headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({password:r.password,user_metadata:{name,username}}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('Password belum berhasil diubah.');
      }
      data._userHistory=(data._userHistory||[]).concat({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Mengedit akun dan akses · '+username,timestamp:stamp,notes:'',version:1}).slice(-500);const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,stamp,state.version).first();if(!saved)return reply(409,{error:'Data akun berubah. Muat ulang. Jika password diisi, password tersebut sudah diperbarui.'});return reply(200,{data:C.visible(data,actor)});
    }
    if(input.method==='getUserHistory'){if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat melihat riwayat pengguna.'});return reply(200,{history:(data._userHistory||[]).filter(x=>!x.deleted),ownerProfile:data._ownerProfile||{name:'Akun utama'}});}
    if(['changeUserHistory','recordLogin','saveOwnerProfile'].includes(input.method)){
      if(input.method!=='recordLogin'&&!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mengelola pengguna dan riwayat.'});
      const r=input.payload||{};if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),previous=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();if(previous){if(previous.actor!==email||previous.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{ok:true,duplicate:true});}
      const at=new Date().toISOString();data._userHistory=data._userHistory||[];
      if(input.method==='recordLogin')data._userHistory.push({id:crypto.randomUUID(),email,type:'Login',action:'Masuk ke aplikasi',timestamp:at,notes:'',version:1});
      if(input.method==='saveOwnerProfile'){const name=String(r.name||'').trim();if(!name||name.length>100)throw new Error('Nama wajib diisi, maksimal 100 karakter.');data._ownerProfile={...data._ownerProfile,name};data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Mengubah nama akun utama',timestamp:at,notes:'',version:1});}
      if(input.method==='changeUserHistory'){const item=data._userHistory.find(x=>x.id===r.id&&!x.deleted);if(!item||item.version!==r.version)throw new Error('Riwayat berubah. Muat ulang.');if(!['edit','delete'].includes(r.action))throw new Error('Tindakan tidak valid.');if(r.action==='delete')item.deleted=true;else{const notes=String(r.notes||'').trim();if(notes.length>1000)throw new Error('Catatan maksimal 1.000 karakter.');item.notes=notes;}item.version++;item.edited_at=at;data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:r.action==='delete'?'Menghapus riwayat dari tampilan':'Mengedit catatan riwayat',timestamp:at,notes:'',version:1});}
      data._userHistory=data._userHistory.slice(-500);const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,at,state.version).first();if(!saved)return reply(409,{error:'Data berubah. Muat ulang sebelum mencoba lagi.'});return reply(200,{ok:true});
    }
    if(input.method==='loadData')return reply(200,{data:C.visible(data,actor),actor,email,mode:'cloudflare',serverTime:new Date().toISOString()});
    const req=input.payload;if(!req||!Object.hasOwn(C.modules,req.collection)||!C.can(actor,req.collection,input.method!=='getAttachment'))return reply(403,{error:'Anda tidak memiliki izin untuk modul ini.'});
    const record=data[req.collection].find(x=>x.id===req.id);
    if(input.method==='getAttachment'){
      const file=record?.files?.find(x=>x.id===req.fileId);if(!file)throw new Error('Lampiran tidak tersedia.');
      return reply(200,await drive(env,email,'cloudGetFile',{fileId:file.id,name:file.name}));
    }
    if(!/^[\w-]{16,80}$/.test(req.requestId||''))throw new Error('Identitas permintaan tidak valid.');
    const fingerprint=await digest(raw),prior=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(req.requestId).first();
    if(prior){if(prior.actor!==email||prior.fingerprint!==fingerprint)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
    if(req.collection==='users'&&String(req.data?.email||'').toLowerCase()===env.OWNER_EMAIL.toLowerCase())throw new Error('Akun utama tidak dapat diganti.');
    const stamp=new Date().toISOString();
    if(input.method==='changeData')C.mutate(data,req,stamp);
    else{
      if(!record||record.version!==req.version)throw new Error('Catatan berubah. Muat ulang sebelum unggah.');
      if(req.replaceFileId&&!record.files?.some(x=>x.id===req.replaceFileId))throw new Error('Lampiran pengganti tidak tersedia.');
      if((record.files||[]).length>=10&&!req.replaceFileId)throw new Error('Maksimal 10 lampiran.');
      if(req.collection==='budget'&&!['application/pdf','image/jpeg','image/png'].includes(req.mime))throw new Error('Invoice harus PDF, JPG atau PNG.');
      const file=await drive(env,email,'cloudUploadFile',req);
      record.files=[...(record.files||[]).filter(x=>x.id!==req.replaceFileId),file];if(req.collection==='admin')record.available=true;record.version++;record.updated_at=stamp;
    }
    data._userHistory=data._userHistory||[];data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:(input.method==='uploadAttachment'?'Mengunggah lampiran':req.action==='delete'?'Menghapus catatan':'Mengubah catatan')+' · '+C.modules[req.collection].title,timestamp:stamp,notes:'',version:1});data._userHistory=data._userHistory.slice(-500);
    const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai. Ekspor dan arsipkan data lama.');
    const result=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,req.requestId,email,fingerprint,stamp,state.version).first();
    if(!result)return reply(409,{error:'Data berubah saat disimpan. Muat ulang; periksa hasil sebelum mengulangi.'});
    return reply(200,{data:C.visible(data,actor)});
  }catch(error){return reply(400,{error:error.message||'Penyimpanan belum terkonfirmasi.'});}
}
async function handleGuestCheckin(request,env){
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'};const reply=(status,value)=>new Response(JSON.stringify(value),{status,headers});
 try{
  if(!env.DB)return reply(503,{error:'Buku Tamu belum tersedia.'});
  const state=await env.DB.prepare('SELECT * FROM wedding_state WHERE id=1').first();if(!state)return reply(503,{error:'Buku Tamu belum tersedia.'});
  const data=JSON.parse(state.data);
  const cookie=(request.headers.get('cookie')||'').match(/(?:^|;\s*)SN_GUEST_DEVICE=([a-f0-9-]{36})(?:;|$)/)?.[1];
  const device=cookie||crypto.randomUUID(),deviceKey=await digest('guest-device:'+device);
  if(request.method==='GET'){
   if(!activeGuestQr(data,new URL(request.url).searchParams.get('token')))return new Response('QR tidak aktif atau sudah kedaluwarsa. Hubungi panitia.',{status:410,headers:{...headers,'Content-Type':'text/plain;charset=utf-8'}});
   const form=data._guestCheckinDevices?.includes(deviceKey)?guestForm.replace('<form id="guest-form">','<form id="guest-form" hidden>').replace('<div id="message" role="status" aria-live="polite"></div>','<div id="message" role="status" aria-live="polite">Kehadiran dari perangkat ini sudah tercatat. Untuk perubahan, hubungi panitia.</div>'):guestForm;
   return new Response(form,{headers:{...headers,'Set-Cookie':'SN_GUEST_DEVICE='+device+'; Max-Age=31536000; Path=/guest-check-in; Secure; HttpOnly; SameSite=Lax','Content-Type':'text/html;charset=utf-8','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"}});
  }
  if(request.method!=='POST')return reply(405,{error:'Metode tidak diizinkan.'});
  const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return reply(403,{error:'Kirim melalui form Buku Tamu.'});
  if(Number(request.headers.get('content-length'))>2800000)return reply(413,{error:'Bukti maksimal 2 MB.'});
  const reader=request.body?.getReader();if(!reader)return reply(400,{error:'Isian kosong.'});
  const decoder=new TextDecoder();let raw='',size=0;
  for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>2800000){await reader.cancel();return reply(413,{error:'Bukti maksimal 2 MB.'});}raw+=decoder.decode(value,{stream:true});}raw+=decoder.decode();const input=JSON.parse(raw);
  if(!activeGuestQr(data,input.token))return reply(410,{error:'QR tidak aktif atau sudah kedaluwarsa. Hubungi panitia.'});
  if(!cookie)return reply(400,{error:'Buka ulang form QR dan izinkan cookie untuk mencatat kehadiran.'});
  const values=guestInput(input),transfer=guestTransfer(input),key=guestKey(values.name,values.contact),fingerprint=await digest(JSON.stringify({key,address:values.address,transfer}));
  const prior=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(input.requestId).first();if(prior)return prior.actor==='guest-qr'&&prior.fingerprint===fingerprint?reply(200,{ok:true}):reply(409,{error:'Muat ulang form sebelum mencoba lagi.'});
  if(data._guestCheckinDevices?.includes(deviceKey))return reply(409,{code:'already_registered',error:'Kehadiran dari perangkat ini sudah tercatat. Untuk perubahan, hubungi panitia.'});
  const minute=Math.floor(Date.now()/60000),ip=await digest(request.headers.get('cf-connecting-ip')||'unknown');const limit=await env.DB.prepare('INSERT INTO wedding_limits VALUES(?,?,1) ON CONFLICT(user_id) DO UPDATE SET minute=excluded.minute,requests=CASE WHEN wedding_limits.minute=excluded.minute THEN wedding_limits.requests+1 ELSE 1 END WHERE wedding_limits.minute<>excluded.minute OR wedding_limits.requests<=5 RETURNING requests').bind('guest:'+ip,minute).first();if(!limit||limit.requests>5)return reply(429,{error:'Tunggu satu menit lalu coba kembali, atau hubungi panitia.'});
  const existing=data.guests.find(row=>guestKey(row.name,row.contact)===key);if(existing&&!C.attendance(existing).length)return reply(409,{error:'Silakan konfirmasi kehadiran melalui panitia; data Anda sudah terdaftar.'});
  if(data.guests.length>=3000)return reply(429,{error:'Hubungi panitia untuk pencatatan kehadiran.'});
  if(existing&&transfer.amount)return reply(409,{error:'Kehadiran Anda sudah tercatat. Hubungi panitia untuk mencatat transfer.'});
  // Validate and apply the guest locally before uploading; no public Drive reads.
  let added;
  if(!existing){const id=crypto.randomUUID();C.mutate(data,{collection:'guests',action:'save',id,version:0,data:{...values,group:'Tamu langsung',event:'Resepsi',quota:1,attending:1,status:'Hadir',deliveryStatus:'Belum dikirim',notes:'Tamu datang langsung melalui QR. Pemberian belum dicatat.'+(transfer.amount?' Transfer BCA: '+transfer.amount.toLocaleString('id-ID')+' — Menunggu verifikasi panitia.':''),attendanceLedger:JSON.stringify([{id:crypto.randomUUID(),name:values.name,kind:'Belum dicatat',cash:0,goods:''}])}},new Date().toISOString());added=data.guests.find(row=>row.id===id);}
  if(added&&transfer.amount)added.qrTransfer={amount:transfer.amount,status:'pending',personId:C.attendance(added)[0].id,submittedAt:new Date().toISOString()};
  if(transfer.proof){const file=await drive(env,env.OWNER_EMAIL,'cloudUploadFile',{...transfer.proof,requestId:'guest-proof-'+(await digest(input.requestId)).slice(0,48)});added.files=[file];}
  data._guestCheckinDevices=[...(data._guestCheckinDevices||[]),deviceKey];
  const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)return reply(429,{error:'Hubungi panitia untuk pencatatan kehadiran.'});
  const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,input.requestId,'guest-qr',fingerprint,new Date().toISOString(),state.version).first();if(!saved)return reply(409,{error:'Pencatatan sedang ramai. Coba lagi; data tidak akan digandakan.'});return reply(200,{ok:true});
 }catch{return reply(400,{error:'Isian belum tersimpan. Periksa nama, alamat, dan nomor HP.'});}
}
export default {fetch:handle};
