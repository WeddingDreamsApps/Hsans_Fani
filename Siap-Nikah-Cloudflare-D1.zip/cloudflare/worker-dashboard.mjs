/* Shared business rules for the Apps Script runtime, browser preview and tests. */
var WeddingCore = (function () {
  'use strict';
  const modules = {
    admin: {title:'Peta Persiapan',sheet:'SN_Administrasi',fields:['name','requirementType','available','owner','date','status','source','notes']},
    profile: {title:'Data Mempelai',sheet:'SN_Mempelai',fields:['name','partner','date','location','budget','target','invitationUrl','notes']},
    budget: {title:'Budget & Pengeluaran',sheet:'SN_Anggaran',fields:['name','category','amount','date','owner','notes']},
    savings: {title:'Tabungan',sheet:'SN_Tabungan',fields:['name','type','amount','date','owner','notes']},
    gifts: {title:'Seserahan & Mahar',sheet:'SN_Seserahan',fields:['name','type','itemGroup','quantity','amount','paymentStatus','status','shopUrl','owner','notes']},
    vendors: {title:'Vendor & Venue',sheet:'SN_Vendor',fields:['name','category','contact','location','amount','capacity','status','notes']},
    guests: {title:'Daftar Undangan',sheet:'SN_Undangan',fields:['name','group','contact','event','quota','attending','status','deliveryStatus','address','attendanceLedger','notes']},
    tasks: {title:'Timeline Checklist',sheet:'SN_Checklist',fields:['name','owner','date','priority','status','notes']},
    rundown: {title:'Rundown & Panitia',sheet:'SN_Rundown',fields:['name','event','start','end','owner','location','contact','status','notes']},
    users: {title:'Manajemen Pengguna',sheet:'SN_Pengguna',fields:['name','username','email','role','status','permissions','notes']}
  };
  const statuses = {
    gifts:['Direncanakan','Disiapkan','Dikemas','Diserahkan'],
    vendors:['Kandidat','Dihubungi','Negosiasi','Dipilih','Selesai','Dibatalkan'],
    admin:['Belum disiapkan','Disiapkan','Perlu perbaikan','Diajukan','Selesai','Tidak berlaku'],
    guests:['Belum dikirim','Dikirim','Hadir','Tidak hadir','Belum pasti'],
    tasks:['Belum mulai','Berlangsung','Terhambat','Selesai','Tidak berlaku'],
    rundown:['Draf','Final'],
    users:['Aktif','Nonaktif']
  };
  function blank(){return Object.fromEntries(Object.keys(modules).map(k=>[k,[]]));}
  function money(n){return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0);}
  function requireThat(ok,msg){if(!ok)throw new Error(msg);}
  function amount(v,label){const n=Number(v||0);requireThat(Number.isSafeInteger(n)&&n>=0&&n<=1000000000000,(label||'Nominal')+' harus berupa bilangan bulat 0–1 triliun.');return n;}
  function validate(key,input){
    requireThat(Object.hasOwn(modules,key),'Modul tidak dikenal.');
    const out={};
    for(const field of modules[key].fields){
      const value=input[field];
      if(field==='available')out[field]=value===true||value==='true'||value==='on';
      else if(['amount','budget','target','quota','attending','capacity','quantity'].includes(field))out[field]=amount(value,field);
      else {requireThat(value==null||typeof value==='string','Format kolom tidak valid.');out[field]=String(value||'').trim();requireThat(out[field].length<=(field==='attendanceLedger'?30000:field==='notes'?3000:field==='permissions'?3000:field.endsWith('Url')?1000:250),'Teks terlalu panjang.');}
    }
    requireThat(out.name.length>0,'Nama atau judul wajib diisi.');
    if(out.date)requireThat(/^\d{4}-\d{2}-\d{2}$/.test(out.date)&&!isNaN(Date.parse(out.date)),'Tanggal tidak valid.');
    if(statuses[key])requireThat(statuses[key].includes(out.status),'Status tidak valid.');
    if(key==='savings')requireThat(['Setoran','Penarikan'].includes(out.type),'Jenis transaksi tidak valid.');
    if(key==='gifts'){
      requireThat(['Seserahan','Mahar'].includes(out.type)&&out.quantity>0,'Jenis dan jumlah barang wajib diisi.');
      out.paymentStatus=out.paymentStatus||'Belum dibayar';
      requireThat(['Belum dibayar','Proses pembayaran','DP / sebagian','Lunas','Hadiah / tanpa biaya'].includes(out.paymentStatus),'Status pembayaran tidak valid.');
      out.itemGroup=out.itemGroup||'Lainnya';
    }
    if(key==='admin'){out.requirementType=out.requirementType||'Umum';requireThat(['Umum','Bersyarat','Tahapan'].includes(out.requirementType),'Jenis persyaratan tidak valid.');}
    if(key==='guests'){out.deliveryStatus=out.deliveryStatus||'Belum dikirim';requireThat(['Belum dikirim','Dikirim','Dibuka'].includes(out.deliveryStatus),'Status pengiriman tidak valid.');}
    if(key==='users'){
      out.username=out.username.toLowerCase();requireThat(!out.username||/^[a-z0-9._-]{3,30}$/.test(out.username),'Username harus 3–30 karakter.');out.email=out.email.toLowerCase();requireThat(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.email),'Email pengguna tidak valid.');
      requireThat(['Pasangan','Koordinator','Panitia','Pembaca'].includes(out.role),'Peran tidak valid.');
      let perms;try{perms=JSON.parse(out.permissions||'{}');}catch(e){throw new Error('Pengaturan akses tidak valid.');}
      requireThat(perms&&typeof perms==='object'&&!Array.isArray(perms),'Pengaturan akses tidak valid.');
      Object.entries(perms).forEach(([k,v])=>requireThat(Object.hasOwn(modules,k)&&k!=='users'&&['none','read','write'].includes(v),'Izin modul tidak valid.'));
      out.permissions=JSON.stringify(perms);
    }
    if(key==='tasks')requireThat(['Normal','Tinggi'].includes(out.priority),'Prioritas tidak valid.');
    if(key==='guests'){
      requireThat(out.quota>0&&out.quota<=100,'Kuota undangan harus 1–100 orang.');
      requireThat(out.attending<=out.quota,'Jumlah hadir melebihi kuota.');
      requireThat(out.status==='Hadir'||out.attending===0,'Isi jumlah hadir hanya untuk status Hadir.');
      requireThat(out.event.length>0,'Nama acara wajib diisi.');
      let ledger;try{ledger=JSON.parse(out.attendanceLedger||'[]');}catch(e){throw new Error('Catatan kehadiran tidak valid.');}
      requireThat(Array.isArray(ledger)&&ledger.length<=out.quota,'Jumlah tamu yang tercatat hadir melebihi kuota.');
      const ids=new Set();
      ledger=ledger.map(person=>{
        requireThat(person&&typeof person==='object','Catatan tamu tidak valid.');
        const id=String(person.id||''),name=String(person.name||'').trim(),kind=String(person.kind||''),goods=String(person.goods||'').trim(),cash=amount(person.cash,'Uang tamu');
        requireThat(/^[\w-]{5,80}$/.test(id)&&!ids.has(id),'ID tamu hadir tidak valid atau duplikat.');ids.add(id);
        requireThat(name.length>0&&name.length<=250,'Nama setiap tamu yang hadir wajib diisi.');
        requireThat(['Uang','Barang','Uang & barang','Tidak memberi'].includes(kind),'Jenis pemberian setiap tamu wajib dipilih.');
        requireThat(goods.length<=3000,'Catatan barang terlalu panjang.');
        requireThat((kind==='Uang'||kind==='Uang & barang')?cash>0:cash===0,'Nominal uang harus sesuai jenis pemberian.');
        requireThat((kind==='Barang'||kind==='Uang & barang')?goods.length>0:goods.length===0,'Rincian barang harus sesuai jenis pemberian.');
        return {id,name,kind,cash,goods};
      });
      out.attendanceLedger=JSON.stringify(ledger);
    }
    if(key==='rundown')requireThat(out.start&&out.end&&Number.isFinite(Date.parse(out.start))&&Number.isFinite(Date.parse(out.end))&&out.end>out.start,'Waktu selesai harus setelah waktu mulai.');
    for(const f of ['source','shopUrl','invitationUrl'])if(out[f])requireThat(/^https:\/\/[^\s]+$/.test(out[f]),'Tautan harus berupa HTTPS yang valid.');
    return out;
  }
  function netPaid(item){return(item.payments||[]).reduce((s,p)=>s+(p.type==='refund'?-p.amount:p.amount),0);}
  function attendance(guest){try{const rows=JSON.parse(guest.attendanceLedger||'[]');return Array.isArray(rows)?rows:[];}catch(e){return [];}}
  function preparationCost(record){const raw=(record?.source||'').match(/[#&]biaya=(\d+)(?:&|$)/)?.[1];if(raw===undefined)return null;const value=Number(raw);return Number.isSafeInteger(value)&&value>=0&&value<=1000000000000?value:null;}
  function taskCost(record){let m;try{m=JSON.parse(record.notes||'');}catch{return null;}const cost=m?.schema==='timeline-v1'?m.cost:null;return Number.isSafeInteger(cost)&&cost>=0&&cost<=1000000000000?cost:null;}
  function checkTask(record,rows){
    let meta;try{meta=JSON.parse(record.notes||'');}catch{return;}
    if(meta?.schema!=='timeline-v1')return;
    requireThat(Array.isArray(meta.dependencies)&&meta.dependencies.length<=100&&Array.isArray(meta.subtasks)&&meta.subtasks.length<=20,'Subtugas atau ketergantungan tidak valid.');
    requireThat(meta.subtasks.every(x=>x&&typeof x.name==='string'&&x.name.trim()&&x.name.length<=100&&typeof x.done==='boolean'),'Subtugas tidak valid.');
    requireThat(meta.cost==null||(Number.isSafeInteger(meta.cost)&&meta.cost>=0&&meta.cost<=1000000000000),'Biaya tugas tidak valid.');
    const visit=(id,seen)=>{requireThat(typeof id==='string'&&id!==record.id,'Ketergantungan tugas membentuk lingkaran.');if(seen.has(id))return;seen.add(id);const row=rows.find(x=>x.id===id);requireThat(row,'Tugas pendahulu tidak ditemukan.');let next;try{next=JSON.parse(row.notes||'');}catch{}if(next?.schema==='timeline-v1'&&Array.isArray(next.dependencies))next.dependencies.forEach(v=>visit(v,seen));};
    meta.dependencies.forEach(id=>visit(id,new Set()));
    if(record.status==='Selesai'){
      requireThat(meta.subtasks.every(x=>x.done),'Selesaikan seluruh subtugas terlebih dahulu.');
      requireThat(meta.dependencies.every(id=>rows.some(x=>x.id===id&&['Selesai','Tidak berlaku'].includes(x.status))),'Selesaikan tugas pendahulu terlebih dahulu.');
    }
  }
  function financeRows(db){
    const gifts=db.gifts||[],tasks=db.tasks||[],vendors=db.vendors||[],budget=db.budget||[],result=budget.map(record=>{
      const gift=gifts.find(item=>'linked-gifts-'+item.id===record.id);
      const task=tasks.find(item=>'linked-tasks-'+item.id===record.id);
      const vendor=vendors.find(item=>'linked-vendors-'+item.id===record.id);
      if(vendor)return {...record,name:vendor.name,amount:vendor.amount,category:vendor.category,sourceKey:'vendors',sourceId:vendor.id,ledgerId:record.id};
      if(task)return {...record,name:task.name,amount:taskCost(task)??record.amount,owner:task.owner||record.owner,sourceKey:'tasks',sourceId:task.id,ledgerId:record.id};
      return {...record,...(gift?{name:gift.name,amount:gift.amount,category:gift.type}:{}),sourceKey:gift?'gifts':'budget',sourceId:gift?gift.id:record.id,ledgerId:record.id};
    });
    gifts.forEach(gift=>{if(!budget.some(record=>record.id==='linked-gifts-'+gift.id))result.push({id:'linked-gifts-'+gift.id,name:gift.name,category:gift.type,amount:gift.amount||0,date:'',owner:gift.owner||'',payments:[],files:[],sourceKey:'gifts',sourceId:gift.id,ledgerId:null});});
    tasks.forEach(task=>{const cost=taskCost(task);if(cost>0&&!budget.some(record=>record.id==='linked-tasks-'+task.id))result.push({id:'linked-tasks-'+task.id,name:task.name,category:'Lainnya',amount:cost,date:task.date||'',owner:task.owner||'',payments:[],files:[],sourceKey:'tasks',sourceId:task.id,ledgerId:null});});
    (db.admin||[]).forEach(record=>{const cost=preparationCost(record);if(cost!==null)result.push({id:'preparation-'+record.id,name:record.name,category:'Administrasi',amount:cost,date:record.date||'',owner:record.owner||'',payments:[],files:[],sourceKey:'admin',sourceId:record.id,ledgerId:null});});
    return result;
  }
  function financePaid(record){return record.sourceKey==='admin'?record.amount:netPaid(record);}
  function paidFinanceRows(db){return financeRows(db).filter(record=>financePaid(record)>0);}
  function totals(db){
    const p=db.profile[0]||{};const costs=financeRows(db);
    const preparationPaid=costs.filter(record=>record.sourceKey==='admin').reduce((sum,record)=>sum+financePaid(record),0);
    const spent=costs.reduce((s,x)=>s+financePaid(x),0);
    const fromSavings=costs.reduce((s,x)=>s+(x.payments||[]).reduce((a,p)=>a+(p.source==='Tabungan'?(p.type==='refund'?-p.amount:p.amount):0),0),0);
    const deposits=db.savings.reduce((s,x)=>s+(x.type==='Setoran'?x.amount:-x.amount),0);
    const tasks=db.tasks.filter(x=>x.status!=='Tidak berlaku');
    const visitors=(db.guests||[]).flatMap(attendance);
    const guestCash=visitors.reduce((s,x)=>s+Number(x.cash||0),0),guestGoods=visitors.filter(x=>x.goods).length;
    return {checkedIn:visitors.length,guestCash,guestGoods,netEventCash:guestCash-spent,budget:p.budget||0,committed:costs.reduce((s,x)=>s+x.amount,0),preparationPaid,paid:spent,due:costs.reduce((s,x)=>s+Math.max(0,x.amount-financePaid(x)),0),credit:costs.reduce((s,x)=>s+Math.max(0,financePaid(x)-x.amount),0),savings:deposits-fromSavings,target:p.target||0,invites:db.guests.length,quota:db.guests.reduce((s,x)=>s+x.quota,0),attending:db.guests.reduce((s,x)=>s+x.attending,0),tasks:tasks.length,done:tasks.filter(x=>x.status==='Selesai').length};
  }
  function mutate(db,req,now){
    requireThat(req&&typeof req==='object','Permintaan tidak valid.');
    requireThat(Object.hasOwn(modules,req.collection),'Modul tidak dikenal.');
    requireThat(typeof req.id==='string'&&/^[\w-]{5,80}$/.test(req.id),'ID tidak valid.');
    const rows=db[req.collection];const index=rows.findIndex(x=>x.id===req.id);const old=rows[index];
    requireThat((old?old.version:0)===req.version,'Data telah berubah. Muat ulang sebelum menyimpan kembali.');
    let record;
    if(req.action==='delete'){
      requireThat(old,'Catatan tidak ditemukan.');
      requireThat(req.collection!=='profile','Profil tidak dapat dihapus.');
      requireThat(!['budget','savings'].includes(req.collection),'Catatan keuangan tidak dapat dihapus.');
      rows.splice(index,1);return {deleted:true,old};
    }
    if(['fileEdit','fileUnlink'].includes(req.action)){
      requireThat(old,'Catatan tidak ditemukan.');
      const files=[...(old.files||[])];const pos=files.findIndex(f=>f.id===req.fileId);
      requireThat(pos>=0,'Lampiran tidak ditemukan.');
      if(req.action==='fileUnlink')files.splice(pos,1);
      else {const name=String(req.fileName||'').trim();requireThat(name.length>0&&name.length<=120,'Nama lampiran harus 1–120 karakter.');files[pos]={...files[pos],name};}
      record={...old,files};
    }else if(req.action==='payment'){
      requireThat(req.collection==='budget'&&old,'Item biaya tidak ditemukan.');
      const p=req.payment||{};const value=amount(p.amount);
      requireThat(value>0,'Nominal pembayaran harus lebih dari nol.');
      requireThat(['payment','refund'].includes(p.type)&&['Tabungan','Dana lain'].includes(p.source),'Jenis/sumber pembayaran tidak valid.');
      requireThat(/^\d{4}-\d{2}-\d{2}$/.test(p.date)&&!isNaN(Date.parse(p.date)),'Tanggal pembayaran wajib diisi.');
      if(p.type==='refund'){
        const available=(old.payments||[]).filter(x=>x.source===p.source).reduce((s,x)=>s+(x.type==='refund'?-x.amount:x.amount),0);
        requireThat(value<=available,'Refund melebihi pembayaran dari sumber dana ini.');
      }
      if(p.type==='payment'&&p.source==='Tabungan')requireThat(value<=totals(db).savings,'Saldo tabungan belum cukup.');
      if(p.type==='payment'&&netPaid(old)+value>old.amount)requireThat(p.allowOverpay===true,'Pembayaran melebihi komitmen. Konfirmasikan kelebihan bayar.');
      record={...old,payments:[...(old.payments||[]),{id:req.requestId,type:p.type,source:p.source,amount:value,date:p.date,note:String(p.note||'').slice(0,500)}]};
    }else{
      requireThat(req.action==='save','Tindakan tidak dikenal.');
      requireThat(!(req.collection==='savings'&&old),'Transaksi tabungan tidak diubah; tambahkan transaksi koreksi.');
      requireThat(req.collection!=='profile'||rows.length===0||!!old,'Hanya satu profil pasangan per spreadsheet.');
      record={...old,...validate(req.collection,req.collection==='guests'?{...old,...req.data}:req.data||{}),id:req.id};
      if(req.collection==='budget'&&req.initialPayment){
        requireThat(!old,'Pembayaran awal hanya untuk item biaya baru.');
        const pay=req.initialPayment,value=amount(pay.amount,'Pembayaran awal');
        requireThat(value>0&&value<=record.amount,'Pembayaran awal harus positif dan tidak melebihi biaya.');
        requireThat(['Tabungan','Dana lain'].includes(pay.source),'Sumber dana tidak valid.');
        requireThat(/^\d{4}-\d{2}-\d{2}$/.test(pay.date)&&!isNaN(Date.parse(pay.date)),'Tanggal pembayaran wajib diisi.');
        if(pay.source==='Tabungan')requireThat(value<=totals(db).savings,'Saldo tabungan belum cukup.');
        record.payments=[{id:req.requestId,type:'payment',source:pay.source,amount:value,date:pay.date,note:'Pembayaran awal'}];
      }
      if(req.collection==='users')requireThat(!rows.some(u=>u.id!==req.id&&u.email===record.email),'Email ini sudah terdaftar.');
      if(req.collection==='savings'&&record.type==='Penarikan')requireThat(record.amount<=totals(db).savings,'Saldo tabungan belum cukup.');
    }
    if(req.collection==='tasks'&&req.action==='save')checkTask(record,rows);
    record.version=(old?.version||0)+1;record.updated_at=now;
    requireThat(JSON.stringify(record).length<40000,'Catatan melebihi kapasitas. Pisahkan item biaya.');
    if(index<0)rows.push(record);else rows[index]=record;
    return {record};
  }
  function csv(rows){const keys=[...new Set(rows.flatMap(x=>Object.keys(x).filter(k=>!['payments','files'].includes(k))))];const cell=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replace(/"/g,'""')+'"';return '\uFEFF'+[keys,...rows.map(r=>keys.map(k=>r[k]))].map(r=>r.map(cell).join(',')).join('\r\n');}
  function can(actor,key,write){if(actor?.owner)return true;if(key==='users')return false;return actor?.permissions?.[key]==='write'||(!write&&actor?.permissions?.[key]==='read');}
  function visible(db,actor){const copy=blank();for(const key of Object.keys(modules))copy[key]=can(actor,key,false)?db[key]:[];return copy;}
  return {modules,statuses,blank,money,amount,validate,netPaid,attendance,preparationCost,financeRows,financePaid,paidFinanceRows,totals,mutate,csv,can,visible};
})();
if(typeof module!=='undefined')module.exports=WeddingCore;

const C=WeddingCore;
const methods=new Set(['loadData','changeData','uploadAttachment','getAttachment','getUserHistory','changeUserHistory','recordLogin','saveOwnerProfile','createUserAccount','updateUserAccount','checkAccountService','exportBackup']);
function actorFor(data,email,owner){
  if(email===owner)return {email,owner:true,role:'Akun utama'};
  const member=data.users.find(x=>x.email===email&&x.status==='Aktif');
  if(!member)throw new Error('Akses akun belum diberikan atau sudah dicabut.');
  return {email,owner:false,role:member.role,permissions:JSON.parse(member.permissions||'{}')};
}
async function digest(text){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(b=>b.toString(16).padStart(2,'0')).join('');}
async function drive(env,email,method,args){
  const endpoint=String(env.GOOGLE_APPS_SCRIPT_URL||'').trim(),secret=String(env.GATEWAY_SECRET||'').trim();
  if(!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(endpoint))throw new Error('Alamat GOOGLE_APPS_SCRIPT_URL di Cloudflare belum valid.');
  if(secret.length<32)throw new Error('GATEWAY_SECRET di Cloudflare kosong atau terlalu pendek. Salin nilai rahasia dari Properti skrip Apps Script, minimal 32 karakter.');
  const payload=JSON.stringify({v:1,timestamp:Date.now(),nonce:crypto.randomUUID(),email,method,args});
  const encoder=new TextEncoder(),key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature=[...new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(payload)))].map(b=>b.toString(16).padStart(2,'0')).join('');
  const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({payload,signature}),redirect:'follow',signal:AbortSignal.timeout(55000)});
  if(!response.ok)throw new Error('Drive belum dapat dihubungi.');
  let result;try{result=await response.json();}catch{throw new Error('Penghubung Drive belum mengembalikan data. Periksa deployment Apps Script yang terpasang di Cloudflare.');}if(result.ok!==true)throw new Error(result.error||'Drive menolak permintaan.');return result.result;
}
export async function handle(request,env){
  const origin=request.headers.get('origin')||'',allowed=(env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim());
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
  if(origin&&allowed.includes(origin))Object.assign(headers,{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS'});
  const reply=(status,value)=>new Response(JSON.stringify(value),{status,headers});
  if(origin&&!allowed.includes(origin))return reply(403,{error:'Alamat aplikasi belum diizinkan.'});
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(request.method!=='POST')return reply(405,{error:'Metode tidak diizinkan.'});
  try{
    if(!env.DB||!env.OWNER_EMAIL||!env.SUPABASE_URL||!env.SUPABASE_PUBLISHABLE_KEY)return reply(503,{error:'Database Cloudflare belum dipasang.'});
    if(!request.headers.get('authorization')){
      const input=await request.json();if(input.method!=='loginAccount')return reply(401,{error:'Silakan masuk terlebih dahulu.'});
      const ip=await digest(request.headers.get('cf-connecting-ip')||'unknown'),minute=Math.floor(Date.now()/60000);
      const count=await env.DB.prepare('INSERT INTO wedding_limits VALUES(?,?,1) ON CONFLICT(user_id) DO UPDATE SET minute=excluded.minute,requests=CASE WHEN wedding_limits.minute=excluded.minute THEN wedding_limits.requests+1 ELSE 1 END WHERE wedding_limits.minute<>excluded.minute OR wedding_limits.requests<=10 RETURNING requests').bind('login:'+ip,minute).first();
      if(!count||count.requests>10)return reply(429,{error:'Terlalu banyak percobaan login. Tunggu satu menit.'});
      const r=input.payload||{},identifier=String(r.email||'').trim().toLowerCase();if(identifier.length>250||typeof r.password!=='string'||r.password.length>128)return reply(400,{error:'Data login tidak valid.'});
      const state=await env.DB.prepare('SELECT * FROM wedding_state WHERE id=1').first(),data=JSON.parse(state.data);
      const loginEmail=identifier.includes('@')?identifier:identifier===data._ownerProfile?.username?env.OWNER_EMAIL:data.users.find(x=>x.username===identifier)?.email||identifier+'@users.siapnikah.app';
      const response=await fetch(env.SUPABASE_URL+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:loginEmail,password:r.password}),signal:AbortSignal.timeout(20000)});
      if(!response.ok)return reply(401,{error:'Username atau password tidak sesuai.'});const session=await response.json();try{actorFor(data,session.user.email.toLowerCase(),env.OWNER_EMAIL.toLowerCase());}catch{return reply(403,{error:'Akses akun tidak aktif.'});}return reply(200,session);
    }
    const authorization=request.headers.get('authorization')||'';if(!/^Bearer \S+$/.test(authorization))return reply(401,{error:'Silakan masuk terlebih dahulu.'});
    const auth=await fetch(env.SUPABASE_URL+'/auth/v1/user',{headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,Authorization:authorization},signal:AbortSignal.timeout(10000)});
    if(!auth.ok)return reply(401,{error:'Sesi berakhir. Silakan masuk kembali.'});
    const user=await auth.json();if(!user.id||!user.email_confirmed_at||!user.email)return reply(401,{error:'Email akun belum dikonfirmasi.'});
    const email=user.email.toLowerCase(),minute=Math.floor(Date.now()/60000);
    const limit=await env.DB.prepare('INSERT INTO wedding_limits VALUES(?,?,1) ON CONFLICT(user_id) DO UPDATE SET minute=excluded.minute,requests=CASE WHEN wedding_limits.minute=excluded.minute THEN wedding_limits.requests+1 ELSE 1 END WHERE wedding_limits.minute<>excluded.minute OR wedding_limits.requests<=60 RETURNING requests').bind(user.id,minute).first();
    if(!limit||limit.requests>60)return reply(429,{error:'Terlalu banyak permintaan. Tunggu satu menit.'});
    const raw=await request.text();if(raw.length>7200000)return reply(413,{error:'Berkas maksimal 5 MB.'});
    let input;try{input=JSON.parse(raw);}catch{return reply(400,{error:'Permintaan tidak valid.'});}
    if(!methods.has(input.method))return reply(400,{error:'Metode tidak diizinkan.'});
    const state=await env.DB.prepare('SELECT * FROM wedding_state WHERE id=1').first();if(!state)throw new Error('Schema database belum dipasang.');
    const data=JSON.parse(state.data),actor=actorFor(data,email,env.OWNER_EMAIL.toLowerCase());
    if(input.method==='exportBackup'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mencadangkan seluruh data.'});
      return reply(200,{schema:'siap-nikah-backup-v1',exportedAt:new Date().toISOString(),version:state.version,data});
    }
    if(input.method==='checkAccountService'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat menguji layanan akun.'});
      if(!env.SUPABASE_SECRET_KEY)return reply(503,{error:'Secret Supabase belum dipasang.'});
      const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users?page=1&per_page=1',{headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY},signal:AbortSignal.timeout(10000)});
      if(!response.ok)return reply(502,{error:'Secret Supabase belum dapat mengakses layanan akun. Status '+response.status+'.'});
      const result=await response.json();if(!Array.isArray(result.users))return reply(502,{error:'Respons layanan akun belum valid.'});
      return reply(200,{ok:true,message:'Layanan akun terhubung. Secret Supabase valid.'});
    }
    if(input.method==='createUserAccount'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat membuat akun.'});
      if(!env.SUPABASE_SECRET_KEY)return reply(503,{error:'Pembuatan akun belum aktif. Pasang SUPABASE_SECRET_KEY di Cloudflare.'});
      const r=input.payload||{},name=String(r.name||'').trim(),username=String(r.username||'').trim().toLowerCase();
      if(!name||name.length>100||!/^[a-z0-9._-]{3,30}$/.test(username))throw new Error('Isi nama dan username 3–30 karakter (huruf, angka, titik, _ atau -).');
      if(typeof r.password!=='string'||r.password.length<8||r.password.length>128)throw new Error('Password harus 8–128 karakter.');
      if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),previous=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();
      if(previous){if(previous.actor!==email||previous.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
      const memberEmail=username+'@users.siapnikah.app';if(data.users.some(x=>x.username===username||x.email===memberEmail))throw new Error('Username sudah digunakan.');
      const id=crypto.randomUUID(),stamp=new Date().toISOString();
      C.mutate(data,{collection:'users',id,version:0,action:'save',data:{name,username,email:memberEmail,role:r.role||'Panitia',status:'Aktif',permissions:r.permissions||'{}',notes:''}},stamp);
      data._userHistory=(data._userHistory||[]).concat({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Membuat akun · '+username,timestamp:stamp,notes:'',version:1}).slice(-500);
      const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users',{method:'POST',headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:memberEmail,password:r.password,email_confirm:true,user_metadata:{name,username}}),signal:AbortSignal.timeout(20000)});
      if(!response.ok)throw new Error(response.status===422?'Username sudah terdaftar di layanan login.':'Layanan login belum dapat membuat akun. Periksa secret Supabase.');
      const created=await response.json();if(!created.id)throw new Error('Pembuatan akun login belum terkonfirmasi.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,stamp,state.version).first();
      if(!saved)return reply(409,{error:'Akun login sudah dibuat, tetapi akses belum tersimpan karena data berubah. Tambahkan akses untuk '+memberEmail+' melalui pengaturan pengguna.'});
      return reply(200,{data:C.visible(data,actor)});
    }
    if(input.method==='updateUserAccount'){
      if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mengedit akun.'});
      const r=input.payload||{},name=String(r.name||'').trim(),username=String(r.username||'').trim().toLowerCase(),owner=r.id==='owner';
      if(!name||name.length>100||!/^[a-z0-9._-]{3,30}$/.test(username))throw new Error('Nama wajib diisi. Username 3–30 karakter.');
      if(r.password&&(typeof r.password!=='string'||r.password.length<8||r.password.length>128))throw new Error('Password baru harus 8–128 karakter.');
      if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),prior=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();if(prior){if(prior.actor!==email||prior.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
      const member=owner?null:data.users.find(x=>x.id===r.id);if(!owner&&(!member||member.version!==r.version))throw new Error('Akun berubah. Muat ulang.');
      if(data.users.some(x=>x.id!==r.id&&x.username===username)||(!owner&&data._ownerProfile?.username===username))throw new Error('Username sudah digunakan.');
      const stamp=new Date().toISOString();if(owner)data._ownerProfile={...data._ownerProfile,name,username};else C.mutate(data,{collection:'users',id:r.id,version:r.version,action:'save',data:{...member,name,username,role:r.role,status:r.status,permissions:r.permissions}},stamp);
      if(r.password){
        if(!env.SUPABASE_SECRET_KEY)return reply(503,{error:'Secret Supabase belum dipasang.'});let authId=owner?user.id:null;
        for(let page=1;page<=20&&!authId;page++){const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users?page='+page+'&per_page=100',{headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY},signal:AbortSignal.timeout(10000)});if(!response.ok)throw new Error('Layanan login belum dapat dihubungi.');const list=await response.json();authId=list.users?.find(x=>x.email===member.email)?.id;if((list.users||[]).length<100)break;}
        if(!authId)throw new Error('Akun login tidak ditemukan.');const response=await fetch(env.SUPABASE_URL+'/auth/v1/admin/users/'+authId,{method:'PUT',headers:{apikey:env.SUPABASE_SECRET_KEY,Authorization:'Bearer '+env.SUPABASE_SECRET_KEY,'Content-Type':'application/json'},body:JSON.stringify({password:r.password,user_metadata:{name,username}}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('Password belum berhasil diubah.');
      }
      data._userHistory=(data._userHistory||[]).concat({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Mengedit akun dan akses · '+username,timestamp:stamp,notes:'',version:1}).slice(-500);const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,stamp,state.version).first();if(!saved)return reply(409,{error:'Data akun berubah. Muat ulang. Jika password diisi, password tersebut sudah diperbarui.'});return reply(200,{data:C.visible(data,actor)});
    }
    if(input.method==='getUserHistory'){if(!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat melihat riwayat pengguna.'});return reply(200,{history:(data._userHistory||[]).filter(x=>!x.deleted),ownerProfile:data._ownerProfile||{name:'Akun utama'}});}
    if(['changeUserHistory','recordLogin','saveOwnerProfile'].includes(input.method)){
      if(input.method!=='recordLogin'&&!actor.owner)return reply(403,{error:'Hanya akun utama yang dapat mengelola pengguna dan riwayat.'});
      const r=input.payload||{};if(!/^[\w-]{16,80}$/.test(r.requestId||''))throw new Error('Identitas permintaan tidak valid.');
      const fp=await digest(raw),previous=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(r.requestId).first();if(previous){if(previous.actor!==email||previous.fingerprint!==fp)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{ok:true,duplicate:true});}
      const at=new Date().toISOString();data._userHistory=data._userHistory||[];
      if(input.method==='recordLogin')data._userHistory.push({id:crypto.randomUUID(),email,type:'Login',action:'Masuk ke aplikasi',timestamp:at,notes:'',version:1});
      if(input.method==='saveOwnerProfile'){const name=String(r.name||'').trim();if(!name||name.length>100)throw new Error('Nama wajib diisi, maksimal 100 karakter.');data._ownerProfile={...data._ownerProfile,name};data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:'Mengubah nama akun utama',timestamp:at,notes:'',version:1});}
      if(input.method==='changeUserHistory'){const item=data._userHistory.find(x=>x.id===r.id&&!x.deleted);if(!item||item.version!==r.version)throw new Error('Riwayat berubah. Muat ulang.');if(!['edit','delete'].includes(r.action))throw new Error('Tindakan tidak valid.');if(r.action==='delete')item.deleted=true;else{const notes=String(r.notes||'').trim();if(notes.length>1000)throw new Error('Catatan maksimal 1.000 karakter.');item.notes=notes;}item.version++;item.edited_at=at;data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:r.action==='delete'?'Menghapus riwayat dari tampilan':'Mengedit catatan riwayat',timestamp:at,notes:'',version:1});}
      data._userHistory=data._userHistory.slice(-500);const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai.');
      const saved=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,r.requestId,email,fp,at,state.version).first();if(!saved)return reply(409,{error:'Data berubah. Muat ulang sebelum mencoba lagi.'});return reply(200,{ok:true});
    }
    if(input.method==='loadData')return reply(200,{data:C.visible(data,actor),actor,email,mode:'cloudflare',serverTime:new Date().toISOString()});
    const req=input.payload;if(!req||!Object.hasOwn(C.modules,req.collection)||!C.can(actor,req.collection,input.method!=='getAttachment'))return reply(403,{error:'Anda tidak memiliki izin untuk modul ini.'});
    const record=data[req.collection].find(x=>x.id===req.id);
    if(input.method==='getAttachment'){
      const file=record?.files?.find(x=>x.id===req.fileId);if(!file)throw new Error('Lampiran tidak tersedia.');
      return reply(200,await drive(env,email,'cloudGetFile',{fileId:file.id,name:file.name}));
    }
    if(!/^[\w-]{16,80}$/.test(req.requestId||''))throw new Error('Identitas permintaan tidak valid.');
    const fingerprint=await digest(raw),prior=await env.DB.prepare('SELECT actor,fingerprint FROM wedding_audit WHERE request_id=?').bind(req.requestId).first();
    if(prior){if(prior.actor!==email||prior.fingerprint!==fingerprint)throw new Error('Identitas permintaan sudah digunakan.');return reply(200,{data:C.visible(data,actor),duplicate:true});}
    if(req.collection==='users'&&String(req.data?.email||'').toLowerCase()===env.OWNER_EMAIL.toLowerCase())throw new Error('Akun utama tidak dapat diganti.');
    const stamp=new Date().toISOString();
    if(input.method==='changeData')C.mutate(data,req,stamp);
    else{
      if(!record||record.version!==req.version)throw new Error('Catatan berubah. Muat ulang sebelum unggah.');
      if(req.replaceFileId&&!record.files?.some(x=>x.id===req.replaceFileId))throw new Error('Lampiran pengganti tidak tersedia.');
      if((record.files||[]).length>=10&&!req.replaceFileId)throw new Error('Maksimal 10 lampiran.');
      if(req.collection==='budget'&&!['application/pdf','image/jpeg','image/png'].includes(req.mime))throw new Error('Invoice harus PDF, JPG atau PNG.');
      const file=await drive(env,email,'cloudUploadFile',req);
      record.files=[...(record.files||[]).filter(x=>x.id!==req.replaceFileId),file];if(req.collection==='admin')record.available=true;record.version++;record.updated_at=stamp;
    }
    data._userHistory=data._userHistory||[];data._userHistory.push({id:crypto.randomUUID(),email,type:'Aktivitas',action:(input.method==='uploadAttachment'?'Mengunggah lampiran':req.action==='delete'?'Menghapus catatan':'Mengubah catatan')+' · '+C.modules[req.collection].title,timestamp:stamp,notes:'',version:1});data._userHistory=data._userHistory.slice(-500);
    const serialized=JSON.stringify(data);if(new TextEncoder().encode(serialized).length>1500000)throw new Error('Kapasitas ruang pernikahan tercapai. Ekspor dan arsipkan data lama.');
    const result=await env.DB.prepare('UPDATE wedding_state SET data=?,version=version+1,request_id=?,actor=?,fingerprint=?,updated_at=? WHERE id=1 AND version=? RETURNING version').bind(serialized,req.requestId,email,fingerprint,stamp,state.version).first();
    if(!result)return reply(409,{error:'Data berubah saat disimpan. Muat ulang; periksa hasil sebelum mengulangi.'});
    return reply(200,{data:C.visible(data,actor)});
  }catch(error){return reply(400,{error:error.message||'Penyimpanan belum terkonfirmasi.'});}
}
export default {fetch:handle};
