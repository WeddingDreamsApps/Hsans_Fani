/* Shared business rules for the Apps Script runtime, browser preview and tests. */
var WeddingCore = (function () {
  'use strict';
  const modules = {
    profile: {title:'Data Mempelai',sheet:'SN_Mempelai',fields:['name','partner','date','location','budget','target','invitationUrl','notes']},
    budget: {title:'Budget & Pengeluaran',sheet:'SN_Anggaran',fields:['name','category','amount','date','owner','notes']},
    savings: {title:'Tabungan',sheet:'SN_Tabungan',fields:['name','type','amount','date','owner','notes']},
    gifts: {title:'Seserahan & Mahar',sheet:'SN_Seserahan',fields:['name','type','itemGroup','quantity','amount','paymentStatus','status','shopUrl','owner','notes']},
    vendors: {title:'Vendor & Venue',sheet:'SN_Vendor',fields:['name','category','contact','location','amount','capacity','status','notes']},
    admin: {title:'Administrasi KUA',sheet:'SN_Administrasi',fields:['name','requirementType','available','owner','date','status','source','notes']},
    guests: {title:'Daftar Undangan',sheet:'SN_Undangan',fields:['name','group','contact','event','quota','attending','status','deliveryStatus','address','attendanceLedger','notes']},
    tasks: {title:'Timeline Checklist',sheet:'SN_Checklist',fields:['name','owner','date','priority','status','notes']},
    rundown: {title:'Rundown & Panitia',sheet:'SN_Rundown',fields:['name','event','start','end','owner','location','contact','status','notes']},
    users: {title:'Manajemen Pengguna',sheet:'SN_Pengguna',fields:['name','email','role','status','permissions','notes']}
  };
  const statuses = {
    gifts:['Direncanakan','Disiapkan','Dikemas','Diserahkan'],
    vendors:['Kandidat','Dihubungi','Negosiasi','Dipilih','Selesai','Dibatalkan'],
    admin:['Belum disiapkan','Disiapkan','Perlu perbaikan','Diajukan','Selesai','Tidak berlaku'],
    guests:['Belum dikirim','Dikirim','Hadir','Tidak hadir','Belum pasti'],
    tasks:['Belum mulai','Berlangsung','Terhambat','Selesai','Tidak berlaku'],
    rundown:['Draf','Final'],
    users:['Aktif','Nonaktif']
  };
  function blank(){return Object.fromEntries(Object.keys(modules).map(k=>[k,[]]));}
  function money(n){return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0);}
  function requireThat(ok,msg){if(!ok)throw new Error(msg);}
  function amount(v,label){const n=Number(v||0);requireThat(Number.isSafeInteger(n)&&n>=0&&n<=1000000000000,(label||'Nominal')+' harus berupa bilangan bulat 0–1 triliun.');return n;}
  function validate(key,input){
    requireThat(Object.hasOwn(modules,key),'Modul tidak dikenal.');
    const out={};
    for(const field of modules[key].fields){
      const value=input[field];
      if(field==='available')out[field]=value===true||value==='true'||value==='on';
      else if(['amount','budget','target','quota','attending','capacity','quantity'].includes(field))out[field]=amount(value,field);
      else {requireThat(value==null||typeof value==='string','Format kolom tidak valid.');out[field]=String(value||'').trim();requireThat(out[field].length<=(field==='attendanceLedger'?30000:field==='notes'?3000:field==='permissions'?3000:field.endsWith('Url')?1000:250),'Teks terlalu panjang.');}
    }
    requireThat(out.name.length>0,'Nama atau judul wajib diisi.');
    if(out.date)requireThat(/^\d{4}-\d{2}-\d{2}$/.test(out.date)&&!isNaN(Date.parse(out.date)),'Tanggal tidak valid.');
    if(statuses[key])requireThat(statuses[key].includes(out.status),'Status tidak valid.');
    if(key==='savings')requireThat(['Setoran','Penarikan'].includes(out.type),'Jenis transaksi tidak valid.');
    if(key==='gifts'){
      requireThat(['Seserahan','Mahar'].includes(out.type)&&out.quantity>0,'Jenis dan jumlah barang wajib diisi.');
      out.paymentStatus=out.paymentStatus||'Belum dibayar';
      requireThat(['Belum dibayar','Proses pembayaran','DP / sebagian','Lunas','Hadiah / tanpa biaya'].includes(out.paymentStatus),'Status pembayaran tidak valid.');
      out.itemGroup=out.itemGroup||'Lainnya';
    }
    if(key==='admin'){out.requirementType=out.requirementType||'Umum';requireThat(['Umum','Bersyarat','Tahapan'].includes(out.requirementType),'Jenis persyaratan tidak valid.');}
    if(key==='guests'){out.deliveryStatus=out.deliveryStatus||'Belum dikirim';requireThat(['Belum dikirim','Dikirim','Dibuka'].includes(out.deliveryStatus),'Status pengiriman tidak valid.');}
    if(key==='users'){
      out.email=out.email.toLowerCase();requireThat(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.email),'Email pengguna tidak valid.');
      requireThat(['Pasangan','Koordinator','Panitia','Pembaca'].includes(out.role),'Peran tidak valid.');
      let perms;try{perms=JSON.parse(out.permissions||'{}');}catch(e){throw new Error('Pengaturan akses tidak valid.');}
      requireThat(perms&&typeof perms==='object'&&!Array.isArray(perms),'Pengaturan akses tidak valid.');
      Object.entries(perms).forEach(([k,v])=>requireThat(Object.hasOwn(modules,k)&&k!=='users'&&['none','read','write'].includes(v),'Izin modul tidak valid.'));
      out.permissions=JSON.stringify(perms);
    }
    if(key==='tasks')requireThat(['Normal','Tinggi'].includes(out.priority),'Prioritas tidak valid.');
    if(key==='guests'){
      requireThat(out.quota>0&&out.quota<=100,'Kuota undangan harus 1–100 orang.');
      requireThat(out.attending<=out.quota,'Jumlah hadir melebihi kuota.');
      requireThat(out.status==='Hadir'||out.attending===0,'Isi jumlah hadir hanya untuk status Hadir.');
      requireThat(out.event.length>0,'Nama acara wajib diisi.');
      let ledger;try{ledger=JSON.parse(out.attendanceLedger||'[]');}catch(e){throw new Error('Catatan kehadiran tidak valid.');}
      requireThat(Array.isArray(ledger)&&ledger.length<=out.quota,'Jumlah tamu yang tercatat hadir melebihi kuota.');
      const ids=new Set();
      ledger=ledger.map(person=>{
        requireThat(person&&typeof person==='object','Catatan tamu tidak valid.');
        const id=String(person.id||''),name=String(person.name||'').trim(),kind=String(person.kind||''),goods=String(person.goods||'').trim(),cash=amount(person.cash,'Uang tamu');
        requireThat(/^[\w-]{5,80}$/.test(id)&&!ids.has(id),'ID tamu hadir tidak valid atau duplikat.');ids.add(id);
        requireThat(name.length>0&&name.length<=250,'Nama setiap tamu yang hadir wajib diisi.');
        requireThat(['Uang','Barang','Uang & barang','Tidak memberi'].includes(kind),'Jenis pemberian setiap tamu wajib dipilih.');
        requireThat(goods.length<=3000,'Catatan barang terlalu panjang.');
        requireThat((kind==='Uang'||kind==='Uang & barang')?cash>0:cash===0,'Nominal uang harus sesuai jenis pemberian.');
        requireThat((kind==='Barang'||kind==='Uang & barang')?goods.length>0:goods.length===0,'Rincian barang harus sesuai jenis pemberian.');
        return {id,name,kind,cash,goods};
      });
      out.attendanceLedger=JSON.stringify(ledger);
    }
    if(key==='rundown')requireThat(out.start&&out.end&&Number.isFinite(Date.parse(out.start))&&Number.isFinite(Date.parse(out.end))&&out.end>out.start,'Waktu selesai harus setelah waktu mulai.');
    for(const f of ['source','shopUrl','invitationUrl'])if(out[f])requireThat(/^https:\/\/[^\s]+$/.test(out[f]),'Tautan harus berupa HTTPS yang valid.');
    return out;
  }
  function netPaid(item){return(item.payments||[]).reduce((s,p)=>s+(p.type==='refund'?-p.amount:p.amount),0);}
  function attendance(guest){try{const rows=JSON.parse(guest.attendanceLedger||'[]');return Array.isArray(rows)?rows:[];}catch(e){return [];}}
  function totals(db){
    const p=db.profile[0]||{};const costs=db.budget||[];
    const spent=costs.reduce((s,x)=>s+netPaid(x),0);
    const fromSavings=costs.reduce((s,x)=>s+(x.payments||[]).reduce((a,p)=>a+(p.source==='Tabungan'?(p.type==='refund'?-p.amount:p.amount):0),0),0);
    const deposits=db.savings.reduce((s,x)=>s+(x.type==='Setoran'?x.amount:-x.amount),0);
    const tasks=db.tasks.filter(x=>x.status!=='Tidak berlaku');
    const visitors=(db.guests||[]).flatMap(attendance);
    const guestCash=visitors.reduce((s,x)=>s+Number(x.cash||0),0),guestGoods=visitors.filter(x=>x.goods).length;
    return {checkedIn:visitors.length,guestCash,guestGoods,netEventCash:guestCash-spent,budget:p.budget||0,committed:costs.reduce((s,x)=>s+x.amount,0),paid:spent,due:costs.reduce((s,x)=>s+Math.max(0,x.amount-netPaid(x)),0),credit:costs.reduce((s,x)=>s+Math.max(0,netPaid(x)-x.amount),0),savings:deposits-fromSavings,target:p.target||0,invites:db.guests.length,quota:db.guests.reduce((s,x)=>s+x.quota,0),attending:db.guests.reduce((s,x)=>s+x.attending,0),tasks:tasks.length,done:tasks.filter(x=>x.status==='Selesai').length};
  }
  function mutate(db,req,now){
    requireThat(req&&typeof req==='object','Permintaan tidak valid.');
    requireThat(Object.hasOwn(modules,req.collection),'Modul tidak dikenal.');
    requireThat(typeof req.id==='string'&&/^[\w-]{5,80}$/.test(req.id),'ID tidak valid.');
    const rows=db[req.collection];const index=rows.findIndex(x=>x.id===req.id);const old=rows[index];
    requireThat((old?old.version:0)===req.version,'Data telah berubah. Muat ulang sebelum menyimpan kembali.');
    let record;
    if(req.action==='delete'){
      requireThat(old,'Catatan tidak ditemukan.');
      requireThat(req.collection!=='profile','Profil tidak dapat dihapus.');
      requireThat(!['budget','savings'].includes(req.collection),'Catatan keuangan tidak dapat dihapus.');
      rows.splice(index,1);return {deleted:true,old};
    }
    if(['fileEdit','fileUnlink'].includes(req.action)){
      requireThat(old,'Catatan tidak ditemukan.');
      const files=[...(old.files||[])];const pos=files.findIndex(f=>f.id===req.fileId);
      requireThat(pos>=0,'Lampiran tidak ditemukan.');
      if(req.action==='fileUnlink')files.splice(pos,1);
      else {const name=String(req.fileName||'').trim();requireThat(name.length>0&&name.length<=120,'Nama lampiran harus 1–120 karakter.');files[pos]={...files[pos],name};}
      record={...old,files};
    }else if(req.action==='payment'){
      requireThat(req.collection==='budget'&&old,'Item biaya tidak ditemukan.');
      const p=req.payment||{};const value=amount(p.amount);
      requireThat(value>0,'Nominal pembayaran harus lebih dari nol.');
      requireThat(['payment','refund'].includes(p.type)&&['Tabungan','Dana lain'].includes(p.source),'Jenis/sumber pembayaran tidak valid.');
      requireThat(/^\d{4}-\d{2}-\d{2}$/.test(p.date)&&!isNaN(Date.parse(p.date)),'Tanggal pembayaran wajib diisi.');
      if(p.type==='refund'){
        const available=(old.payments||[]).filter(x=>x.source===p.source).reduce((s,x)=>s+(x.type==='refund'?-x.amount:x.amount),0);
        requireThat(value<=available,'Refund melebihi pembayaran dari sumber dana ini.');
      }
      if(p.type==='payment'&&p.source==='Tabungan')requireThat(value<=totals(db).savings,'Saldo tabungan belum cukup.');
      if(p.type==='payment'&&netPaid(old)+value>old.amount)requireThat(p.allowOverpay===true,'Pembayaran melebihi komitmen. Konfirmasikan kelebihan bayar.');
      record={...old,payments:[...(old.payments||[]),{id:req.requestId,type:p.type,source:p.source,amount:value,date:p.date,note:String(p.note||'').slice(0,500)}]};
    }else{
      requireThat(req.action==='save','Tindakan tidak dikenal.');
      requireThat(!(req.collection==='savings'&&old),'Transaksi tabungan tidak diubah; tambahkan transaksi koreksi.');
      requireThat(req.collection!=='profile'||rows.length===0||!!old,'Hanya satu profil pasangan per spreadsheet.');
      record={...old,...validate(req.collection,req.collection==='guests'?{...old,...req.data}:req.data||{}),id:req.id};
      if(req.collection==='budget'&&req.initialPayment){
        requireThat(!old,'Pembayaran awal hanya untuk item biaya baru.');
        const pay=req.initialPayment,value=amount(pay.amount,'Pembayaran awal');
        requireThat(value>0&&value<=record.amount,'Pembayaran awal harus positif dan tidak melebihi biaya.');
        requireThat(['Tabungan','Dana lain'].includes(pay.source),'Sumber dana tidak valid.');
        requireThat(/^\d{4}-\d{2}-\d{2}$/.test(pay.date)&&!isNaN(Date.parse(pay.date)),'Tanggal pembayaran wajib diisi.');
        if(pay.source==='Tabungan')requireThat(value<=totals(db).savings,'Saldo tabungan belum cukup.');
        record.payments=[{id:req.requestId,type:'payment',source:pay.source,amount:value,date:pay.date,note:'Pembayaran awal'}];
      }
      if(req.collection==='users')requireThat(!rows.some(u=>u.id!==req.id&&u.email===record.email),'Email ini sudah terdaftar.');
      if(req.collection==='savings'&&record.type==='Penarikan')requireThat(record.amount<=totals(db).savings,'Saldo tabungan belum cukup.');
    }
    record.version=(old?.version||0)+1;record.updated_at=now;
    requireThat(JSON.stringify(record).length<40000,'Catatan melebihi kapasitas. Pisahkan item biaya.');
    if(index<0)rows.push(record);else rows[index]=record;
    return {record};
  }
  function csv(rows){const keys=[...new Set(rows.flatMap(x=>Object.keys(x).filter(k=>!['payments','files'].includes(k))))];const cell=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replace(/"/g,'""')+'"';return '\uFEFF'+[keys,...rows.map(r=>keys.map(k=>r[k]))].map(r=>r.map(cell).join(',')).join('\r\n');}
  function can(actor,key,write){if(actor?.owner)return true;if(key==='users')return false;return actor?.permissions?.[key]==='write'||(!write&&actor?.permissions?.[key]==='read');}
  function visible(db,actor){const copy=blank();for(const key of Object.keys(modules))copy[key]=can(actor,key,false)?db[key]:[];return copy;}
  return {modules,statuses,blank,money,amount,validate,netPaid,attendance,totals,mutate,csv,can,visible};
})();
if(typeof module!=='undefined')module.exports=WeddingCore;


/* Deploy only one Apps Script project for this workbook. */
const SPREADSHEET_ID = '1hG9wUKF28ErTIlxfKQPqznzEbBy4_z6mojQ9U13I_Rc';
const DRIVE_FOLDER_ID = '11l-_WvlejNKYFxjwjzoOq0NsjcSgdKQ0';
const HEADER = ['id','version','nama','status','nominal','tanggal','penanggung_jawab','data_json','updated_at'];

// Run manually once from the script editor while signed in as the workbook owner.
function initializeDatabase() {
  const bootstrapEmail=authorize_(true);
  if(bootstrapEmail!==ownerEmail_())throw new Error('Hanya akun utama yang boleh menyiapkan database.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try {
    const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
    const specs=Object.values(WeddingCore.modules).map(m=>[m.sheet,HEADER]);
    specs.push(['SN_Audit',['request_id','timestamp','actor','action','collection','record_id','fingerprint']]);
    specs.forEach(([name,headers])=>{
      let sheet=ss.getSheetByName(name);
      if(sheet&&sheet.getLastRow()>0){
        if(JSON.stringify(sheet.getRange(1,1,1,headers.length).getValues()[0])!==JSON.stringify(headers))throw new Error('Header berbeda pada '+name+'. Data tidak ditimpa.');
        return;
      }
      if(!sheet)sheet=ss.insertSheet(name);
      sheet.getRange(1,1,1,headers.length).setValues([headers]).setFontWeight('bold').setBackground('#eeeeee');sheet.setFrozenRows(1);sheet.setColumnWidths(1,headers.length,160);
      if(headers.length===9)sheet.setColumnWidth(8,320);
    });
    return 'Database siap. Tab lama tetap dipertahankan.';
  } finally {lock.releaseLock();}
}

function authorize_(allowDirectOwner) {
  const props=PropertiesService.getScriptProperties();
  const verified=typeof GATEWAY_EMAIL_!=='undefined'&&GATEWAY_EMAIL_;
  const email=String(verified||Session.getActiveUser().getEmail()).toLowerCase();
  if(props.getProperty('GATEWAY_ONLY')==='true'&&!verified&&!(allowDirectOwner===true&&email===ownerEmail_()))throw new Error('Masuk melalui aplikasi Supabase.');
  const allowed = (PropertiesService.getScriptProperties().getProperty('ALLOWED_EMAILS') || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
  if(!email)throw new Error('Identitas Google tidak tersedia. Masuk dengan akun yang diizinkan.');
  if(email===ownerEmail_())return email;
  const sheet=SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName('SN_Pengguna');
  let registered=false;
  if(sheet&&sheet.getLastRow()>1)registered=sheet.getRange(2,8,sheet.getLastRow()-1,1).getValues().some(row=>{try{const user=JSON.parse(row[0]);return user.email===email&&user.status==='Aktif';}catch(e){return false;}});
  if(!registered)throw new Error('Akses belum diizinkan. Akun utama perlu menambahkan pengguna aktif.');
  return email;
}
function ownerEmail_(){const props=PropertiesService.getScriptProperties();return String(props.getProperty('OWNER_EMAIL')||(props.getProperty('ALLOWED_EMAILS')||'').split(',')[0]||'').trim().toLowerCase();}
function actor_(ctx,email){
  if(email===ownerEmail_())return {email,owner:true,role:'Akun utama'};
  const u=ctx.db.users.find(x=>x.email===email&&x.status==='Aktif');
  if(!u)throw new Error('Akses akun sudah dicabut.');
  return {email,owner:false,role:u.role,permissions:JSON.parse(u.permissions||'{}')};
}
function access_(ctx,email,key,write){const actor=actor_(ctx,email);if(!WeddingCore.can(actor,key,write))throw new Error('Anda tidak memiliki izin untuk modul ini.');return actor;}
function doGet() {
  if(PropertiesService.getScriptProperties().getProperty('GATEWAY_ONLY')==='true')return ContentService.createTextOutput('Penghubung Google aktif. Buka aplikasi GitHub dan masuk dengan akun yang diizinkan.');
  authorize_();
  return HtmlService.createHtmlOutputFromFile('Index').setTitle('Siap Nikah').addMetaTag('viewport','width=device-width, initial-scale=1');
}
function read_() {
  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);const db=WeddingCore.blank();const sheets={};
  Object.keys(WeddingCore.modules).forEach(key=>{
    const sheet=ss.getSheetByName(WeddingCore.modules[key].sheet);
    if(!sheet)throw new Error('Tabel belum tersedia: '+WeddingCore.modules[key].sheet);
    const header=sheet.getRange(1,1,1,9).getValues()[0];
    if(JSON.stringify(header)!==JSON.stringify(HEADER))throw new Error('Struktur tabel berubah. Jangan mengubah header database.');
    sheets[key]={id:sheet.getSheetId(),rows:{},next:sheet.getLastRow()};
    if(sheet.getLastRow()>1)sheet.getRange(2,1,sheet.getLastRow()-1,9).getValues().forEach((row,i)=>{
      if(row[0]){const record=JSON.parse(row[7]);if(record.id!==row[0])throw new Error('Data tidak konsisten.');db[key].push(record);sheets[key].rows[record.id]=i+1;}
    });
  });
  return {ss,db,sheets};
}
function loadData() {
  const email=authorize_();const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{const ctx=read_(),actor=actor_(ctx,email);return {data:WeddingCore.visible(ctx.db,actor),actor,email,mode:'live',serverTime:new Date().toISOString()};}finally{lock.releaseLock();}
}
function auditFind_(ss,id) {
  const sheet=ss.getSheetByName('SN_Audit');if(!sheet)throw new Error('Tabel audit belum tersedia.');
  if(sheet.getLastRow()<2)return null;
  const found=sheet.getRange(2,1,sheet.getLastRow()-1,1).createTextFinder(id).matchEntireCell(true).findNext();
  return found?sheet.getRange(found.getRow(),1,1,7).getValues()[0]:null;
}
function fingerprint_(request){return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,JSON.stringify(request)));}
function cell_(v){return {userEnteredValue:typeof v==='number'?{numberValue:v}:{stringValue:String(v??'')}};}
function save_(ctx,request,record,email,stamp) {
  const table=ctx.sheets[request.collection];const row=table.rows[request.id]??table.next;
  const sheet=ctx.ss.getSheetByName(WeddingCore.modules[request.collection].sheet);
  const audit=ctx.ss.getSheetByName('SN_Audit');const requests=[];
  if(row>=sheet.getMaxRows())requests.push({appendDimension:{sheetId:table.id,dimension:'ROWS',length:100}});
  const values=record?[record.id,record.version,record.name,record.status||'',record.amount||0,record.date||record.start||'',record.owner||'',JSON.stringify(record),record.updated_at]:Array(9).fill('');
  requests.push({updateCells:{start:{sheetId:table.id,rowIndex:row,columnIndex:0},rows:[{values:values.map(cell_)}],fields:'userEnteredValue'}});
  requests.push({appendCells:{sheetId:audit.getSheetId(),rows:[{values:[request.requestId,stamp,email,request.action,request.collection,request.id,fingerprint_(request)].map(cell_)}],fields:'userEnteredValue'}});
  Sheets.Spreadsheets.batchUpdate({requests},SPREADSHEET_ID);
}
function changeData(request) {
  const email=authorize_();
  if(!request||typeof request.requestId!=='string'||!/^[\w-]{16,80}$/.test(request.requestId))throw new Error('Identitas permintaan tidak valid.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const ctx=read_();const actor=access_(ctx,email,request.collection,true);const prior=auditFind_(ctx.ss,request.requestId);
    if(request.collection==='users'&&String(request.data?.email||'').toLowerCase()===ownerEmail_())throw new Error('Akun utama diatur melalui konfigurasi pemilik dan tidak dapat diganti di sini.');
    if(prior){if(prior[2]!==email||prior[6]!==fingerprint_(request))throw new Error('Permintaan sebelumnya sudah tersimpan. Muat ulang sebelum mengirim perubahan baru.');return {data:WeddingCore.visible(ctx.db,actor),duplicate:true};}
    const stamp=new Date().toISOString();const result=WeddingCore.mutate(ctx.db,request,stamp);
    save_(ctx,request,result.record||null,email,stamp);
    return {data:WeddingCore.visible(ctx.db,actor)};
  }finally{lock.releaseLock();}
}
function uploadAttachment(request) {
  const email=authorize_();
  if(!request||!Object.hasOwn(WeddingCore.modules,request.collection)||typeof request.requestId!=='string'||!/^[\w-]{16,80}$/.test(request.requestId))throw new Error('Permintaan unggah tidak valid.');
  if(typeof request.base64!=='string'||request.base64.length>7000000)throw new Error('Berkas maksimal 5 MB.');
  request.action='upload';
  const bytes=Utilities.base64Decode(request.base64);if(bytes.length>5*1024*1024||bytes.length<4)throw new Error('Ukuran berkas tidak valid.');
  const b=bytes.map(x=>(x+256)%256);const type=request.mime;
  const valid=(type==='application/pdf'&&b[0]===37&&b[1]===80&&b[2]===68&&b[3]===70)||(type==='image/jpeg'&&b[0]===255&&b[1]===216&&b[2]===255)||(type==='image/png'&&b.slice(0,8).join(',')==='137,80,78,71,13,10,26,10')||(type==='application/vnd.openxmlformats-officedocument.wordprocessingml.document'&&/\.docx$/i.test(request.name)&&b[0]===80&&b[1]===75&&b[2]===3&&b[3]===4)||(type==='application/msword'&&/\.doc$/i.test(request.name)&&b.slice(0,8).join(',')==='208,207,17,224,161,177,26,225');
  if(!valid)throw new Error('Gunakan PDF, JPG, PNG, DOC, atau DOCX yang valid.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const ctx=read_();const actor=access_(ctx,email,request.collection,true);const prior=auditFind_(ctx.ss,request.requestId);
    if(prior){if(prior[2]!==email||prior[6]!==fingerprint_(request))throw new Error('Identitas unggah telah digunakan.');return {data:WeddingCore.visible(ctx.db,actor)};}
    const record=ctx.db[request.collection].find(x=>x.id===request.id);
    if(!record||record.version!==request.version)throw new Error('Catatan berubah. Muat ulang sebelum unggah.');
    if(request.replaceFileId&&!record.files?.some(f=>f.id===request.replaceFileId))throw new Error('Lampiran yang akan diganti tidak ditemukan.');
    if((record.files||[]).length>=10&&!request.replaceFileId)throw new Error('Maksimal 10 lampiran per catatan.');
    const folder=DriveApp.getFolderById(DRIVE_FOLDER_ID);
    if(folder.getSharingAccess()!==DriveApp.Access.PRIVATE)throw new Error('Folder dibagikan melalui tautan/domain. Ubah General access menjadi Restricted sebelum unggah dokumen.');
    const name=String(request.name||'lampiran').replace(/[\\/\x00-\x1f]/g,'_').slice(0,120);
    // A stable request prefix permits recovery after an uncertain upload response.
    const storedName=request.requestId+'_'+name;const existing=folder.getFilesByName(storedName);
    const file=existing.hasNext()?existing.next():folder.createFile(Utilities.newBlob(bytes,type,storedName));
    const stamp=new Date().toISOString();record.files=[...(record.files||[]).filter(f=>f.id!==request.replaceFileId),{id:file.getId(),name,url:file.getUrl(),mime:type,uploaded_at:stamp}];if(request.collection==='admin')record.available=true;record.version++;record.updated_at=stamp;
    if(JSON.stringify(record).length>40000)throw new Error('Catatan terlalu besar. Lampiran tersimpan di Drive tetapi belum ditautkan.');
    save_(ctx,request,record,email,stamp);
    return {data:WeddingCore.visible(ctx.db,actor)};
  }finally{lock.releaseLock();}
}
function getAttachment(request){
  const email=authorize_(),ctx=read_();access_(ctx,email,request.collection,false);
  const record=ctx.db[request.collection].find(x=>x.id===request.id);
  const item=record?.files?.find(f=>f.id===request.fileId);if(!item)throw new Error('Lampiran tidak tersedia.');
  const file=DriveApp.getFileById(item.id);const parents=file.getParents();let inFolder=false;while(parents.hasNext())if(parents.next().getId()===DRIVE_FOLDER_ID)inFolder=true;
  if(!inFolder)throw new Error('Berkas berada di luar folder aplikasi.');
  const blob=file.getBlob();if(blob.getBytes().length>5*1024*1024)throw new Error('Berkas terlalu besar untuk pratinjau.');
  return {name:item.name,mime:blob.getContentType(),base64:Utilities.base64Encode(blob.getBytes())};
}


/* Server-to-server bridge. Only a verified HMAC envelope sets the caller identity. */
var GATEWAY_EMAIL_='';
function bridgeRequest_(envelope,now) {
  const secret=PropertiesService.getScriptProperties().getProperty('GATEWAY_SECRET')||'';
  if(secret.length<32)throw new Error('Penghubung Google belum dikonfigurasi.');
  if(!envelope||typeof envelope.payload!=='string'||envelope.payload.length>20980000||! /^[a-f0-9]{64}$/.test(envelope.signature||''))throw new Error('Permintaan penghubung tidak valid.');
  const expected=Utilities.computeHmacSha256Signature(envelope.payload,secret,Utilities.Charset.UTF_8).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');
  let different=0;for(let i=0;i<64;i++)different|=expected.charCodeAt(i)^envelope.signature.charCodeAt(i);
  if(different)throw new Error('Tanda tangan penghubung tidak valid.');
  const payload=JSON.parse(envelope.payload);
  if(payload.v!==1||!Number.isSafeInteger(payload.timestamp)||Math.abs(now-payload.timestamp)>120000||! /^[\w-]{16,80}$/.test(payload.nonce||''))throw new Error('Permintaan penghubung kedaluwarsa atau tidak valid.');
  if(!['loadData','changeData','uploadAttachment','getAttachment','cloudUploadFile','cloudGetFile'].includes(payload.method))throw new Error('Metode penghubung tidak diizinkan.');
  const email=String(payload.email||'').trim().toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('Identitas penghubung tidak valid.');
  return {...payload,email};
}
function doPost(event) {
  let response;
  try{
    const body=event?.postData?.contents;if(!body||body.length>21000000)throw new Error('Ukuran permintaan tidak valid.');
    const request=bridgeRequest_(JSON.parse(body),Date.now());GATEWAY_EMAIL_=request.email;
    const handlers={loadData,changeData,uploadAttachment,getAttachment};
    if(typeof cloudUploadFile_==='function')handlers.cloudUploadFile=cloudUploadFile_;
    if(typeof cloudGetFile_==='function')handlers.cloudGetFile=cloudGetFile_;
    if(!handlers[request.method])throw new Error('Versi penghubung Drive belum dipasang.');
    response={ok:true,result:handlers[request.method](request.args)};
  }catch(error){response={ok:false,error:String(error.message||'Penghubung gagal.')};}
  finally{GATEWAY_EMAIL_='';}
  return ContentService.createTextOutput(JSON.stringify(response)).setMimeType(ContentService.MimeType.JSON);
}
function enableSupabaseGateway(){
  const email=Session.getActiveUser().getEmail().toLowerCase();
  if(!email||email!==ownerEmail_())throw new Error('Jalankan dari editor menggunakan akun pemilik.');
  const props=PropertiesService.getScriptProperties();if((props.getProperty('GATEWAY_SECRET')||'').length<32)throw new Error('Isi GATEWAY_SECRET minimal 32 karakter terlebih dahulu.');
  props.setProperty('GATEWAY_ONLY','true');return 'Penghubung aktif. Deploy sebagai pemilik; akses browser menggunakan Supabase.';
}


/* Run once from the Apps Script editor while signed into the owner Google account. */
function setupWeddingOwner(){
  const expected='hasanudin.legal@gmail.com';
  const active=Session.getActiveUser().getEmail().trim().toLowerCase();
  if(active!==expected)throw new Error('Jalankan dengan akun Google pemilik yang sudah ditentukan.');
  const props=PropertiesService.getScriptProperties(),existing=String(props.getProperty('OWNER_EMAIL')||'').trim().toLowerCase();
  if(existing&&existing!==expected)throw new Error('Pemilik berbeda sudah dikonfigurasi. Tidak ditimpa.');
  props.setProperty('OWNER_EMAIL',expected);
  if(!props.getProperty('ALLOWED_EMAILS'))props.setProperty('ALLOWED_EMAILS',expected);
  const secret=props.getProperty('GATEWAY_SECRET');
  if(!secret)props.setProperty('GATEWAY_SECRET',Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,''));
  else if(secret.length<32)throw new Error('GATEWAY_SECRET terlalu pendek. Perbaiki di Script properties.');
  initializeDatabase();enableSupabaseGateway();
  return 'Database dan penghubung siap. Deploy Web app sebagai pemilik, lalu isi secret penghubung yang sama di Supabase.';
}


/* Only called by a verified HMAC envelope. Worker enforces D1 membership. */
function cloudUploadFile_(request){
  if(!GATEWAY_EMAIL_)throw new Error('Tanda tangan penghubung diperlukan.');
  const maxMb=request&&request.purpose==='guest-transfer-proof'?15:5;
  if(!request||!/^[\w-]{16,80}$/.test(request.requestId||'')||typeof request.base64!=='string'||request.base64.length>Math.ceil(maxMb*1024*1024/3)*4)throw new Error('Permintaan unggah tidak valid.');
  const bytes=Utilities.base64Decode(request.base64),b=bytes.slice(0,8).map(x=>(x+256)%256),type=request.mime;
  if(bytes.length<4||bytes.length>maxMb*1024*1024)throw new Error('Berkas maksimal '+maxMb+' MB.');
  const valid=(type==='application/pdf'&&b.slice(0,4).join(',')==='37,80,68,70')||(type==='image/jpeg'&&b.slice(0,3).join(',')==='255,216,255')||(type==='image/png'&&b.slice(0,8).join(',')==='137,80,78,71,13,10,26,10')||(type==='application/msword'&&/\.doc$/i.test(request.name)&&b.slice(0,8).join(',')==='208,207,17,224,161,177,26,225')||(type==='application/vnd.openxmlformats-officedocument.wordprocessingml.document'&&/\.docx$/i.test(request.name)&&b.slice(0,4).join(',')==='80,75,3,4');
  if(!valid)throw new Error('Format berkas tidak valid.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{const folder=DriveApp.getFolderById(DRIVE_FOLDER_ID);if(folder.getSharingAccess()!==DriveApp.Access.PRIVATE)throw new Error('Ubah akses folder Drive menjadi Restricted sebelum upload.');
    const name=String(request.name||'lampiran').replace(/[\\/\x00-\x1f]/g,'_').slice(0,120),storedName='d1_'+request.requestId+'_'+name,files=folder.getFilesByName(storedName);
    const file=files.hasNext()?files.next():folder.createFile(Utilities.newBlob(bytes,type,storedName));
    return {id:file.getId(),name,mime:type,url:file.getUrl(),uploaded_at:new Date().toISOString()};
  }finally{lock.releaseLock();}
}
function cloudGetFile_(request){
  if(!GATEWAY_EMAIL_||!request||!/^[\w-]+$/.test(request.fileId||''))throw new Error('Permintaan berkas tidak valid.');
  const file=DriveApp.getFileById(request.fileId),parents=file.getParents();let allowed=false;while(parents.hasNext())if(parents.next().getId()===DRIVE_FOLDER_ID)allowed=true;
  if(!allowed)throw new Error('Berkas di luar folder aplikasi.');
  if(file.getSize()>15*1024*1024)throw new Error('Berkas maksimal 15 MB.');
  const blob=file.getBlob(),bytes=blob.getBytes();if(bytes.length>15*1024*1024)throw new Error('Berkas maksimal 15 MB.');
  return {name:String(request.name||file.getName()),mime:blob.getContentType(),base64:Utilities.base64Encode(bytes)};
}
