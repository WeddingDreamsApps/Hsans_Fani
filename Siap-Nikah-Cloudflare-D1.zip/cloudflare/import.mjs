// Owner exports loadData().data to private JSON; never commit that JSON.
import fs from 'node:fs';
import C from './core.mjs';
const [input,output]=process.argv.slice(2);if(!input||!output)throw new Error('Usage: node import.mjs private-export.json private-import.sql');
const original=JSON.parse(fs.readFileSync(input,'utf8')),data=original.data||original;
for(const collection of Object.keys(C.modules)){
  if(!Array.isArray(data[collection]))throw new Error('Missing collection: '+collection);
  const ids=new Set();for(const record of data[collection]){if(!record.id||ids.has(record.id))throw new Error('Duplicate/missing id');ids.add(record.id);C.validate(collection,record);if(!Number.isInteger(record.version)||record.version<1)throw new Error('Invalid version');}
}
const text=JSON.stringify(data);if(Buffer.byteLength(text)>1500000)throw new Error('Export exceeds initial room capacity');
const quote=text.replace(/'/g,"''");
fs.writeFileSync(output,"-- Import ONLY into an empty D1 room; existing state is never overwritten.\nUPDATE wedding_state SET data='"+quote+"',version=version+1 WHERE id=1 AND version=0 AND request_id IS NULL;\n");
console.log('Private import prepared. Verify affected rows and compare collection totals before switching the site.');
