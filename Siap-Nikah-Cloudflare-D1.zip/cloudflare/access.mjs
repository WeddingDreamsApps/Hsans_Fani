// Verify Access at the origin too: preview URLs and forged email headers must fail closed.
let cached;
function decode(part){return Uint8Array.from(atob(part.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));}
export async function accessIdentity(request,env){
  const domain=env.ACCESS_TEAM_DOMAIN||'',audience=env.ACCESS_AUD||'';
  if(!/^[a-z0-9-]+\.cloudflareaccess\.com$/.test(domain)||!audience)throw new Error('Login Cloudflare belum dikonfigurasi.');
  const token=request.headers.get('Cf-Access-Jwt-Assertion')||'';
  if(token.length>16000||token.split('.').length!==3)throw new Error('Silakan masuk melalui Cloudflare Access.');
  const parts=token.split('.');let header,claims;
  try{header=JSON.parse(new TextDecoder().decode(decode(parts[0])));claims=JSON.parse(new TextDecoder().decode(decode(parts[1])));}catch{throw new Error('Sesi login tidak valid.');}
  const now=Math.floor(Date.now()/1000);
  if(header.alg!=='RS256'||!header.kid||claims.iss!=='https://'+domain||!(Array.isArray(claims.aud)?claims.aud:[claims.aud]).includes(audience)||!Number.isFinite(claims.exp)||claims.exp<=now||(claims.nbf!==undefined&&claims.nbf>now+30)||!claims.sub||typeof claims.email!=='string'||!claims.email.includes('@'))throw new Error('Sesi login tidak valid atau sudah berakhir.');
  if(!cached||cached.domain!==domain||cached.until<Date.now()||!cached.keys.some(k=>k.kid===header.kid)){
    const response=await fetch('https://'+domain+'/cdn-cgi/access/certs',{signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw new Error('Login Cloudflare belum dapat diverifikasi.');
    const body=await response.json();if(!Array.isArray(body.keys))throw new Error('Kunci login tidak tersedia.');
    cached={domain,until:Date.now()+300000,keys:body.keys};
  }
  const jwk=cached.keys.find(k=>k.kid===header.kid&&k.kty==='RSA');if(!jwk)throw new Error('Kunci login tidak dikenal.');
  const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
  if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,decode(parts[2]),new TextEncoder().encode(parts[0]+'.'+parts[1])))throw new Error('Tanda tangan login tidak valid.');
  return {id:claims.sub,email:claims.email.toLowerCase()};
}
