# D1 + Workers + Drive

Status 2026-10-10: D1 and Worker deployed; website uses cloudflare-d1. Existing profile migrated and save/read verified online. Supabase handles login only. Drive upload is not yet verified: the stored Worker configuration failed validation. Live upload identified GATEWAY_SECRET as empty or shorter than 32 characters. The owner must copy the exact existing Apps Script property into the Cloudflare secret and deploy before upload/view/download can be verified.

1. On Workers Free, create D1 database `siap-nikah`; apply schema.sql and insert its ID in wrangler.jsonc. No paid plan or R2 required.
2. Copy core.js plus `export default WeddingCore;` into core.mjs whenever shared rules change. Deploy worker.mjs and core.mjs using Wrangler, binding DB to the new database.
3. Set GOOGLE_APPS_SCRIPT_URL and GATEWAY_SECRET as Worker secrets. Owner enters the existing secret directly, never in GitHub or chat. Public vars are in wrangler.jsonc.
4. Add CloudDrive.gs and updated Gateway.gs to the existing Apps Script project; update its existing deployment. Direct cloud file functions end in underscore and require verified HMAC; membership comes from D1 via the Worker. Drive folder must remain Restricted.
5. Before cutover export the old owner's data privately, run import.mjs and apply generated SQL ONLY to the empty room. Compare counts, payments, savings, guest receipts and attachment IDs. Never publish the private export/import.
6. Verify owner login, save/reload, CAS conflict, retry idempotency, budget totals, committee denial, Drive upload/view/download. Then set config.public.json mode to cloudflare-d1 and workerUrl to the actual HTTPS workers.dev URL, build and publish index. No secret enters the client.

The initial personal-room schema stores one JSON snapshot (max 1.5 MB), with indexed rate limit and audit tables. A version compare prevents concurrent overwrites; an SQLite trigger commits audit in the same state update. A larger application should split records across tables. Drive upload and D1 update are not a distributed transaction: a failed update may leave an unlinked Drive file; replay uses a stable request filename. Uploaded files are not antivirus scanned.

Free plan has daily request/read/write limits; service may stop until reset when limits are reached. This is not unlimited free hosting. Check current official pricing:
- https://developers.cloudflare.com/d1/platform/pricing/
- https://developers.cloudflare.com/workers/platform/pricing/

Free-tier controls: no polling or automatic repeated saves; load scans one state row by primary key; rate counter is capped at 61 per account per minute, so further rejected requests do not keep writing D1. Snapshot capacity is 1.5 MB, attachments live in Drive rather than the database, and each file is capped at 5 MB. The Workers Free CPU allowance is only 10 ms per invocation: maximum-size uploads and large snapshots still require real workload verification; the file-size cap is not a throughput guarantee. Do not upgrade plans automatically.

Do not delete old Sheets, data, or Supabase gateway before verified cutover and backup.

