-- Apply to a NEW D1 database. Wedding data remains private behind the Worker.
CREATE TABLE IF NOT EXISTS wedding_state (
 id INTEGER PRIMARY KEY CHECK(id=1), version INTEGER NOT NULL DEFAULT 0,
 data TEXT NOT NULL CHECK(json_valid(data)), request_id TEXT,
 actor TEXT, fingerprint TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS wedding_audit (
 request_id TEXT PRIMARY KEY, actor TEXT NOT NULL, fingerprint TEXT NOT NULL,
 state_version INTEGER NOT NULL, timestamp TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS wedding_state_audit AFTER UPDATE ON wedding_state
WHEN NEW.request_id IS NOT NULL
BEGIN
 INSERT INTO wedding_audit VALUES(NEW.request_id,NEW.actor,NEW.fingerprint,NEW.version,NEW.updated_at);
END;
CREATE TABLE IF NOT EXISTS wedding_limits (
 user_id TEXT PRIMARY KEY, minute INTEGER NOT NULL, requests INTEGER NOT NULL
);
INSERT OR IGNORE INTO wedding_state(id,data) VALUES(1,'{"profile":[],"budget":[],"savings":[],"gifts":[],"vendors":[],"admin":[],"guests":[],"tasks":[],"rundown":[],"users":[]}');
