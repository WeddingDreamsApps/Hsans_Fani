/* Run once from the Apps Script editor while signed into the owner Google account. */
function setupWeddingOwner(){
  const expected='hasanudin.legal@gmail.com';
  const active=Session.getActiveUser().getEmail().trim().toLowerCase();
  if(active!==expected)throw new Error('Jalankan dengan akun Google pemilik yang sudah ditentukan.');
  const props=PropertiesService.getScriptProperties(),existing=String(props.getProperty('OWNER_EMAIL')||'').trim().toLowerCase();
  if(existing&&existing!==expected)throw new Error('Pemilik berbeda sudah dikonfigurasi. Tidak ditimpa.');
  props.setProperty('OWNER_EMAIL',expected);
  if(!props.getProperty('ALLOWED_EMAILS'))props.setProperty('ALLOWED_EMAILS',expected);
  const secret=props.getProperty('GATEWAY_SECRET');
  if(!secret)props.setProperty('GATEWAY_SECRET',Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,''));
  else if(secret.length<32)throw new Error('GATEWAY_SECRET terlalu pendek. Perbaiki di Script properties.');
  initializeDatabase();enableSupabaseGateway();
  return 'Database dan penghubung siap. Deploy Web app sebagai pemilik, lalu isi secret penghubung yang sama di Supabase.';
}
