/* Deploy only one Apps Script project for this workbook. */
const SPREADSHEET_ID = '1hG9wUKF28ErTIlxfKQPqznzEbBy4_z6mojQ9U13I_Rc';
const DRIVE_FOLDER_ID = '11l-_WvlejNKYFxjwjzoOq0NsjcSgdKQ0';
const HEADER = ['id','version','nama','status','nominal','tanggal','penanggung_jawab','data_json','updated_at'];

// Run manually once from the script editor while signed in as the workbook owner.
function initializeDatabase() {
  const bootstrapEmail=authorize_(true);
  if(bootstrapEmail!==ownerEmail_())throw new Error('Hanya akun utama yang boleh menyiapkan database.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try {
    const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
    const specs=Object.values(WeddingCore.modules).map(m=>[m.sheet,HEADER]);
    specs.push(['SN_Audit',['request_id','timestamp','actor','action','collection','record_id','fingerprint']]);
    specs.forEach(([name,headers])=>{
      let sheet=ss.getSheetByName(name);
      if(sheet&&sheet.getLastRow()>0){
        if(JSON.stringify(sheet.getRange(1,1,1,headers.length).getValues()[0])!==JSON.stringify(headers))throw new Error('Header berbeda pada '+name+'. Data tidak ditimpa.');
        return;
      }
      if(!sheet)sheet=ss.insertSheet(name);
      sheet.getRange(1,1,1,headers.length).setValues([headers]).setFontWeight('bold').setBackground('#eeeeee');sheet.setFrozenRows(1);sheet.setColumnWidths(1,headers.length,160);
      if(headers.length===9)sheet.setColumnWidth(8,320);
    });
    return 'Database siap. Tab lama tetap dipertahankan.';
  } finally {lock.releaseLock();}
}

function authorize_(allowDirectOwner) {
  const props=PropertiesService.getScriptProperties();
  const verified=typeof GATEWAY_EMAIL_!=='undefined'&&GATEWAY_EMAIL_;
  const email=String(verified||Session.getActiveUser().getEmail()).toLowerCase();
  if(props.getProperty('GATEWAY_ONLY')==='true'&&!verified&&!(allowDirectOwner===true&&email===ownerEmail_()))throw new Error('Masuk melalui aplikasi Supabase.');
  const allowed = (PropertiesService.getScriptProperties().getProperty('ALLOWED_EMAILS') || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
  if(!email)throw new Error('Identitas Google tidak tersedia. Masuk dengan akun yang diizinkan.');
  if(email===ownerEmail_())return email;
  const sheet=SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName('SN_Pengguna');
  let registered=false;
  if(sheet&&sheet.getLastRow()>1)registered=sheet.getRange(2,8,sheet.getLastRow()-1,1).getValues().some(row=>{try{const user=JSON.parse(row[0]);return user.email===email&&user.status==='Aktif';}catch(e){return false;}});
  if(!registered)throw new Error('Akses belum diizinkan. Akun utama perlu menambahkan pengguna aktif.');
  return email;
}
function ownerEmail_(){const props=PropertiesService.getScriptProperties();return String(props.getProperty('OWNER_EMAIL')||(props.getProperty('ALLOWED_EMAILS')||'').split(',')[0]||'').trim().toLowerCase();}
function actor_(ctx,email){
  if(email===ownerEmail_())return {email,owner:true,role:'Akun utama'};
  const u=ctx.db.users.find(x=>x.email===email&&x.status==='Aktif');
  if(!u)throw new Error('Akses akun sudah dicabut.');
  return {email,owner:false,role:u.role,permissions:JSON.parse(u.permissions||'{}')};
}
function access_(ctx,email,key,write){const actor=actor_(ctx,email);if(!WeddingCore.can(actor,key,write))throw new Error('Anda tidak memiliki izin untuk modul ini.');return actor;}
function doGet() {
  if(PropertiesService.getScriptProperties().getProperty('GATEWAY_ONLY')==='true')return ContentService.createTextOutput('Penghubung Google aktif. Buka aplikasi GitHub dan masuk dengan akun yang diizinkan.');
  authorize_();
  return HtmlService.createHtmlOutputFromFile('Index').setTitle('Siap Nikah').addMetaTag('viewport','width=device-width, initial-scale=1');
}
function read_() {
  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);const db=WeddingCore.blank();const sheets={};
  Object.keys(WeddingCore.modules).forEach(key=>{
    const sheet=ss.getSheetByName(WeddingCore.modules[key].sheet);
    if(!sheet)throw new Error('Tabel belum tersedia: '+WeddingCore.modules[key].sheet);
    const header=sheet.getRange(1,1,1,9).getValues()[0];
    if(JSON.stringify(header)!==JSON.stringify(HEADER))throw new Error('Struktur tabel berubah. Jangan mengubah header database.');
    sheets[key]={id:sheet.getSheetId(),rows:{},next:sheet.getLastRow()};
    if(sheet.getLastRow()>1)sheet.getRange(2,1,sheet.getLastRow()-1,9).getValues().forEach((row,i)=>{
      if(row[0]){const record=JSON.parse(row[7]);if(record.id!==row[0])throw new Error('Data tidak konsisten.');db[key].push(record);sheets[key].rows[record.id]=i+1;}
    });
  });
  return {ss,db,sheets};
}
function loadData() {
  const email=authorize_();const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{const ctx=read_(),actor=actor_(ctx,email);return {data:WeddingCore.visible(ctx.db,actor),actor,email,mode:'live',serverTime:new Date().toISOString()};}finally{lock.releaseLock();}
}
function auditFind_(ss,id) {
  const sheet=ss.getSheetByName('SN_Audit');if(!sheet)throw new Error('Tabel audit belum tersedia.');
  if(sheet.getLastRow()<2)return null;
  const found=sheet.getRange(2,1,sheet.getLastRow()-1,1).createTextFinder(id).matchEntireCell(true).findNext();
  return found?sheet.getRange(found.getRow(),1,1,7).getValues()[0]:null;
}
function fingerprint_(request){return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,JSON.stringify(request)));}
function cell_(v){return {userEnteredValue:typeof v==='number'?{numberValue:v}:{stringValue:String(v??'')}};}
function save_(ctx,request,record,email,stamp) {
  const table=ctx.sheets[request.collection];const row=table.rows[request.id]??table.next;
  const sheet=ctx.ss.getSheetByName(WeddingCore.modules[request.collection].sheet);
  const audit=ctx.ss.getSheetByName('SN_Audit');const requests=[];
  if(row>=sheet.getMaxRows())requests.push({appendDimension:{sheetId:table.id,dimension:'ROWS',length:100}});
  const values=record?[record.id,record.version,record.name,record.status||'',record.amount||0,record.date||record.start||'',record.owner||'',JSON.stringify(record),record.updated_at]:Array(9).fill('');
  requests.push({updateCells:{start:{sheetId:table.id,rowIndex:row,columnIndex:0},rows:[{values:values.map(cell_)}],fields:'userEnteredValue'}});
  requests.push({appendCells:{sheetId:audit.getSheetId(),rows:[{values:[request.requestId,stamp,email,request.action,request.collection,request.id,fingerprint_(request)].map(cell_)}],fields:'userEnteredValue'}});
  Sheets.Spreadsheets.batchUpdate({requests},SPREADSHEET_ID);
}
function changeData(request) {
  const email=authorize_();
  if(!request||typeof request.requestId!=='string'||!/^[\w-]{16,80}$/.test(request.requestId))throw new Error('Identitas permintaan tidak valid.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const ctx=read_();const actor=access_(ctx,email,request.collection,true);const prior=auditFind_(ctx.ss,request.requestId);
    if(request.collection==='users'&&String(request.data?.email||'').toLowerCase()===ownerEmail_())throw new Error('Akun utama diatur melalui konfigurasi pemilik dan tidak dapat diganti di sini.');
    if(prior){if(prior[2]!==email||prior[6]!==fingerprint_(request))throw new Error('Permintaan sebelumnya sudah tersimpan. Muat ulang sebelum mengirim perubahan baru.');return {data:WeddingCore.visible(ctx.db,actor),duplicate:true};}
    const stamp=new Date().toISOString();const result=WeddingCore.mutate(ctx.db,request,stamp);
    save_(ctx,request,result.record||null,email,stamp);
    return {data:WeddingCore.visible(ctx.db,actor)};
  }finally{lock.releaseLock();}
}
function uploadAttachment(request) {
  const email=authorize_();
  if(!request||!Object.hasOwn(WeddingCore.modules,request.collection)||typeof request.requestId!=='string'||!/^[\w-]{16,80}$/.test(request.requestId))throw new Error('Permintaan unggah tidak valid.');
  if(typeof request.base64!=='string'||request.base64.length>7000000)throw new Error('Berkas maksimal 5 MB.');
  request.action='upload';
  const bytes=Utilities.base64Decode(request.base64);if(bytes.length>5*1024*1024||bytes.length<4)throw new Error('Ukuran berkas tidak valid.');
  const b=bytes.map(x=>(x+256)%256);const type=request.mime;
  const valid=(type==='application/pdf'&&b[0]===37&&b[1]===80&&b[2]===68&&b[3]===70)||(type==='image/jpeg'&&b[0]===255&&b[1]===216&&b[2]===255)||(type==='image/png'&&b.slice(0,8).join(',')==='137,80,78,71,13,10,26,10')||(type==='application/vnd.openxmlformats-officedocument.wordprocessingml.document'&&/\.docx$/i.test(request.name)&&b[0]===80&&b[1]===75&&b[2]===3&&b[3]===4)||(type==='application/msword'&&/\.doc$/i.test(request.name)&&b.slice(0,8).join(',')==='208,207,17,224,161,177,26,225');
  if(!valid)throw new Error('Gunakan PDF, JPG, PNG, DOC, atau DOCX yang valid.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const ctx=read_();const actor=access_(ctx,email,request.collection,true);const prior=auditFind_(ctx.ss,request.requestId);
    if(prior){if(prior[2]!==email||prior[6]!==fingerprint_(request))throw new Error('Identitas unggah telah digunakan.');return {data:WeddingCore.visible(ctx.db,actor)};}
    const record=ctx.db[request.collection].find(x=>x.id===request.id);
    if(!record||record.version!==request.version)throw new Error('Catatan berubah. Muat ulang sebelum unggah.');
    if(request.replaceFileId&&!record.files?.some(f=>f.id===request.replaceFileId))throw new Error('Lampiran yang akan diganti tidak ditemukan.');
    if((record.files||[]).length>=10&&!request.replaceFileId)throw new Error('Maksimal 10 lampiran per catatan.');
    const folder=DriveApp.getFolderById(DRIVE_FOLDER_ID);
    if(folder.getSharingAccess()!==DriveApp.Access.PRIVATE)throw new Error('Folder dibagikan melalui tautan/domain. Ubah General access menjadi Restricted sebelum unggah dokumen.');
    const name=String(request.name||'lampiran').replace(/[\\/\x00-\x1f]/g,'_').slice(0,120);
    // A stable request prefix permits recovery after an uncertain upload response.
    const storedName=request.requestId+'_'+name;const existing=folder.getFilesByName(storedName);
    const file=existing.hasNext()?existing.next():folder.createFile(Utilities.newBlob(bytes,type,storedName));
    const stamp=new Date().toISOString();record.files=[...(record.files||[]).filter(f=>f.id!==request.replaceFileId),{id:file.getId(),name,url:file.getUrl(),mime:type,uploaded_at:stamp}];if(request.collection==='admin')record.available=true;record.version++;record.updated_at=stamp;
    if(JSON.stringify(record).length>40000)throw new Error('Catatan terlalu besar. Lampiran tersimpan di Drive tetapi belum ditautkan.');
    save_(ctx,request,record,email,stamp);
    return {data:WeddingCore.visible(ctx.db,actor)};
  }finally{lock.releaseLock();}
}
function getAttachment(request){
  const email=authorize_(),ctx=read_();access_(ctx,email,request.collection,false);
  const record=ctx.db[request.collection].find(x=>x.id===request.id);
  const item=record?.files?.find(f=>f.id===request.fileId);if(!item)throw new Error('Lampiran tidak tersedia.');
  const file=DriveApp.getFileById(item.id);const parents=file.getParents();let inFolder=false;while(parents.hasNext())if(parents.next().getId()===DRIVE_FOLDER_ID)inFolder=true;
  if(!inFolder)throw new Error('Berkas berada di luar folder aplikasi.');
  const blob=file.getBlob();if(blob.getBytes().length>5*1024*1024)throw new Error('Berkas terlalu besar untuk pratinjau.');
  return {name:item.name,mime:blob.getContentType(),base64:Utilities.base64Encode(blob.getBytes())};
}
