/* Server-to-server bridge. Only a verified HMAC envelope sets the caller identity. */
var GATEWAY_EMAIL_='';
function bridgeRequest_(envelope,now) {
  const secret=PropertiesService.getScriptProperties().getProperty('GATEWAY_SECRET')||'';
  if(secret.length<32)throw new Error('Penghubung Google belum dikonfigurasi.');
  if(!envelope||typeof envelope.payload!=='string'||envelope.payload.length>7200000||! /^[a-f0-9]{64}$/.test(envelope.signature||''))throw new Error('Permintaan penghubung tidak valid.');
  const expected=Utilities.computeHmacSha256Signature(envelope.payload,secret,Utilities.Charset.UTF_8).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');
  let different=0;for(let i=0;i<64;i++)different|=expected.charCodeAt(i)^envelope.signature.charCodeAt(i);
  if(different)throw new Error('Tanda tangan penghubung tidak valid.');
  const payload=JSON.parse(envelope.payload);
  if(payload.v!==1||!Number.isSafeInteger(payload.timestamp)||Math.abs(now-payload.timestamp)>120000||! /^[\w-]{16,80}$/.test(payload.nonce||''))throw new Error('Permintaan penghubung kedaluwarsa atau tidak valid.');
  if(!['loadData','changeData','uploadAttachment','getAttachment','cloudUploadFile','cloudGetFile'].includes(payload.method))throw new Error('Metode penghubung tidak diizinkan.');
  const email=String(payload.email||'').trim().toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('Identitas penghubung tidak valid.');
  return {...payload,email};
}
function doPost(event) {
  let response;
  try{
    const body=event?.postData?.contents;if(!body||body.length>7300000)throw new Error('Ukuran permintaan tidak valid.');
    const request=bridgeRequest_(JSON.parse(body),Date.now());GATEWAY_EMAIL_=request.email;
    const handlers={loadData,changeData,uploadAttachment,getAttachment};
    if(typeof cloudUploadFile_==='function')handlers.cloudUploadFile=cloudUploadFile_;
    if(typeof cloudGetFile_==='function')handlers.cloudGetFile=cloudGetFile_;
    if(!handlers[request.method])throw new Error('Versi penghubung Drive belum dipasang.');
    response={ok:true,result:handlers[request.method](request.args)};
  }catch(error){response={ok:false,error:String(error.message||'Penghubung gagal.')};}
  finally{GATEWAY_EMAIL_='';}
  return ContentService.createTextOutput(JSON.stringify(response)).setMimeType(ContentService.MimeType.JSON);
}
function enableSupabaseGateway(){
  const email=Session.getActiveUser().getEmail().toLowerCase();
  if(!email||email!==ownerEmail_())throw new Error('Jalankan dari editor menggunakan akun pemilik.');
  const props=PropertiesService.getScriptProperties();if((props.getProperty('GATEWAY_SECRET')||'').length<32)throw new Error('Isi GATEWAY_SECRET minimal 32 karakter terlebih dahulu.');
  props.setProperty('GATEWAY_ONLY','true');return 'Penghubung aktif. Deploy sebagai pemilik; akses browser menggunakan Supabase.';
}
