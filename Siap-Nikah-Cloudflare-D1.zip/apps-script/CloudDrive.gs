/* Only called by a verified HMAC envelope. Worker enforces D1 membership. */
function cloudUploadFile_(request){
  if(!GATEWAY_EMAIL_)throw new Error('Tanda tangan penghubung diperlukan.');
  if(!request||!/^[\w-]{16,80}$/.test(request.requestId||'')||typeof request.base64!=='string'||request.base64.length>7000000)throw new Error('Permintaan unggah tidak valid.');
  const bytes=Utilities.base64Decode(request.base64),b=bytes.map(x=>(x+256)%256),type=request.mime;
  if(bytes.length<4||bytes.length>5*1024*1024)throw new Error('Berkas maksimal 5 MB.');
  const valid=(type==='application/pdf'&&b.slice(0,4).join(',')==='37,80,68,70')||(type==='image/jpeg'&&b.slice(0,3).join(',')==='255,216,255')||(type==='image/png'&&b.slice(0,8).join(',')==='137,80,78,71,13,10,26,10')||(type==='application/msword'&&/\.doc$/i.test(request.name)&&b.slice(0,8).join(',')==='208,207,17,224,161,177,26,225')||(type==='application/vnd.openxmlformats-officedocument.wordprocessingml.document'&&/\.docx$/i.test(request.name)&&b.slice(0,4).join(',')==='80,75,3,4');
  if(!valid)throw new Error('Format berkas tidak valid.');
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{const folder=DriveApp.getFolderById(DRIVE_FOLDER_ID);if(folder.getSharingAccess()!==DriveApp.Access.PRIVATE)throw new Error('Ubah akses folder Drive menjadi Restricted sebelum upload.');
    const name=String(request.name||'lampiran').replace(/[\\/\x00-\x1f]/g,'_').slice(0,120),storedName='d1_'+request.requestId+'_'+name,files=folder.getFilesByName(storedName);
    const file=files.hasNext()?files.next():folder.createFile(Utilities.newBlob(bytes,type,storedName));
    return {id:file.getId(),name,mime:type,url:file.getUrl(),uploaded_at:new Date().toISOString()};
  }finally{lock.releaseLock();}
}
function cloudGetFile_(request){
  if(!GATEWAY_EMAIL_||!request||!/^[\w-]+$/.test(request.fileId||''))throw new Error('Permintaan berkas tidak valid.');
  const file=DriveApp.getFileById(request.fileId),parents=file.getParents();let allowed=false;while(parents.hasNext())if(parents.next().getId()===DRIVE_FOLDER_ID)allowed=true;
  if(!allowed)throw new Error('Berkas di luar folder aplikasi.');
  const blob=file.getBlob(),bytes=blob.getBytes();if(bytes.length>5*1024*1024)throw new Error('Berkas maksimal 5 MB.');
  return {name:String(request.name||file.getName()),mime:blob.getContentType(),base64:Utilities.base64Encode(bytes)};
}
