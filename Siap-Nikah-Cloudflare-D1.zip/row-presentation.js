/* Display only. Original records, editors and action handlers stay authoritative. */
function alignFeatureRows(){
 const view=document.getElementById('view');if(!view)return;
 view.querySelectorAll('table.table:not(.user-permission-matrix)').forEach(table=>{
  const heads=[...table.querySelectorAll('thead th')];if(heads.length<2)return;
  table.classList.add('aligned-data-table');
  if(table.classList.contains('gift-sheet-table')||table.classList.contains('finance-table'))return;
  const labels=heads.map(h=>h.textContent.trim()),last=heads.length-1;
  const actions=!labels[last]||/Aksi|Tindakan/.test(labels[last])||!!table.querySelector('tbody tr td:last-child :is(button,a)');
  if(!actions)return; if(!heads[last].textContent.trim())heads[last].textContent='Aksi';
  const status=labels.findIndex((v,i)=>i>0&&/Status|Konfirmasi|Kehadiran/.test(v));
  const amount=labels.findIndex((v,i)=>i>0&&/Biaya|Nominal|Komitmen|Uang|Estimasi|Waktu/.test(v));
  let keep=[0,...new Set([amount>0?amount:1,status>0?status:2].filter(i=>i<last&&i>0)),last];
  if(table.classList.contains('document-data-table')&&amount<0)keep=[0,status>0?status:1,last];
  const widths=keep.length===4?[40,19,19,22]:[52,26,22];
  heads.forEach((h,i)=>{h.classList.add('aligned-cell');h.classList.toggle('aligned-secondary',!keep.includes(i));h.style.setProperty('--row-width',(widths[keep.indexOf(i)]||0)+'%');});
  table.querySelectorAll('tbody tr').forEach(row=>{
   if(row.dataset.alignedRow==='true')return;
   row.dataset.alignedRow='true';const cells=[...row.children];if(cells.length!==heads.length)return;
   const primary=cells[0],tail=cells[last],details=document.createElement('div');details.className='aligned-mobile-details';
   if(table.classList.contains('document-data-table')){const title=primary.querySelector('h3');if(title)title.textContent=title.textContent.replace(/surat pengantar nikah desa\s*\/\s*kelurahan/i,'Surat pengantar nikah desa');}
   cells.forEach((cell,i)=>{
    cell.classList.add('aligned-cell');cell.classList.toggle('aligned-secondary',!keep.includes(i));cell.style.setProperty('--row-width',(widths[keep.indexOf(i)]||0)+'%');
    if(keep.includes(i))return;
    const value=cell.textContent.trim();
    if(value&&value!=='—'&&value!=='-'&&!primary.textContent.includes(value)&&!cell.querySelector('button,a')){
     const detail=document.createElement('small');detail.textContent=table.classList.contains('document-data-table')&&/Mempelai|Remark/.test(labels[i])?value:labels[i]+': '+value;details.append(detail);
    }
    cell.querySelectorAll('button,a').forEach(control=>{
     const shortcut=control.cloneNode(true);shortcut.classList.add('aligned-mobile-action');
     shortcut.removeAttribute('id');shortcut.addEventListener('click',event=>{event.preventDefault();if(control.dataset.docFile){const record=db.admin.find(x=>x.id===control.dataset.docRecord);if(record)openFile('admin',record,control.dataset.docFile,false);}else control.click();});
     (tail.querySelector('div')||tail).prepend(shortcut);
    });
   });
   if(details.childElementCount)primary.append(details);
  });
 });
}
let featureRowFrame=0;
new MutationObserver(()=>{if(featureRowFrame)return;featureRowFrame=requestAnimationFrame(()=>{featureRowFrame=0;alignFeatureRows();});}).observe(document.getElementById('view'),{childList:true,subtree:true});
alignFeatureRows();



