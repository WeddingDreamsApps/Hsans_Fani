# Integrasi terkini — Google utama, Supabase penghubung

Google Sheets menyimpan data pernikahan dan Google Drive menyimpan berkas. Supabase menyediakan login, pembatasan permintaan, dan Edge Function penghubung. Paket kode sudah dibuat dan diuji lokal; project Supabase dan email pemilik sudah dikonfigurasi. Aktivasi cloud masih menunggu pemasangan SQL/Edge Function, deployment Apps Script, dan akses tulis GitHub.

Ikuti [panduan aktivasi terbaru](docs/AKTIVASI-SUPABASE-GOOGLE.md). Panduan ini menggantikan instruksi deployment versi lama di bawah, terutama akses panitia dan identitas eksekusi Apps Script. Akun panitia tidak perlu akses langsung ke sumber spreadsheet atau folder Drive.

---

# Siap Nikah

> **Versi index saat ini: 0.2.** Pengelompokan/status belanja seserahan, checklist & berkas KUA, integrasi undangan, invoice, manajemen pengguna, serta menu bawah ponsel sudah ditambahkan. Lihat [perubahan v0.2](docs/PERUBAHAN-V0.2.md) untuk detail dan batas deployment akses panitia. Bagian v0.1 di bawah adalah catatan versi awal; pernyataan bahwa role belum dibuat kini digantikan oleh perubahan v0.2. Koneksi Google nyata masih belum aktif.

Aplikasi persiapan menikah berbahasa Indonesia, dengan Google Sheets sebagai penyimpanan utama dan Google Drive untuk lampiran. Antarmuka menggunakan warna magenta dari referensi pengguna.

## Status pekerjaan

Versi awal 0.1 sudah berisi kode antarmuka, aturan bisnis, backend Google Apps Script, dan pengujian lokal. **Belum aktif menyimpan data nyata** sampai Apps Script dipasang dan diotorisasi. Pratinjau Sites menggunakan data sintetis di memori; tidak menghubungi spreadsheet dan perubahan hilang saat refresh.

Percobaan menambahkan tabel ke spreadsheet melalui koneksi Google pada 9 Oktober 2026 ditolak `403 PERMISSION_DENIED`, termasuk setelah pemeriksaan ulang. Tab awal `Sheet1` tidak diubah. Fungsi `initializeDatabase` disediakan untuk menambahkan tabel tanpa menimpa tab lama.

Repository tujuan sudah diketahui: WeddingDreamsApps/Hsans_Fani. Akun GitHub yang terhubung hanya memiliki akses baca, sehingga kode terbaru belum dapat dikirim. Tidak ada API key yang disimpan dalam paket ini. API key yang pernah dibagikan dalam chat tidak diperlukan untuk pendekatan Apps Script.

## Fitur versi ini

- Dashboard dengan hitung mundur, progres tugas, keuangan, dan undangan.
- Data mempelai, tanggal, lokasi, anggaran dan target tabungan.
- Item biaya, pembayaran, refund, sisa tagihan, serta peringatan kelebihan bayar.
- Catatan tabungan yang tidak dapat diedit/hapus, dengan koreksi melalui transaksi baru.
- Daftar seserahan/mahar, vendor/venue, serta checklist administrasi.
- Daftar undangan per acara dan RSVP manual dengan batas kuota.
- Checklist tugas dengan PIC, prioritas, status, dan tenggat.
- Rundown dengan deteksi benturan PIC/lokasi, kegiatan lintas tengah malam, dan cetak.
- Pencarian, filter, ekspor CSV, lampiran PDF/JPG/PNG hingga 5 MB setelah aktivasi.
- Validasi server, penguncian penulisan, nomor versi, kunci idempotensi, serta audit perubahan.

Versi awal khusus **satu pasangan per spreadsheet**. Semua akun yang diizinkan mendapat akses penuh. Panitia cukup menerima hasil cetak rundown; jangan beri akses spreadsheet jika mereka tidak boleh membaca keuangan atau dokumen.

Belum dibuat: aplikasi multi-pasangan, peran panitia terbatas, undangan anggota dari UI, RSVP publik, impor CSV, notifikasi otomatis, termin pembayaran terpisah, multi-event terstruktur, task tanggal relatif, soft delete 30 hari, dan pemindaian malware. Dokumen PRD penuh tetap menjadi backlog; versi ini bukan klaim semua P0 PRD sudah selesai.

## Penyimpanan tujuan

- Spreadsheet: https://docs.google.com/spreadsheets/d/1hG9wUKF28ErTIlxfKQPqznzEbBy4_z6mojQ9U13I_Rc/edit
- Folder berkas: https://drive.google.com/drive/folders/11l-_WvlejNKYFxjwjzoOq0NsjcSgdKQ0

Tabel tambahan: `SN_Mempelai`, `SN_Anggaran`, `SN_Tabungan`, `SN_Seserahan`, `SN_Vendor`, `SN_Administrasi`, `SN_Undangan`, `SN_Checklist`, `SN_Rundown`, dan `SN_Audit`.

Kolom 1–9 pada tabel modul: `id`, `version`, `nama`, `status`, `nominal`, `tanggal`, `penanggung_jawab`, `data_json`, `updated_at`. Kolom ringkasan membantu inspeksi manusia; `data_json` adalah catatan lengkap yang dibaca aplikasi. **Jangan mengubah tabel SN_ secara langsung**, termasuk kolom ringkasan. Edit dari aplikasi agar versi dan audit konsisten. Spreadsheet asli atau tab lain tetap boleh dipakai secara terpisah.

Setiap item biaya menyimpan pembayaran/refund sebagai ledger dalam record yang sama. Pemakaian tabungan dihitung dari pembayaran yang bersumber dari Tabungan; tidak dicatat lagi sebagai penarikan manual. Ini mencegah hitungan ganda. Refund tidak boleh melebihi pembayaran dari sumber yang dipilih. Kelebihan bayar pada satu item tidak mengurangi utang item lain.

## Aktivasi Google satu kali

1. Masuk menggunakan akun pemilik/editor spreadsheet. Buka spreadsheet → **Extensions / Ekstensi → Apps Script**.
2. Pada editor Apps Script, buat/pasang berkas berikut dari folder `apps-script`:
   - `Code.gs`
   - `Core.gs`
   - file HTML bernama `Index` (isi dari `Index.html`)
   - `appsscript.json` (aktifkan tampilan manifest lewat Project Settings).
3. Di **Project Settings → Script properties**, tambahkan `ALLOWED_EMAILS` dengan email Google pemilik. Untuk akses pasangan, tambahkan email pasangan dipisahkan koma. Daftar ini kosong secara default; akses ditolak sampai diisi. Jangan taruh email palsu atau token di kode.
4. Aktifkan **Google Sheets API v4** pada Services bila belum muncul setelah pemasangan manifest. Bila memakai Cloud project khusus, aktifkan Sheets API pada project yang sama.
5. Jalankan `initializeDatabase` dari editor. Google akan meminta otorisasi. Kode memerlukan akses Sheets, Drive, dan alamat email pengguna. Izin Drive yang diminta oleh DriveApp cukup luas, tetapi kode hanya menulis ke folder tujuan tetap; baca layar persetujuan sebelum menyetujui.
6. **Deploy → New deployment → Web app**. Pilih **Execute as: User accessing the web app**. Untuk pemakaian sendiri, pilih akses **Only myself**. Manifest awal menetapkan akses ini. Jangan menggunakan anonymous/anyone without sign-in.
7. Buka URL deployment yang dihasilkan Google. Aplikasi meminta otorisasi pengguna dan menampilkan data nyata. Tidak ada data contoh yang dimasukkan ke spreadsheet.
8. Untuk pasangan: pemilik secara sadar membagikan folder dan spreadsheet hanya kepada email pasangan sebagai Editor, menambahkan email itu ke `ALLOWED_EMAILS`, lalu mengubah audience deployment ke pengguna Google yang sesuai jika tersedia pada akun. Kode tetap memeriksa allowlist setiap operasi. Pilihan audience bisa berbeda menurut jenis akun/kebijakan organisasi.

**Jangan deploy sebagai “Me” untuk pengguna lain.** Arsitektur ini menjalankan operasi dengan izin pengguna aktif. Jika email aktif tidak tersedia, aplikasi menolak akses, bukan mempercayai email yang dikirim browser. Folder harus **Restricted**, tanpa akses publik/domain lewat tautan, sebelum unggah. Daftar orang yang secara eksplisit sudah diberi akses tetap berlaku untuk lampiran; periksa daftar itu sendiri.

Satu workbook hanya boleh dipakai oleh **satu project Apps Script** aplikasi. LockService melindungi penulisan dalam project ini; editor spreadsheet langsung atau project script lain tidak mengikuti lock.

## Uji setelah aktivasi

1. Masukkan profil pasangan dan satu item biaya uji Rp20.000.
2. Catat setoran Rp10.000, lalu DP Rp5.000 bersumber dari Tabungan. Saldo harus Rp5.000 dan sisa tagihan Rp15.000.
3. Catat refund Rp2.000 dari sumber yang sama. Saldo harus Rp7.000 dan pembayaran bersih Rp3.000.
4. Muat ulang halaman dan pastikan data tetap ada. Periksa baris di `SN_Anggaran`, `SN_Tabungan`, dan `SN_Audit`.
5. Unggah berkas contoh nonsensitif pada sebuah catatan. Periksa file masuk ke folder yang ditentukan dan tidak dibagikan ke publik.
6. Pastikan akun di luar allowlist ditolak. Uji edit dua tab: penyimpanan versi lama harus ditolak.
7. Setelah semua lolos, mulai penggunaan sebenarnya. Koreksi transaksi uji melalui refund/penarikan dengan catatan; jangan menghapus histori finansial secara sembunyi.

Pengujian Google nyata ini **belum dijalankan** pada lingkungan pengguna. Pengujian lokal tidak membuktikan izin produksi.

## Menjalankan dan mengembangkan

Memerlukan Node.js modern; tidak ada dependency npm untuk build/test.

```sh
node scripts/build.mjs
node --test tests/*.test.cjs
node scripts/serve.mjs
```

Pratinjau lokal: `http://127.0.0.1:4173`. Build menyalin kode aturan bisnis ke `Core.gs`, kemudian menghasilkan `apps-script/Index.html` dan `dist/index.html` dari sumber yang sama. Jangan mengedit hasil build langsung. Data pratinjau hanya berada di memori; browser storage tidak dipakai sebagai database.

Sumber utama: `index.html`, `core.js`, dan `apps-script/Code.gs`. Jangan commit `.clasprc.json`, `.clasp.json`, kredensial Google, atau file `.env`.

## GitHub

Repository harus private karena menyimpan konfigurasi target pengguna. Setelah URL tujuan ditentukan, kirim sumber beserta hasil build Apps Script, pengujian, dan README ke repository itu. Pipeline pada `.github/workflows/checks.yml` memverifikasi build serta tes. Commit tidak memuat data asli, API key, atau berkas dari Drive.

Sites menggunakan penyimpanan sumber tersendiri untuk penerbitan pratinjau. Itu **bukan** pengganti repository GitHub milik pengguna yang diminta.

## Batas teknis dan operasional

- Sheets API batch update menyimpan perubahan record dan audit dalam satu batch. LockService mengurutkan perubahan dari aplikasi yang sama; bukan transaksi lintas Sheets dan Drive.
- Upload menggunakan awalan request ID untuk membantu retry setelah respons gagal. Jika file sudah dibuat tetapi pencatatan gagal, file mungkin tersisa di Drive. Jangan menganggap upload sukses sebelum aplikasi mengonfirmasi.
- Nominal disimpan sebagai rupiah bulat dengan batas input 1 triliun. Record JSON dibatasi 40.000 karakter; pisahkan item biaya dengan ledger sangat panjang.
- Profil, nilai keuangan, dan data pribadi tidak disimpan dalam log analitik eksternal.
- Penghapusan catatan nonfinansial pada UI belum memiliki undo aplikasi. Riwayat Google Sheets dapat membantu pemulihan manual. Berkas Drive tidak ikut dihapus.
- Validasi signature berkas bukan antivirus. Jangan mengunggah berkas tidak tepercaya; tidak ada klaim pemindaian malware.
- Apps Script mempunyai kuota dan batas waktu. Rancangan ini untuk pemakaian pribadi/pasangan, bukan SaaS besar. Volume tinggi membutuhkan desain lain.
- Backup dilakukan pemilik melalui salinan spreadsheet dan folder secara terpisah; belum ada backup otomatis atau SLA pemulihan.

## Referensi teknis

- https://developers.google.com/apps-script/guides/web
- https://developers.google.com/apps-script/reference/lock/lock-service
- https://developers.google.com/workspace/sheets/api/guides/batchupdate

Dokumentasi dan implementasi disusun 9 Oktober 2026.
