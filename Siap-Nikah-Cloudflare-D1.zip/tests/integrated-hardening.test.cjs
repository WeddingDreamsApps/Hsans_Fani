const test=require('node:test'),assert=require('node:assert/strict'),C=require('../core.js');
test('vendor changes update finance projection without losing payments or double counting',()=>{
 const db=C.blank();db.vendors.push({id:'vendor-1',name:'Vendor diperbarui',category:'Venue',amount:900000});db.budget.push({id:'linked-vendors-vendor-1',name:'Nama lama',category:'Lainnya',amount:700000,payments:[{type:'payment',amount:300000}]});
 const rows=C.financeRows(db);assert.equal(rows.length,1);assert.equal(rows[0].sourceKey,'vendors');assert.equal(rows[0].name,'Vendor diperbarui');assert.equal(C.totals(db).committed,900000);assert.equal(C.totals(db).paid,300000);assert.equal(C.totals(db).due,600000);
 db.vendors=[];assert.equal(C.totals(db).paid,300000);
});
test('shared task rules reject premature completion and dependency cycles without changing stored state',()=>{
 const db=C.blank(),save=(id,status,meta,version=0)=>C.mutate(db,{collection:'tasks',id,version,action:'save',data:{name:id,owner:'Efani',priority:'Normal',status,notes:JSON.stringify({schema:'timeline-v1',subtasks:[],dependencies:[],...meta})}},'now');
 save('task-first','Belum mulai',{});save('task-second','Belum mulai',{dependencies:['task-first']});const before=JSON.stringify(db);
 assert.throws(()=>save('task-second','Selesai',{dependencies:['task-first']},1),/pendahulu/);assert.equal(JSON.stringify(db),before);
 assert.throws(()=>save('task-first','Belum mulai',{dependencies:['task-second']},1),/lingkaran/);assert.equal(JSON.stringify(db),before);
 assert.throws(()=>save('task-third','Selesai',{subtasks:[{name:'Verifikasi',done:false}]}),/subtugas/);
 save('task-first','Selesai',{},1);save('task-second','Selesai',{dependencies:['task-first']},1);assert.equal(db.tasks[1].status,'Selesai');
});
