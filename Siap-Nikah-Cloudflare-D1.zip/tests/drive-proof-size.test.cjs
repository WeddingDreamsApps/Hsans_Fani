const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
test('signed Drive bridge accepts 15 MiB guest proofs and reads them without changing normal upload limits',()=>{
 const bytes=Buffer.alloc(15*1024*1024);bytes.write('%PDF-1.4');let creates=0;const file={getId:()=> 'proof-file',getUrl:()=> 'https://drive.google.com/file/d/proof-file',getSize:()=>bytes.length,getParents:()=>({hasNext:()=>creates++===1,next:()=>({getId:()=> 'folder'})}),getBlob:()=>({getBytes:()=>bytes,getContentType:()=> 'application/pdf'})};
 const folder={getSharingAccess:()=> 'private',getFilesByName:()=>({hasNext:()=>false}),createFile:()=>{creates++;return file;}};
 const state={GATEWAY_EMAIL_:'owner@example.test',DRIVE_FOLDER_ID:'folder',DriveApp:{Access:{PRIVATE:'private'},getFolderById:()=>folder,getFileById:()=>file},LockService:{getScriptLock:()=>({waitLock(){},releaseLock(){}})},Utilities:{base64Decode:s=>Buffer.from(s,'base64'),base64Encode:b=>Buffer.from(b).toString('base64'),newBlob:()=>({})}};
 vm.createContext(state);vm.runInContext(fs.readFileSync(require.resolve('../apps-script/CloudDrive.gs'),'utf8'),state);
 const req={requestId:'fixture-upload-0000001',base64:bytes.toString('base64'),mime:'application/pdf',name:'Proof.pdf',purpose:'guest-transfer-proof'};
 assert.equal(state.cloudUploadFile_(req).id,'proof-file');assert.throws(()=>state.cloudUploadFile_({...req,purpose:''}),/unggah|maksimal/);assert.equal(state.cloudGetFile_({fileId:'proof-file',name:'Proof.pdf'}).base64.length,20971520);
});
