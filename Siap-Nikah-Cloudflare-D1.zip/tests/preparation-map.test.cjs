const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');const ctx={adminPage(){},edit(){},drawDocs(){},dashboardReception(){}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('preparation-map.js','utf8'),ctx);test('documents follow location and explicit saved assignment wins',()=>{assert.equal(ctx.prepRecordPlace({name:'Surat pengantar nikah desa / kelurahan'}),'desa');assert.equal(ctx.prepRecordPlace({name:'Surat pengantar RT / RW'}),'rt');assert.equal(ctx.prepRecordPlace({name:'Buku nikah suami'}),'kua');assert.equal(ctx.prepRecordPlace({name:'Custom',source:'https://example.com/#peta=resepsi'}),'resepsi');assert.equal(ctx.prepRecordPlace({name:'KTP',source:'https://example.com/#peta=asal'}),'asal');});test('map filters existing documents without deleting them',()=>{vm.runInContext("prepPlace='sehat'",ctx);assert.equal(ctx.prepVisibleDoc({name:'Surat keterangan sehat'}),true);assert.equal(ctx.prepVisibleDoc({name:'KTP'}),false);vm.runInContext("prepPlace='all'",ctx);assert.equal(ctx.prepVisibleDoc({name:'KTP'}),true);});
ctx.kuaRowStatus=row=>row.status==='Selesai'||row.files?.length?'Selesai':['Disiapkan','Diajukan','Perlu perbaikan'].includes(row.status)?'Disiapkan':'Belum disiapkan';test('roadmap percentage counts Done only and starts at zero without records',()=>{assert.equal(ctx.prepProgress([]).percent,0);assert.equal(ctx.prepProgress([{status:'Disiapkan'},{files:[{id:'done-file'}]},{status:'Belum disiapkan'}]).percent,33);assert.equal(ctx.prepProgress([{files:[{id:'file'}]}]).percent,100);});
ctx.esc=value=>String(value);ctx.icon=()=>'';ctx.principal={};ctx.C={can:()=>false};
ctx.kuaTarget=row=>row.owner||'Kedua mempelai';
test('reusing a requirement copies its definition without copying personal files, completion or costs',()=>{
 const fields=ctx.prepReusableFields({name:'KTP',requirementType:'Umum',owner:'Mempelai pria',status:'Selesai',files:[{id:'ktp-pria'}],source:'https://example.com/#peta=desa&biaya=100000',notes:'Catatan pria'});
 assert.deepEqual(JSON.parse(JSON.stringify(fields)),{name:'KTP',requirementType:'Umum'});
});
test('shared requirements are reused at KUA and duplicates respect each bride or groom',()=>{
 assert.ok(ctx.prepCatalog('kua').includes('KTP'));
 assert.ok(ctx.prepCatalog('kua').includes('Surat keterangan sehat'));
 assert.equal(ctx.prepRequirementType('Surat rekomendasi nikah KUA asal','kua'),'Bersyarat');
 const rows=[{id:'pria',name:'KTP',owner:'Mempelai pria'},{id:'both',name:'Kartu keluarga',owner:'Kedua mempelai'}];
 assert.equal(ctx.prepDuplicate(rows,' ktp ','Mempelai pria').id,'pria');
 assert.equal(ctx.prepDuplicate(rows,'KTP','Mempelai wanita'),undefined);
 assert.equal(ctx.prepDuplicate(rows,'Kartu   keluarga','Mempelai wanita').id,'both');
 assert.equal(ctx.prepDuplicate(rows,'KTP','Mempelai pria','pria'),undefined);
 assert.equal(ctx.prepProgress([{status:'Selesai'},{status:'Disiapkan'}]).percent,50);
 const shared={name:'KTP',source:'https://example.com/#peta=desa',status:'Selesai'};
 assert.equal(ctx.prepMatchesPlace(shared,'desa'),true);
 assert.equal(ctx.prepMatchesPlace(shared,'kua'),true);
 assert.equal(ctx.prepMatchesPlace(shared,'rt'),false);
});
test('optional cost round trips with accounting separators and distinguishes empty from zero',()=>{
 const source=ctx.prepSourceWithCost('', 'sehat', '600.000');
 assert.equal(ctx.prepCost({source}),600000);
 assert.equal(ctx.prepRecordPlace({source}),'sehat');
 assert.equal(ctx.prepCost({source:ctx.prepSourceWithCost(source,'rt','')}),'');
 assert.equal(ctx.prepCost({source:ctx.prepSourceWithCost(source,'rt','0')}),0);
 const revised=ctx.prepSourceWithCost(source,'rt','300.000');
 assert.equal(ctx.prepCost({source:revised}),300000);
 assert.equal((revised.match(/biaya=/g)||[]).length,1);
 assert.equal(ctx.prepCost({source:''}),'');
 assert.throws(()=>ctx.prepSourceWithCost('', 'rt','-1'));
 assert.throws(()=>ctx.prepSourceWithCost('', 'rt','1000000000001'));
});
test('editor guidance follows the selected destination and respects linked module access',()=>{
 assert.match(ctx.prepGuidance('rt'),/pengantar RT\/RW/);
 assert.doesNotMatch(ctx.prepGuidance('rt'),/sertifikatnya/);
 assert.match(ctx.prepGuidance('kua'),/Bimwin/);
 assert.doesNotMatch(ctx.prepGuidance('kua'),/data-prep-form-link/);
 ctx.C.can=(_user,key)=>key==='budget';
 assert.match(ctx.prepGuidance('kua'),/data-prep-form-link="budget"/);
 assert.doesNotMatch(ctx.prepGuidance('kua'),/data-prep-form-link="tasks"/);
 assert.equal(ctx.prepGuidance('invalid'),'');
});
