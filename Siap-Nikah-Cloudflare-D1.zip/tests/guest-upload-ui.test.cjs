const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm');
test('upload shows actual progress, blocks double submit, waits for storage and recovers on error',async()=>{
 const {guestForm}=await import('../cloudflare/guest-checkin.mjs');const nodes={},controls=[{disabled:false,textContent:''},{disabled:false}],attributes={};const form={dataset:{},reportValidity:()=>true,setAttribute:(k,v)=>attributes[k]=v,querySelector:()=>controls[0],querySelectorAll:()=>controls,reset(){}};
 nodes['guest-form']=form;nodes.transferProof={files:[]};nodes['upload-progress']={removeAttribute(k){delete this[k]}};
 const state={document:{getElementById:id=>nodes[id]??=( {hidden:true,textContent:''})},crypto:{randomUUID:()=> 'fixture-request-000001'},location:{search:'?token=fixture'},URLSearchParams,FormData:class{*[Symbol.iterator](){yield ['name','Fixture'];yield ['address','Fixture'];yield ['contact','081234567890'];}},XMLHttpRequest:class{constructor(){state.requests=(state.requests||0)+1;state.xhr=this;this.upload={}}open(){}setRequestHeader(){}send(body){this.sent=JSON.parse(body)}},Error};
 vm.createContext(state);vm.runInContext(guestForm.match(/<script>([\s\S]*?)<\/script>/)[1],state);
 const pending=form.onsubmit({preventDefault(){}});assert.equal(nodes['upload-state'].hidden,false);assert.equal(form.dataset.busy,'true');assert.equal(controls[1].disabled,true);
 await form.onsubmit({preventDefault(){}});assert.equal(state.requests,1);
 state.xhr.upload.onprogress({lengthComputable:true,loaded:25,total:100});assert.match(nodes['upload-stage'].textContent,/25%/);assert.equal(nodes['upload-progress'].value,25);
 state.xhr.upload.onload();assert.match(nodes['upload-stage'].textContent,/Menyimpan/);assert.equal(nodes['upload-state'].hidden,false);
 state.xhr.status=400;state.xhr.response={error:'Drive belum tersimpan'};state.xhr.onload();await pending;
 assert.equal(nodes['upload-state'].hidden,true);assert.equal(form.dataset.busy,'false');assert.equal(controls[0].disabled,false);assert.equal(controls[1].disabled,false);assert.equal(nodes.message.textContent,'Drive belum tersimpan');
});
