const test=require('node:test'),assert=require('node:assert/strict'),C=require('../core.js');
const now='2026-10-11T12:00:00Z';
const save=(db,amount,version=0)=>C.mutate(db,{collection:'admin',id:'preparation-one',version,action:'save',data:{name:'Pemeriksaan kesehatan',status:'Belum disiapkan',source:'https://example.com/#peta=sehat'+(amount===null?'':'&biaya='+amount)}},now);
test('preparation expense persists and updates dashboard totals exactly once',()=>{
 const db=C.blank();db.budget=[{amount:1000000,payments:[{type:'payment',source:'Dana lain',amount:200000}]}];
 save(db,600000);
 assert.equal(C.preparationCost(db.admin[0]),600000);
 assert.equal(C.totals(db).paid,800000);
 assert.equal(C.totals(db).committed,1600000);
 assert.equal(C.totals(db).due,800000);
 assert.equal(C.totals(db).netEventCash,-800000);
 assert.equal(C.totals(db).paid,800000);
 save(db,300000,1);
 assert.equal(C.totals(db).paid,500000);
 assert.equal(C.totals(db).preparationPaid,300000);
 save(db,null,2);
 assert.equal(C.totals(db).paid,200000);
 save(db,0,3);
 assert.equal(C.preparationCost(db.admin[0]),0);
 assert.equal(C.totals(db).paid,200000);
});
test('removed records and invalid cost metadata cannot inflate expenses',()=>{
 const db=C.blank();save(db,100000);
 C.mutate(db,{collection:'admin',id:'preparation-one',version:1,action:'delete'},now);
 assert.equal(C.totals(db).paid,0);
 db.admin=[{source:'https://example.com/#peta=rt&biaya=1000000000001'},{source:'https://example.com/#peta=rt&biaya=-100'}];
 assert.equal(C.totals(db).paid,0);
 assert.equal(C.preparationCost({source:''}),null);
});
