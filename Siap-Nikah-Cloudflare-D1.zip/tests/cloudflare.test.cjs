const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
function fixture(){
  const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync(path.join(__dirname,'../cloudflare/schema.sql'),'utf8'));
  const env={DB:{prepare(sql){return {bind(...args){return {async first(){return sqlite.prepare(sql).get(...args)||null;}}},async first(){return sqlite.prepare(sql).get()||null;}}}},OWNER_EMAIL:'hasanudin.legal@gmail.com',ALLOWED_ORIGINS:'https://weddingdreamsapps.github.io',SUPABASE_URL:'https://example.supabase.co',SUPABASE_PUBLISHABLE_KEY:'public',GOOGLE_APPS_SCRIPT_URL:'https://script.google.com/macros/s/test-deployment/exec',GATEWAY_SECRET:'a'.repeat(64)};
  return {sqlite,env,async call(method,payload){const {handle}=await import('../cloudflare/worker.mjs');return handle(new Request('https://app.workers.dev',{method:'POST',headers:{Origin:env.ALLOWED_ORIGINS,Authorization:'Bearer test','Content-Type':'application/json'},body:JSON.stringify({method,payload})}),env);}};
}
test('account service check is read-only and never returns server key or identities',async()=>{
 const f=fixture(),previous=global.fetch;f.env.SUPABASE_SECRET_KEY='private-test-secret';let adminCalls=0;
 global.fetch=async(url,options)=>{if(String(url).includes('/admin/users?')){adminCalls++;assert.equal(options.headers.apikey,f.env.SUPABASE_SECRET_KEY);return Response.json({users:[{email:'private@example.com'}]});}return Response.json({id:'owner',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});};
 try{const before=f.sqlite.prepare('SELECT data,version FROM wedding_state').get();const response=await f.call('checkAccountService');assert.equal(response.status,200);const body=await response.text();assert.ok(!body.includes('private'));assert.equal(adminCalls,1);assert.deepEqual(f.sqlite.prepare('SELECT data,version FROM wedding_state').get(),before);assert.equal(f.sqlite.prepare('SELECT count(*) n FROM wedding_audit').get().n,0);}finally{global.fetch=previous;f.sqlite.close();}
});
test('account service check reports invalid key without leaking upstream response',async()=>{
 const f=fixture(),previous=global.fetch;f.env.SUPABASE_SECRET_KEY='private-test-secret';global.fetch=async url=>String(url).includes('/admin/users?')?new Response('private upstream detail',{status:401}):Response.json({id:'owner',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});
 try{const response=await f.call('checkAccountService');assert.equal(response.status,502);const body=await response.text();assert.match(body,/401/);assert.ok(!body.includes('private'));}finally{global.fetch=previous;f.sqlite.close();}
});
test('owner backup contains data version but no infrastructure secrets and is read-only',async()=>{
 const f=fixture(),previous=global.fetch;global.fetch=async()=>Response.json({id:'owner',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});
 try{const before=f.sqlite.prepare('SELECT data,version FROM wedding_state').get(),response=await f.call('exportBackup');assert.equal(response.status,200);const result=await response.json();assert.equal(result.schema,'siap-nikah-backup-v1');assert.equal(result.version,before.version);assert.deepEqual(result.data,JSON.parse(before.data));assert.ok(!JSON.stringify(result).includes(f.env.GATEWAY_SECRET));assert.deepEqual(f.sqlite.prepare('SELECT data,version FROM wedding_state').get(),before);}finally{global.fetch=previous;f.sqlite.close();}
});
test('Drive preserves signed POST through canonical redirects and strips body on content redirect',async()=>{
 const f=fixture(),previous=global.fetch;let body,posts=0,gets=0;
 global.fetch=async(url,options)=>{url=String(url);if(url.includes('/auth/v1/user'))return Response.json({id:'owner',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});if(url.startsWith('https://script.googleusercontent.com/')){gets++;assert.equal(options.method,'GET');assert.equal(options.body,undefined);return Response.json({ok:true,result:{id:'redirected-file',name:'test.png',mime:'image/png'}});}posts++;assert.equal(options.method,'POST');if(!body)body=options.body;else assert.equal(options.body,body);return new Response(null,{status:302,headers:{location:posts===1?'https://script.google.com/macros/s/test-deployment/exec?canonical=1':'https://script.googleusercontent.com/macros/echo?user_content_key=test'}});};
 try{await f.call('changeData',{collection:'budget',id:'redirect-cost',version:0,action:'save',requestId:'redirect-create-0001',data:{name:'Test',category:'Lainnya',amount:0}});const response=await f.call('uploadAttachment',{collection:'budget',id:'redirect-cost',version:1,requestId:'redirect-upload-0001',name:'test.png',mime:'image/png',base64:'YWJjZA=='});assert.equal(response.status,200,await response.clone().text());assert.equal(posts,2);assert.equal(gets,1);}finally{global.fetch=previous;f.sqlite.close();}
});
test('Drive rejects redirect to an untrusted host without forwarding signed identity',async()=>{
 const f=fixture(),previous=global.fetch;let calls=0;global.fetch=async url=>{if(String(url).includes('/auth/'))return Response.json({id:'owner',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});calls++;return new Response(null,{status:302,headers:{location:'https://untrusted.example/steal'}});};
 try{await f.call('changeData',{collection:'budget',id:'blocked-cost',version:0,action:'save',requestId:'blocked-create-0001',data:{name:'Test',category:'Lainnya',amount:0}});const response=await f.call('uploadAttachment',{collection:'budget',id:'blocked-cost',version:1,requestId:'blocked-upload-0001',name:'test.png',mime:'image/png',base64:'YWJjZA=='});assert.equal(response.status,400);assert.equal(calls,1);assert.match((await response.json()).error,/deployment/);assert.equal((JSON.parse(f.sqlite.prepare('SELECT data FROM wedding_state').get().data).budget[0].files||[]).length,0);}finally{global.fetch=previous;f.sqlite.close();}
});
test('free quota: rejected rate-limit requests stop writing D1',async()=>{
  const f=fixture(),previous=global.fetch;global.fetch=async()=>Response.json({id:'quota-user',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});
  try{for(let i=0;i<60;i++)assert.equal((await f.call('loadData')).status,200);for(let i=0;i<10;i++)assert.equal((await f.call('loadData')).status,429);assert.equal(f.sqlite.prepare('SELECT requests FROM wedding_limits').get().requests,61);assert.equal(f.sqlite.prepare('SELECT count(*) n FROM wedding_audit').get().n,0);}finally{global.fetch=previous;f.sqlite.close();}
});
test('Drive uploads use signed owner identity, persist metadata, replay once and download only linked files',async()=>{
  const f=fixture(),previous=global.fetch;let uploads=0,reads=0;
  global.fetch=async(url,options)=>{
    if(String(url).includes('/auth/v1/user'))return Response.json({id:'owner-user',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});
    const envelope=JSON.parse(options.body),p=JSON.parse(envelope.payload);
    const expected=require('node:crypto').createHmac('sha256',f.env.GATEWAY_SECRET).update(envelope.payload).digest('hex');assert.equal(envelope.signature,expected);assert.equal(p.email,f.env.OWNER_EMAIL);
    if(p.method==='cloudUploadFile'){uploads++;return Response.json({ok:true,result:{id:'drive-file-one',name:p.args.name,mime:p.args.mime}});}
    reads++;assert.equal(p.method,'cloudGetFile');return Response.json({ok:true,result:{name:'test.png',mime:'image/png',base64:'YWJjZA=='}});
  };
  try{
    let response=await f.call('changeData',{collection:'budget',id:'cost-test',version:0,requestId:'cost-test-request-0001',action:'save',data:{name:'Test invoice',category:'Lainnya',amount:0,date:'',owner:'',notes:''}});assert.equal(response.status,200);
    const upload={collection:'budget',id:'cost-test',version:1,requestId:'upload-test-request-01',name:'test.png',mime:'image/png',base64:'YWJjZA==',email:'forged@example.com'};
    response=await f.call('uploadAttachment',upload);assert.equal(response.status,200);assert.equal((await response.json()).data.budget[0].files.length,1);
    assert.equal((await (await f.call('uploadAttachment',upload)).json()).duplicate,true);assert.equal(uploads,1);
    assert.equal((await f.call('getAttachment',{collection:'budget',id:'cost-test',fileId:'drive-file-one'})).status,200);assert.equal(reads,1);
    assert.equal((await f.call('getAttachment',{collection:'budget',id:'cost-test',fileId:'another-private-file'})).status,400);assert.equal(reads,1);
    assert.equal((await f.call('uploadAttachment',{...upload,requestId:'upload-test-request-02',version:1})).status,400);assert.equal(uploads,1);
    assert.equal(JSON.parse(f.sqlite.prepare('SELECT data FROM wedding_state').get().data).budget[0].amount,0);
  }finally{global.fetch=previous;f.sqlite.close();}
});
test('Drive configuration failures preserve D1 record and report the missing setting',async()=>{
  const f=fixture(),previous=global.fetch;let driveCalls=0;global.fetch=async url=>{if(!String(url).includes('/auth/'))driveCalls++;return Response.json({id:'owner',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});};
  try{
    await f.call('changeData',{collection:'admin',id:'doc-test',version:0,requestId:'doc-test-request-0001',action:'save',data:{name:'Test document',requirementType:'Umum',available:false,owner:'',date:'',status:'Belum disiapkan',source:'',notes:''}});
    f.env.GATEWAY_SECRET='short';const response=await f.call('uploadAttachment',{collection:'admin',id:'doc-test',version:1,requestId:'doc-upload-request-01',name:'test.pdf',mime:'application/pdf',base64:'JVBERg=='});assert.equal(response.status,400);assert.match((await response.json()).error,/GATEWAY_SECRET/);assert.equal(driveCalls,0);assert.equal(f.sqlite.prepare('SELECT version FROM wedding_state').get().version,1);
  }finally{global.fetch=previous;f.sqlite.close();}
});
test('D1 stores once, rejects conflicting replays and denies nonmembers',async()=>{
  const {handle}=await import('../cloudflare/worker.mjs');const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync(path.join(__dirname,'../cloudflare/schema.sql'),'utf8'));
  const env={DB:{prepare(sql){return {bind(...args){return {async first(){return sqlite.prepare(sql).get(...args)||null;}}},async first(){return sqlite.prepare(sql).get()||null;}}}},OWNER_EMAIL:'hasanudin.legal@gmail.com',ALLOWED_ORIGINS:'https://weddingdreamsapps.github.io',SUPABASE_URL:'https://example.supabase.co',SUPABASE_PUBLISHABLE_KEY:'public'};
  const previous=global.fetch;let email=env.OWNER_EMAIL;global.fetch=async()=>new Response(JSON.stringify({id:'user-1',email,email_confirmed_at:'2026-10-10'}));
  const call=(method,payload)=>handle(new Request('https://app.workers.dev',{method:'POST',headers:{Origin:env.ALLOWED_ORIGINS,Authorization:'Bearer test','Content-Type':'application/json'},body:JSON.stringify({method,payload})}),env);
  try{
    const payload={collection:'tasks',id:'task-one',version:0,requestId:'request-1234567890123456',action:'save',data:{name:'Uji checklist',owner:'Hasanudin',date:'2026-10-10',priority:'Normal',status:'Belum mulai',notes:''}};
    const saved=await call('changeData',payload);assert.equal(saved.status,200,await saved.clone().text());
    assert.equal(sqlite.prepare('SELECT count(*) n FROM wedding_audit').get().n,1);
    const replay=await call('changeData',payload);assert.equal((await replay.json()).duplicate,true);assert.equal(sqlite.prepare('SELECT version FROM wedding_state').get().version,1);
    const conflict=await call('changeData',{...payload,data:{...payload.data,name:'Changed'}});assert.equal(conflict.status,400);
    email='outsider@example.com';const denied=await call('loadData');assert.equal(denied.status,400);assert.match((await denied.json()).error,/Akses akun/);
    const noauth=await handle(new Request('https://app.workers.dev',{method:'POST',headers:{Origin:env.ALLOWED_ORIGINS},body:'{}'}),env);assert.equal(noauth.status,401);
    const badOrigin=await handle(new Request('https://app.workers.dev',{method:'POST',headers:{Origin:'https://other.example'},body:'{}'}),env);assert.equal(badOrigin.status,403);
  }finally{global.fetch=previous;sqlite.close();}
});
test('SQLite audit failure rolls back state; stale versions do not overwrite',()=>{
  const db=new DatabaseSync(':memory:');db.exec(fs.readFileSync(path.join(__dirname,'../cloudflare/schema.sql'),'utf8'));
  const statement=db.prepare("UPDATE wedding_state SET version=version+1,request_id=?,actor='owner',fingerprint='hash',updated_at='now' WHERE id=1 AND version=? RETURNING version");
  assert.equal(statement.get('request-one',0).version,1);assert.equal(statement.get('request-two',0),undefined);
  assert.throws(()=>statement.get('request-one',1),/UNIQUE/);assert.equal(db.prepare('SELECT version FROM wedding_state').get().version,1);db.close();
});

test('user history verifies identity, protects audit fields, rejects stale edits and limits management to owner',async()=>{
 const f=fixture(),previous=global.fetch;let email=f.env.OWNER_EMAIL;global.fetch=async()=>Response.json({id:'history-user',email,email_confirmed_at:'now'});
 try{const request={requestId:'login-history-request-0001',email:'forged@example.com'};assert.equal((await f.call('recordLogin',request)).status,200);assert.equal((await (await f.call('recordLogin',request)).json()).duplicate,true);let data=await(await f.call('getUserHistory')).json();assert.equal(data.history.length,1);const item=data.history[0];assert.equal(item.email,f.env.OWNER_EMAIL);assert.equal((await f.call('changeUserHistory',{id:item.id,version:1,action:'edit',notes:'Checked',timestamp:'forged',requestId:'history-edit-request-0001'})).status,200);data=await(await f.call('getUserHistory')).json();assert.equal(data.history[0].timestamp,item.timestamp);assert.equal(data.history[0].notes,'Checked');assert.equal((await f.call('changeUserHistory',{id:item.id,version:1,action:'delete',requestId:'history-stale-request-0001'})).status,400);assert.equal((await f.call('changeUserHistory',{id:item.id,version:2,action:'delete',requestId:'history-delete-request-001'})).status,200);data=await(await f.call('getUserHistory')).json();assert.equal(data.history.some(x=>x.id===item.id),false);assert.ok(f.sqlite.prepare('SELECT count(*) n FROM wedding_audit').get().n>=3);assert.equal((await f.call('saveOwnerProfile',{name:'Owner',requestId:'owner-profile-request-001'})).status,200);assert.equal((await(await f.call('getUserHistory')).json()).ownerProfile.name,'Owner');
 const state=JSON.parse(f.sqlite.prepare('SELECT data FROM wedding_state').get().data);state.users.push({id:'member',email:'member@example.com',status:'Aktif',role:'Panitia',permissions:'{}'});f.sqlite.prepare('UPDATE wedding_state SET request_id=NULL,data=?').run(JSON.stringify(state));email='member@example.com';assert.equal((await f.call('getUserHistory')).status,403);assert.equal((await f.call('saveOwnerProfile',{name:'Hijack',requestId:'member-profile-request-01'})).status,403);assert.equal((await f.call('recordLogin',{requestId:'member-login-request-0001'})).status,200);
 }finally{global.fetch=previous;f.sqlite.close();}
});

test('account provisioning is owner-only, idempotent and never stores a password in D1',async()=>{
 const f=fixture(),previous=global.fetch;let email=f.env.OWNER_EMAIL,created=0;f.env.SUPABASE_SECRET_KEY='server-only-test';
 global.fetch=async(url,options)=>{if(String(url).endsWith('/auth/v1/admin/users')){created++;const payload=JSON.parse(options.body);assert.equal(payload.email,'panitia1@users.siapnikah.app');assert.equal(payload.email_confirm,true);return Response.json({id:'auth-created'});}return Response.json({id:'verified-owner',email,email_confirmed_at:'now'});};
 try{const payload={name:'Panitia',username:'Panitia1',role:'Panitia',permissions:JSON.stringify({guests:'write',budget:'none'}),password:'test-password-123',requestId:'create-account-test-0001'};let response=await f.call('createUserAccount',payload);assert.equal(response.status,200,await response.clone().text());let state=JSON.parse(f.sqlite.prepare('SELECT data FROM wedding_state').get().data);assert.equal(state.users[0].username,'panitia1');assert.deepEqual(JSON.parse(state.users[0].permissions),{guests:'write',budget:'none'});assert.ok(!JSON.stringify(state).includes(payload.password));assert.equal((await(await f.call('createUserAccount',payload)).json()).duplicate,true);assert.equal(created,1);delete f.env.SUPABASE_SECRET_KEY;assert.equal((await f.call('createUserAccount',{...payload,requestId:'create-account-test-0002'})).status,503);f.env.SUPABASE_SECRET_KEY='server-only-test';email='panitia1@users.siapnikah.app';assert.equal((await f.call('createUserAccount',{...payload,requestId:'create-account-test-0003'})).status,403);}finally{global.fetch=previous;f.sqlite.close();}
});

test('editing an account preserves auth email, applies access, updates password server-side and renamed username logs in',async()=>{
 const f=fixture(),previous=global.fetch;f.env.SUPABASE_SECRET_KEY='test-server';let passwordUpdates=0;global.fetch=async(url,options)=>{url=String(url);if(url.includes('token?')){assert.equal(JSON.parse(options.body).email,'panitia1@users.siapnikah.app');return Response.json({access_token:'test-session',user:{email:'panitia1@users.siapnikah.app'}});}if(url.includes('/admin/users?page'))return Response.json({users:[{id:'member-auth',email:'panitia1@users.siapnikah.app'}]});if(url.endsWith('/admin/users/member-auth')){passwordUpdates++;assert.equal(JSON.parse(options.body).password,'new-test-password');return Response.json({id:'member-auth'});}if(url.endsWith('/admin/users'))return Response.json({id:'member-auth'});return Response.json({id:'owner-auth',email:f.env.OWNER_EMAIL,email_confirmed_at:'now'});};
 try{await f.call('createUserAccount',{name:'Panitia',username:'panitia1',password:'first-test-password',requestId:'edit-account-create-0001'});let state=JSON.parse(f.sqlite.prepare('SELECT data FROM wedding_state').get().data),member=state.users[0];let response=await f.call('updateUserAccount',{id:member.id,version:member.version,name:'Budi',username:'budi',role:'Koordinator',status:'Aktif',permissions:'{"guests":"write"}',password:'new-test-password',requestId:'edit-account-update-0001'});assert.equal(response.status,200,await response.clone().text());state=JSON.parse(f.sqlite.prepare('SELECT data FROM wedding_state').get().data);assert.equal(state.users[0].username,'budi');assert.equal(state.users[0].email,'panitia1@users.siapnikah.app');assert.equal(passwordUpdates,1);assert.ok(!JSON.stringify(state).includes('new-test-password'));const {handle}=await import('../cloudflare/worker.mjs');response=await handle(new Request('https://app.workers.dev',{method:'POST',headers:{Origin:f.env.ALLOWED_ORIGINS,'Content-Type':'application/json'},body:JSON.stringify({method:'loginAccount',payload:{email:'budi',password:'new-test-password'}})}),f.env);assert.equal(response.status,200);assert.equal((await response.json()).access_token,'test-session');}finally{global.fetch=previous;f.sqlite.close();}
});
