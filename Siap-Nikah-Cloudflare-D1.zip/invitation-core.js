var WeddingInvitations=(function(){
 const types=['Fisik','Digital','Fisik & Digital'],sides=['Hasanudin','Efani','Bersama'];
 function read(row){let meta;try{meta=JSON.parse(row.notes||'');}catch{}if(meta?.schema==='invitation-v1')return {side:sides.includes(meta.side)?meta.side:'Bersama',type:types.includes(meta.type)?meta.type:'Fisik',physical:meta.physical===true,digital:meta.digital===true,note:String(meta.note||'')};return {side:'Bersama',type:'Belum ditentukan',physical:false,digital:row.deliveryStatus==='Dikirim'||row.deliveryStatus==='Dibuka',note:row.notes||''};}
 function encode(value){if(!types.includes(value.type))throw Error('Pilih jenis undangan.');return JSON.stringify({schema:'invitation-v1',side:sides.includes(value.side)?value.side:'Bersama',type:value.type,physical:value.type!=='Digital'&&!!value.physical,digital:value.type!=='Fisik'&&!!value.digital,note:value.note||''});}
 function delivered(value){return value.type==='Fisik'?value.physical:value.type==='Digital'?value.digital:value.type==='Fisik & Digital'?value.physical&&value.digital:false;}
 function rsvp(row){return ['Hadir','Tidak hadir','Belum pasti'].includes(row.status)?row.status:'Belum konfirmasi';}
 function channels(value){return [value.type!=='Digital'&&value.type!=='Belum ditentukan'?'Fisik: '+(value.physical?'Diserahkan':'Belum diserahkan'):'',value.type!=='Fisik'?'Digital: '+(value.digital?'Dikirim':'Belum dikirim'):''].filter(Boolean);}
 function dispatch(row){const meta=read(row);if(meta.type==='Belum ditentukan')return meta.digital?'Sudah dikirim':'Belum dikirim';if(delivered(meta))return 'Sudah dikirim';if(meta.physical||meta.digital)return 'Dikirim sebagian';return 'Belum dikirim';}
 function matches(row,filter){if(!filter)return true;if(filter.startsWith('Pihak: '))return read(row).side===filter.slice(7);if(['Belum dikirim','Dikirim sebagian','Sudah dikirim'].includes(filter))return dispatch(row)===filter;return rsvp(row)===filter;}
 function normalized(value){return String(value||'').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();}
 function duplicates(rows,draft){const name=normalized(draft.name),address=normalized(draft.address);if(!name)return [];return rows.filter(row=>row.id!==draft.id&&normalized(row.name)===name).map(row=>({row,exact:!!address&&normalized(row.address)===address}));}
 return {types,sides,read,encode,delivered,rsvp,channels,dispatch,matches,duplicates};
})();
if(typeof module!=='undefined')module.exports=WeddingInvitations;
