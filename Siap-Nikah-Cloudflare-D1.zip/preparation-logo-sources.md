# Sumber lambang

- Kementerian Agama: https://sulteng.kemenag.go.id/parimokab/profil/logo-kementerian-agama (lambang pada footer)
- Puskesmas: https://puskesmaskaligondang.purbalinggakab.go.id/cropped-logo-puskesmas-png/

RT/RW, kelurahan, akad, dan resepsi memakai penanda ilustratif, bukan klaim logo resmi daerah atau venue.
